# Find Skills — Claude Code Skill Kit

One Claude Code skill that finds you the right tool for the job — so you never build a workflow from scratch when someone has already packaged it.

Ask Claude *"is there a skill for this?"* and it searches the open skills library, checks how many people trust each one, and hands you the exact install command. It always checks the skills you already have first.

---

## The four steps

You need to do four things. Everything technical happens on Claude's side.

1. **Download** this kit (the zip).
2. **Unzip** it.
3. **Drag** the `.claude` folder into your business folder (the folder you open in Claude Code).
4. **Paste** this one message into Claude Code:

   > Is there a skill for &lt;the thing you're trying to do&gt;? Use the find-skills skill.

That's it. Claude takes over from there — it searches, vets the options by how many people use them, and recommends one. It only installs when you say go.

---

## Don't have Claude Code yet?

Get the **Claude desktop app** (Mac or Windows) — the non-technical-friendly version, no terminal required. Sign in, open your business folder, and paste the message above. If you prefer the command line, the CLI works identically.

---

## Where the skill lives

The kit puts it here:

```
your-business-folder/
└── .claude/
    └── skills/
        └── find-skills/
            └── SKILL.md
```

Skills in a project's `.claude/skills/` load whenever you open that folder in Claude Code. To make it available in *every* project on your machine instead, drag the `find-skills` folder into `~/.claude/skills/`.

---

## What it does

- Searches the open skills library (`npx skills find`) and the leaderboard at https://skills.sh/
- **Vets before it recommends** — prefers skills with 1,000+ installs and trusted sources, and warns you off anything unproven
- Gives you the exact one-line install command and only installs on your go
- **Checks the skills you already have first** — most of what you do every day is already covered

---

## Notes

- This finds *general-purpose* skills built by the wider community. They won't know your brand voice or your funnel — use your own custom skills for anything brand- or content-facing, and reach outside only for a genuinely new capability (a file format, a dev tool, a new integration).
- Nothing installs without your say-so. Claude shows you the option and the source first.
