# Viral to Script — Claude Code Skill

One Claude Code skill that turns a batch of viral videos into shoot-ready short-form reel scripts:

**`/viral-to-script`** — you hand it your SortFeed notes (source page, link, view count, hook for each reel), and it extracts the transferable mechanic from each one, screens out anything that would attract the wrong audience, re-anchors it on the woman we serve, and returns tagged VO / TH scripts with hooks, beats, shot lists, captions, and tracker rows. Up to 10 scripts per run.

The full training guide (including SortFeed setup and how to work your niche) lives here:
https://agency-true-north.github.io/team-true-north/Viral%20to%20Script%20System.html

---

## Install

A Claude Code skill is just a folder named `<skill-name>/` with a `SKILL.md` inside, placed in a `.claude/skills/` directory. Two places work:

- **Personal (all your projects):** `~/.claude/skills/`
- **One project (shared with your team via git):** `<project>/.claude/skills/`

### Option A — copy the folder in

Copy the skill folder from this package into whichever `.claude/skills/` you want:

```bash
# personal, available everywhere
mkdir -p ~/.claude/skills
cp -R "viral-to-script" ~/.claude/skills/

# or per-project (commit it so teammates get it too)
mkdir -p /path/to/your-project/.claude/skills
cp -R "viral-to-script" /path/to/your-project/.claude/skills/
```

(The skill folder lives under `.claude/skills/` inside this package.)

### Option B — do it by hand

Create the folder and paste the `SKILL.md`:

```
.claude/
└── skills/
    └── viral-to-script/
        └── SKILL.md
```

Restart Claude Code (or start a new session) so it picks up the new skill.

---

## Use

In Claude Code, type:

```
/viral-to-script
```

or just say it in plain language — "turn these virals into scripts" — and paste your batch, one line per reel:

```
1. @sourcepage — [link] — 2.1M views — hook: "[first line of the reel]" — format: [talking head list / b-roll with text / voiceover story]
2. ...
```

Claude hands back tagged scripts and tracker rows. You make the call on which to shoot, which to kill, and the one talking-head pick of the week.

---

## What you'll need

- **Claude Code** (CLI, desktop, web, or IDE extension).
- **SortFeed** set up in Chrome — section 01 of the training guide walks through it.
- Your **niche map** — 10–20 creators plus 5–10 hashtags. Section 02 of the guide.

---

## Notes

- The core rule is baked in and outranks everything: **model the format and hook mechanics, never the topic.** The kill list exists so a borrowed topic never imports the wrong audience.
- The voice rules are baked in too — second person, no exclamation marks, no income numbers, the doubt never named. One miss sends a script back.
- When the master copy of this skill gets updated, re-install the same way — your local copy doesn't update itself.
