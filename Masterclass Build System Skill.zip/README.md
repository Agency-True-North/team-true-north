# Masterclass Build System / Claude Code Skill Kit

Three Claude Code skills that take you from a blank page to a finished, high-converting masterclass, **in your own voice, for your own audience.**

1. **`setup`** — run this once. It builds your whole Claude foundation: your folders, your voice file, your goals and offer, your writing rules, and a deep ideal-client profile, all through one guided conversation. It looks at what you already have before asking anything, gets your approval on every file, and picks up where it left off if you get interrupted.
2. **`build-icp`** — the deep ideal-client interview plus real Voice-of-Customer research from the web. Setup runs this for you the first time. Run it again on its own whenever you target a new audience. It works for consumer businesses and professional/B2B sales; one early question adapts the whole interview.
3. **`build-masterclass`** — writes the whole class: Phase 1 the full spoken script (17-part spine), Phase 2 a slide-by-slide deck map, Phase 3 (optional) an actual Canva deck.

---

## The four steps

You do four things. Everything technical happens on Claude's side.

1. **Download** this kit (the zip).
2. **Unzip** it.
3. **Drag** the `.claude` folder into your business folder (the folder you open in Claude Code).
4. **Paste** this one message into Claude Code:

   > Read the file .claude/skills/setup/SKILL.md and follow it exactly, step by step, starting now.

That's it. Claude takes over from there. It interviews you, builds your foundation files, and proves the voice back to you before it finishes. When setup is done, run `/build-masterclass`. Your ideal-client profile is already built, because setup runs the full ICP interview inside it.

**Already ran setup from the Team True North Claude Setup Guide?** You're done with step 4 before you started. Setup sees your finished foundation and won't make you repeat a thing. Go straight to `/build-masterclass`.

---

## Don't have Claude Code yet?

The Team True North **Claude Setup Guide** walks you through it with no terminal and no technical steps: two free apps, one folder, one paste. Start there, and this kit becomes a two-minute install.

---

## Where the skills live

The kit puts them here:

```
your-business-folder/
└── .claude/
    └── skills/
        ├── setup/            └── SKILL.md
        ├── build-icp/        └── SKILL.md
        └── build-masterclass/└── SKILL.md
```

Skills in a project's `.claude/skills/` load whenever you open that folder in Claude Code. To make them available in *every* project on your machine instead, drag the three skill folders into `~/.claude/skills/`.

---

## What you'll need

- **Claude Code** (the VS Code extension is easiest; the desktop app and CLI work identically).
- **Real writing of your own**: a couple of published emails, captions, or a sales page. `setup` will not calibrate to a voice that isn't on the page yet.
- **Web access** for the research phase (optional; it builds from your interview alone if web isn't available).
- **A Canva connection** only if you want Phase 3 to build the actual deck. The Phase 2 slide map is a human-buildable deliverable on its own.

---

## Notes

- **Your voice and your audience are different from anyone else's.** That's the entire reason `setup` exists. You don't inherit someone else's calibrations; you build your own in one conversation.
- The **17-part spine is fixed**. That's the proven structure. The skills change the words inside it for each audience, never the order.
- The governing law never changes: **sell the emotion, not the thing.**
