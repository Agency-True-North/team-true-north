# Masterclass Build System — Claude Code Skill

Two Claude Code skills that turn audience research into a finished, high-converting masterclass:

1. **`/build-icp`** — interviews you one question at a time, researches real Voice-of-Customer language on the web, and delivers an ICP Dossier (pains, fears, desires, objections as *emotions*), ending with a handoff block.
2. **`/build-masterclass`** — takes that ICP and writes the full masterclass: Phase 1 the complete spoken script (17-part spine), Phase 2 a slide-by-slide deck map, Phase 3 (optional) an actual Canva deck.

Run them in order: `/build-icp` first, then hand its output to `/build-masterclass`.

---

## Install

A Claude Code skill is just a folder named `<skill-name>/` with a `SKILL.md` inside, placed in a `.claude/skills/` directory. Two places work:

- **Personal (all your projects):** `~/.claude/skills/`
- **One project (shared with your team via git):** `<project>/.claude/skills/`

### Option A — copy the folders in

Copy the two skill folders from this package into whichever `.claude/skills/` you want:

```bash
# personal, available everywhere
mkdir -p ~/.claude/skills
cp -R "build-icp" "build-masterclass" ~/.claude/skills/

# or per-project (commit it so teammates get it too)
mkdir -p /path/to/your-project/.claude/skills
cp -R "build-icp" "build-masterclass" /path/to/your-project/.claude/skills/
```

(The skill folders live under `.claude/skills/` inside this package.)

### Option B — do it by hand

Create the folders and paste each `SKILL.md`:

```
.claude/
└── skills/
    ├── build-icp/
    │   └── SKILL.md
    └── build-masterclass/
        └── SKILL.md
```

Restart Claude Code (or start a new session) so it picks up the new skills.

---

## Use

In Claude Code, type:

```
/build-icp
```

Answer the interview questions one at a time. When it hands you a finished dossier (ending in an `ICP HANDOFF` block), run:

```
/build-masterclass
```

and paste or reference the handoff block. Ask for **Phase 3** if you want it to build the Canva deck (needs the Canva connector enabled, and it will pause for your OK before publishing anything public).

You can also just describe what you want in plain language ("build me an ICP for my coaching offer") — Claude will pick the right skill.

---

## What you'll need

- **Claude Code** (CLI, desktop, web, or IDE extension).
- **Web access** for the `/build-icp` research phase (optional — it'll build from the interview alone if web isn't available).
- **A Canva connection** only if you want Phase 3 to build the actual deck. Otherwise the Phase 2 slide map is a human-buildable deliverable on its own.

---

## Notes

- These skills are **brand-neutral**. If your business has a brand-voice guide or a banned-word list, point the skill at it and it'll apply it. If you have a pre-publish quality check, it'll run it at the end.
- The **17-part spine is fixed** — that's the proven structure. The skill changes the words inside it for each audience, never the order.
- The governing law never changes: **sell the emotion, not the thing.**
