"""Cut planning: trim dead space and pause-adjacent filler words.

Input: Deepgram word timings. Output: keep-intervals in source time (seconds)
plus a human-readable cut report. Nothing here touches CapCut — pure planning.

Conservative by design:
  - Only pauses long enough to be worth cutting are cut (a breath survives).
  - Fillers ("um"/"uh") are cut only when they sit next to a pause; a filler
    packed tightly between words stays, because cutting it would pop.
  - Every cut keeps PAD seconds of air on each side so speech never clips.
  - Retakes (repeated phrases) are DETECTED and REPORTED, never auto-cut.
"""

MAX_PAUSE = 0.7   # gaps longer than this get trimmed
PAD = 0.25        # air kept on each side of every cut
MIN_CUT = 0.3     # don't bother cutting less than this much silence
FILLER_WORDS = {"um", "uh", "uhm", "erm"}
FILLER_PAUSE = 0.3  # a filler is cut only if a neighbor gap exceeds this
FILLER_TRIM_PAD = 0.04


def _norm(word: str) -> str:
    return word.lower().strip(".,!?;:…'\"")


def plan_cuts(words, video_duration: float):
    """Returns (keeps, report) — keeps: [(start, end), ...] in source seconds."""
    report = {"fillers_cut": [], "pauses_cut": [], "lead_trim": None,
              "tail_trim": None, "retakes": find_retakes(words)}

    # Decide which fillers go: pause on either side
    kept_words, filler_cuts = [], []
    for i, w in enumerate(words):
        gap_before = w["start"] - (words[i - 1]["end"] if i else 0.0)
        gap_after = (words[i + 1]["start"] if i + 1 < len(words)
                     else video_duration) - w["end"]
        if _norm(w["word"]) in FILLER_WORDS and max(gap_before, gap_after) >= FILLER_PAUSE:
            filler_cuts.append((w["start"] - FILLER_TRIM_PAD,
                                w["end"] + FILLER_TRIM_PAD))
            report["fillers_cut"].append((w["start"], w["word"]))
        else:
            kept_words.append(w)

    if not kept_words:
        return [(0.0, video_duration)], report

    # Speech blocks over kept words; long gaps between blocks become cuts
    blocks = [[kept_words[0]["start"], kept_words[0]["end"]]]
    for w in kept_words[1:]:
        if w["start"] - blocks[-1][1] <= MAX_PAUSE:
            blocks[-1][1] = max(blocks[-1][1], w["end"])
        else:
            blocks.append([w["start"], w["end"]])

    keeps = []
    for start, end in blocks:
        s = max(0.0, start - PAD)
        e = min(video_duration, end + PAD)
        if keeps and s - keeps[-1][1] < MIN_CUT:
            keeps[-1][1] = e  # cut too small to be worth it: bridge it
        else:
            if keeps:
                report["pauses_cut"].append((keeps[-1][1], s))
            keeps.append([s, e])
    if keeps[0][0] > 0.05:
        report["lead_trim"] = keeps[0][0]
    if video_duration - keeps[-1][1] > 0.05:
        report["tail_trim"] = video_duration - keeps[-1][1]

    keeps = _subtract(keeps, filler_cuts)
    return [(s, e) for s, e in keeps if e - s > 0.2], report


def _subtract(keeps, cuts):
    out = []
    for s, e in keeps:
        spans = [[s, e]]
        for cs, ce in cuts:
            nxt = []
            for a, b in spans:
                if ce <= a or cs >= b:
                    nxt.append([a, b])
                else:
                    if cs > a:
                        nxt.append([a, cs])
                    if ce < b:
                        nxt.append([ce, b])
            spans = nxt
        out.extend(spans)
    return out


def find_retakes(words, ngram=4, window_s=25.0):
    """Repeated n-grams close in time = likely re-said lines. Report only.

    Near-repeats count too: each n-gram is also indexed with every single
    position wildcarded, so a one-word self-correction ("who you ARE in" ->
    "who you WERE in") still matches."""
    grams = {}
    hits = set()
    for i in range(len(words) - ngram + 1):
        toks = [_norm(w["word"]) for w in words[i:i + ngram]]
        keys = [" ".join(toks)] + [
            " ".join(toks[:k] + ["*"] + toks[k + 1:]) for k in range(ngram)]
        for key in keys:
            for j in grams.get(key, []):
                if 1.0 < words[i]["start"] - words[j]["start"] <= window_s:
                    hits.add((j, i))
            grams.setdefault(key, []).append(i)
    hits = sorted(hits)

    # Merge overlapping hit pairs into readable proposals
    merged = []
    for j, i in hits:
        if merged and j <= merged[-1]["first_idx"] + ngram:
            merged[-1]["first_end"] = max(merged[-1]["first_end"], j + ngram)
            merged[-1]["second_end"] = max(merged[-1]["second_end"], i + ngram)
            continue
        merged.append({"first_idx": j, "first_end": j + ngram,
                       "second_idx": i, "second_end": i + ngram})
    out = []
    for m in merged:
        out.append({
            "earlier_time": words[m["first_idx"]]["start"],
            "later_time": words[m["second_idx"]]["start"],
            "text": " ".join(w["word"] for w in
                             words[m["first_idx"]:m["first_end"]]),
        })
    return out


def format_report(keeps, report, video_duration: float) -> str:
    kept = sum(e - s for s, e in keeps)
    lines = [
        f"Source {video_duration:.1f}s -> tightened {kept:.1f}s "
        f"(cut {video_duration - kept:.1f}s across {len(keeps)} segments)",
    ]
    if report["lead_trim"]:
        lines.append(f"  lead-in trimmed: {report['lead_trim']:.1f}s")
    if report["tail_trim"]:
        lines.append(f"  tail trimmed: {report['tail_trim']:.1f}s")
    for a, b in report["pauses_cut"]:
        lines.append(f"  pause cut: {a:.1f}s -> {b:.1f}s ({b - a:.1f}s)")
    for t, w in report["fillers_cut"]:
        lines.append(f"  filler cut at {t:.1f}s: {w!r}")
    if report["retakes"]:
        lines.append("  RETAKE CANDIDATES (not cut - review):")
        for r in report["retakes"]:
            lines.append(f"    {r['earlier_time']:.1f}s then again at "
                         f"{r['later_time']:.1f}s: \"{r['text']}...\"")
    return "\n".join(lines)
