"""Phase 0: build a hello-world CapCut draft that opens and plays.

One synthetic video clip on one video track. Media staged into CapCut's
sandbox, timeline built by pyJianYingDraft, conformed to your reference format,
registered in root_meta_info.json. Run only with CapCut closed.

Usage: .venv/bin/python src/build_hello.py [--remove]
"""

import json
import os
import subprocess
import sys

import pyJianYingDraft as draft

from capcut_env import (
    PROJECTS_DIR,
    TOOL_DIR,
    assert_capcut_closed,
    assert_not_locked,
    atomic_write_json,
    clean_draft_dir,
    capcut_uuid,
    register_draft,
    stage_media,
    unregister_draft,
)
from conform import conform_draft_info
from meta_info import build_draft_meta_info, build_root_entry, media_bin_entry

DRAFT_NAME = "ZZTEST_hello_001"
SOURCE_CLIP = os.path.join(TOOL_DIR, "media", "ZZTEST_clip_001.mp4")


def main() -> None:
    assert_capcut_closed()
    draft_dir = os.path.join(PROJECTS_DIR, DRAFT_NAME)
    assert_not_locked(draft_dir)

    if "--remove" in sys.argv:
        unregister_draft(DRAFT_NAME)
        print(f"Unregistered {DRAFT_NAME} from root_meta_info.json.")
        print(f"Folder left in place for inspection: {draft_dir}")
        return

    staged = stage_media(SOURCE_CLIP)
    print(f"Staged media: {staged}")

    material = draft.VideoMaterial(staged)
    script = draft.ScriptFile(1080, 1920, 30, True)
    script.add_track(draft.TrackType.video)
    segment = draft.VideoSegment(
        material, draft.Timerange(0, material.duration)
    )
    script.add_segment(segment)

    bin_entry = media_bin_entry(
        staged, material.width, material.height, material.duration
    )
    draft_info = conform_draft_info(json.loads(script.dumps()), bin_entry["id"])

    meta = build_draft_meta_info(
        draft_name=DRAFT_NAME,
        draft_id=capcut_uuid(),
        bin_entries=[bin_entry],
        duration_us=draft_info["duration"],
        media_size_bytes=os.path.getsize(staged),
    )

    clean_draft_dir(draft_dir)
    os.makedirs(draft_dir)
    atomic_write_json(os.path.join(draft_dir, "draft_info.json"), draft_info)
    atomic_write_json(os.path.join(draft_dir, "draft_meta_info.json"), meta)
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", staged, "-frames:v", "1",
         os.path.join(draft_dir, "draft_cover.jpg")],
        check=True,
    )
    register_draft(build_root_entry(meta))

    print(f"Draft written and registered: {draft_dir}")
    print(f"Timeline: {draft_info['duration'] / 1_000_000:.1f}s, "
          f"{len(draft_info['tracks'])} track(s)")


if __name__ == "__main__":
    main()
