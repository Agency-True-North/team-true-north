"""Build draft_meta_info.json and the root_meta_info.json entry.

draft_meta_info is the draft's identity + media bin. A malformed media bin can
crash CapCut, so this is modeled field-for-field on a real CapCut draft
(including CapCut's own key spellings: `file_Path`,
`metetype`). Keep entries exactly in this shape.
"""

import os
import time
import uuid

from capcut_env import PROJECTS_DIR, now_us

# The seven media-bin buckets CapCut writes, in order. Type 0 holds video/photo.
_MATERIAL_BUCKET_TYPES = [0, 1, 2, 3, 6, 7, 8]


def media_bin_entry(staged_path: str, width: int, height: int, duration_us: int) -> dict:
    now_s = int(time.time())
    return {
        "ai_group_type": "",
        "create_time": now_s,
        "duration": duration_us,
        "enter_from": 0,
        "extra_info": os.path.basename(staged_path),
        "file_Path": staged_path,
        "height": height,
        "id": str(uuid.uuid4()),  # media-bin ids are lowercase in CapCut's own drafts
        "import_time": now_s,
        "import_time_ms": now_us(),
        "item_source": 1,
        "md5": "",
        "metetype": "video",
        "roughcut_time_range": {"duration": duration_us, "start": 0},
        "sub_time_range": {"duration": -1, "start": -1},
        "type": 0,
        "width": width,
    }


def build_draft_meta_info(
    draft_name: str,
    draft_id: str,
    bin_entries: list,
    duration_us: int,
    media_size_bytes: int,
) -> dict:
    fold_path = os.path.join(PROJECTS_DIR, draft_name)
    now = now_us()
    return {
        "cloud_draft_cover": False,
        "cloud_draft_sync": False,
        "cloud_package_completed_time": "",
        "draft_cloud_capcut_purchase_info": "",
        "draft_cloud_last_action_download": False,
        "draft_cloud_package_type": "",
        "draft_cloud_purchase_info": "",
        "draft_cloud_template_id": "",
        "draft_cloud_tutorial_info": "",
        "draft_cloud_videocut_purchase_info": "",
        "draft_cover": "draft_cover.jpg",
        "draft_deeplink_url": "",
        "draft_enterprise_info": {
            "draft_enterprise_extra": "",
            "draft_enterprise_id": "",
            "draft_enterprise_name": "",
            "enterprise_material": [],
        },
        "draft_fold_path": fold_path,
        "draft_id": draft_id,
        "draft_is_ae_produce": False,
        "draft_is_ai_packaging_used": False,
        "draft_is_ai_shorts": False,
        "draft_is_ai_translate": False,
        "draft_is_article_video_draft": False,
        "draft_is_cloud_temp_draft": False,
        "draft_is_from_deeplink": "false",
        "draft_is_invisible": False,
        "draft_is_pippit_draft": False,
        "draft_is_web_article_video": False,
        "draft_materials": [
            {"type": t, "value": (bin_entries if t == 0 else [])}
            for t in _MATERIAL_BUCKET_TYPES
        ],
        "draft_materials_copied_info": [],
        "draft_name": draft_name,
        "draft_need_rename_folder": False,
        "draft_new_version": "",
        "draft_removable_storage_device": "",
        "draft_root_path": PROJECTS_DIR,
        "draft_segment_extra_info": [],
        "draft_timeline_materials_size_": media_size_bytes,
        "draft_type": "",
        "draft_web_article_video_enter_from": "",
        "pippit_avatar_url": "",
        "pippit_extra_info": "",
        "pippit_id": "",
        "pippit_user_name": "",
        "tm_draft_cloud_completed": "",
        "tm_draft_cloud_entry_id": -1,
        "tm_draft_cloud_modified": 0,
        "tm_draft_cloud_parent_entry_id": -1,
        "tm_draft_cloud_space_id": -1,
        "tm_draft_cloud_user_id": -1,
        "tm_draft_create": now,
        "tm_draft_modified": now,
        "tm_draft_removed": 0,
        "tm_duration": duration_us,
    }


def build_root_entry(meta: dict) -> dict:
    """root_meta_info.json all_draft_store entry, mirroring the reference draft's shape."""
    fold_path = meta["draft_fold_path"]
    return {
        "cloud_draft_cover": False,
        "cloud_draft_sync": False,
        "draft_cloud_last_action_download": False,
        "draft_cloud_purchase_info": "",
        "draft_cloud_template_id": "",
        "draft_cloud_tutorial_info": "",
        "draft_cloud_videocut_purchase_info": "",
        "draft_cover": os.path.join(fold_path, "draft_cover.jpg"),
        "draft_fold_path": fold_path,
        "draft_id": meta["draft_id"],
        "draft_is_ai_shorts": False,
        "draft_is_cloud_temp_draft": False,
        "draft_is_invisible": False,
        "draft_is_pippit_draft": False,
        "draft_is_web_article_video": False,
        "draft_json_file": os.path.join(fold_path, "draft_info.json"),
        "draft_name": meta["draft_name"],
        "draft_new_version": "",
        "draft_root_path": PROJECTS_DIR,
        "draft_timeline_materials_size": meta["draft_timeline_materials_size_"],
        "draft_type": "",
        "draft_web_article_video_enter_from": "",
        "pippit_avatar_url": "",
        "pippit_extra_info": "",
        "pippit_id": "",
        "pippit_user_name": "",
        "streaming_edit_draft_ready": True,
        "tm_draft_cloud_completed": "",
        "tm_draft_cloud_entry_id": -1,
        "tm_draft_cloud_modified": 0,
        "tm_draft_cloud_parent_entry_id": -1,
        "tm_draft_cloud_space_id": -1,
        "tm_draft_cloud_user_id": -1,
        "tm_draft_create": meta["tm_draft_create"],
        "tm_draft_modified": meta["tm_draft_modified"],
        "tm_draft_removed": 0,
        "tm_duration": meta["tm_duration"],
    }
