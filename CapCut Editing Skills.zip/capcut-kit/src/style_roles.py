"""Style ROLES and the user's style map.

Rough-cut never requires a specific font, sound, animation, or sticker.
It styles by ROLE (hook font, annotation entry sound, ...) and each role
is filled by whatever the user picked and put in their STYLE_SETUP draft.

style_map.json at the kit root maps role -> the NAME of the user's pick.
Names are matched case-insensitively as substrings against the harvest in
reference/ (so "keyboard" finds "Keyboard Typing 01"). A role whose named
item isn't in the harvest resolves to nothing and the builders simply skip
it — silent entry, plain entry, no sticker. Missing assets never block a
setup or a build.

DEFAULT_STYLE_MAP is only the kit's starter look, used when
style_map.json doesn't exist yet. src/harvest_style.py creates
style_map.json from whatever the user actually harvested. To restyle
later: put the new font/sound/animation/sticker in STYLE_SETUP once,
re-run src/harvest_style.py, and set its name in style_map.json.
"""

import json
import os

KIT_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
STYLE_MAP_PATH = os.path.join(KIT_ROOT, "style_map.json")

DEFAULT_STYLE_MAP = {
    # Master switches, set from the style interview. False = the user
    # doesn't want that layer at all: no sounds placed / all text enters
    # plain. Their videos build exactly the same otherwise.
    "use_sfx": True,
    "use_animations": True,
    "fonts": {
        "hook": "Larken",        # the big opening line (serif look)
        "body": "Ugly Dave",     # sub-line, annotations, captions, labels
        "pop": "ZY Modern",      # emphasized caption words
    },
    "animations": {
        "hook": "Typing Cursor",  # how the hook enters
        "text_in": "Bounce In",   # how sub-line and annotations enter
    },
    "sfx": {
        "typing": "Keyboard Typing",       # hook entry
        "glitter": "Glitter",              # sub-line entry
        "swoosh": "Swoosh",                # a text layer exiting
        "mouse_click": "Mouse click",      # numbered-list items entering
        "bell": "Bell",                    # emphasis annotation
        "pop_whoosh": "Pop Whoosh",        # hot-take label entry
        "pop": "Pop. Sound to open",       # default annotation entry
    },
    "stickers": {
        "underline": "Two White Underline",  # under hot-take labels
    },
}

# Plain-language role descriptions, used in harvest_style.py's report.
ROLE_NOTES = {
    ("fonts", "hook"): "the big opening line",
    ("fonts", "body"): "sub-line, annotations, and captions",
    ("fonts", "pop"): "emphasized caption words",
    ("animations", "hook"): "how the hook text enters",
    ("animations", "text_in"): "how sub-lines and annotations enter",
    ("sfx", "typing"): "plays as the hook enters",
    ("sfx", "glitter"): "plays as the sub-line enters",
    ("sfx", "swoosh"): "plays as a text layer exits",
    ("sfx", "mouse_click"): "plays on numbered-list items",
    ("sfx", "bell"): "plays on an emphasis annotation",
    ("sfx", "pop_whoosh"): "plays as a hot-take label enters",
    ("sfx", "pop"): "plays as a normal annotation enters",
    ("stickers", "underline"): "drawn under hot-take labels",
}


def _norm(s):
    """Lowercase, punctuation stripped, spaces collapsed — so a user-typed
    "pop sound to open" matches CapCut's "Pop. Sound to open the lid"."""
    return " ".join("".join(c if c.isalnum() else " " for c in s.lower()).split())


def match_name(wanted, names):
    """The harvested name best matching `wanted`, or None.

    Case- and punctuation-insensitive; exact match wins, then substring
    either way (the user's short name inside CapCut's long one, or vice
    versa)."""
    if not wanted:
        return None
    w = _norm(wanted)
    if not w:
        return None
    for n in names:
        if n and _norm(n) == w:
            return n
    for n in names:
        if n and (w in _norm(n) or _norm(n) in w):
            return n
    return None


def load_style_map():
    """style_map.json overlaid on the defaults (so a partial file, or one
    from an older kit missing a newer role, still fills every role)."""
    merged = {cat: (dict(roles) if isinstance(roles, dict) else roles)
              for cat, roles in DEFAULT_STYLE_MAP.items()}
    if os.path.exists(STYLE_MAP_PATH):
        with open(STYLE_MAP_PATH, encoding="utf-8") as f:
            user = json.load(f)
        for cat, roles in user.items():
            if cat not in merged:
                continue
            if isinstance(roles, dict) and isinstance(merged[cat], dict):
                merged[cat].update(roles)
            else:
                merged[cat] = roles
    return merged


def save_style_map(style_map):
    with open(STYLE_MAP_PATH, "w", encoding="utf-8") as f:
        json.dump(style_map, f, indent=2)
        f.write("\n")
