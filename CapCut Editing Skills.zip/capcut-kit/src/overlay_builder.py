"""Sound-effect and sticker builders, cloned from the harvested style draft.

Everything is deep-copied from reference/sound_effects.json and
reference/stickers.json (harvested from your STYLE_SETUP draft by
src/harvest_run001.py), so every field — trim, volume, linked speeds/beats/
channel-mapping materials — is exactly what your CapCut wrote. We only
re-id and re-time.
"""

import copy
import json
import os

from capcut_env import REFERENCE_DIR, capcut_uuid
from style_presets import SFX

_AUDIO_RENDER_INDEX_BASE = 0
_STICKER_RENDER_INDEX_BASE = 14500


def _load(name):
    with open(os.path.join(REFERENCE_DIR, name), encoding="utf-8") as f:
        return json.load(f)


def _clone_with_extras(entry):
    """Deep-copy an entry's material + segment + linked extras, all re-id'd,
    keeping extra_material_refs order and linkage intact."""
    material = copy.deepcopy(entry["material"])
    segment = copy.deepcopy(entry["segment"])
    extras = copy.deepcopy(entry.get("extras", {}))

    id_map = {material["id"]: capcut_uuid()}
    for mat in extras.values():
        id_map[mat["id"]] = capcut_uuid()
    for mat in [material] + list(extras.values()):
        mat["id"] = id_map[mat["id"]]

    segment["id"] = capcut_uuid()
    segment["material_id"] = material["id"]
    segment["extra_material_refs"] = [
        id_map[r] for r in segment.get("extra_material_refs", []) if r in id_map]
    return material, segment, extras


def audio_track(segments):
    return {"id": capcut_uuid(), "type": "audio", "segments": segments,
            "flag": 0, "attribute": 0, "name": "", "is_default_name": True}


def sticker_track(segments):
    return {"id": capcut_uuid(), "type": "sticker", "segments": segments,
            "flag": 0, "attribute": 0, "name": "", "is_default_name": True}


class SfxBuilder:
    """Sound effects by semantic name (style_presets.SFX keys)."""

    def __init__(self):
        self._harvested = _load("sound_effects.json")
        self._render_index = _AUDIO_RENDER_INDEX_BASE

    def make_sfx(self, key, start_us, max_end_us=None):
        """One sound effect at start_us. Duration and volume are her trim.
        Returns (audio_material, segment, extras {category: [materials]})."""
        entry = self._harvested[SFX[key]["effect_id"]]
        material, segment, extras = _clone_with_extras(entry)

        duration = segment["target_timerange"]["duration"]
        if max_end_us is not None:
            duration = max(0, min(duration, max_end_us - start_us))
            if segment.get("source_timerange"):
                segment["source_timerange"]["duration"] = duration
        segment["target_timerange"] = {"start": start_us, "duration": duration}
        self._render_index += 1
        segment["render_index"] = self._render_index

        return material, segment, {cat: [mat] for cat, mat in extras.items()}


class StickerBuilder:
    """Stickers by sticker_id (keys of reference/stickers.json)."""

    def __init__(self):
        self._harvested = _load("stickers.json")
        self._render_index = _STICKER_RENDER_INDEX_BASE

    def make_sticker(self, sticker_id, start_us, duration_us, clip=None):
        """One sticker segment. clip (transform/scale/rotation) defaults to
        her harvested placement; pass a dict to override fields.
        Returns (sticker_material, segment, extras {category: [materials]})."""
        entry = self._harvested[str(sticker_id)]
        material, segment, extras = _clone_with_extras(entry)

        segment["target_timerange"] = {"start": start_us, "duration": duration_us}
        if clip:
            segment["clip"].update(copy.deepcopy(clip))
        self._render_index += 1
        segment["render_index"] = self._render_index

        return material, segment, {cat: [mat] for cat, mat in extras.items()}
