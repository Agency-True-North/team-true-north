"""Style-test draft — the 3 default text layers on a test clip.

Builds sample text (hook + yellow sub-line + annotation list)
plus word-by-word captions, using the locked presets, so the creator can compare
the generated look 1:1 against the reference video in CapCut.

Usage: .venv/bin/python src/build_style_test.py [--remove]
"""

import json
import os
import subprocess
import sys

import pyJianYingDraft as draft

from capcut_env import (
    PROJECTS_DIR,
    TOOL_DIR,
    assert_capcut_closed,
    assert_not_locked,
    atomic_write_json,
    clean_draft_dir,
    capcut_uuid,
    register_draft,
    stage_media,
    unregister_draft,
)
from conform import conform_draft_info
from meta_info import build_draft_meta_info, build_root_entry, media_bin_entry
from style_presets import PRESETS
from text_builder import TextBuilder

DRAFT_NAME = "ZZTEST_style_001"
SOURCE_CLIP = os.path.join(TOOL_DIR, "media", "ZZTEST_clip_001.mp4")
SEC = 1_000_000

HOOK = "Couples Money Habits"
HOOK_UNDERLINE = [(8, 13)]  # "Money"
SUBLINE = "to avoid tension & build wealth"
ANNOTATION = "1. once weekly money meeting\n2.\n3.\n4."
CAPTION_WORDS = ["once", "weekly", "meeting", "works", "best", "for", "us"]


def text_track(segments):
    return {
        "id": capcut_uuid(),
        "type": "text",
        "segments": segments,
        "flag": 0,
        "attribute": 0,
        "name": "",
        "is_default_name": True,
    }


def main() -> None:
    assert_capcut_closed()
    draft_dir = os.path.join(PROJECTS_DIR, DRAFT_NAME)
    assert_not_locked(draft_dir)

    if "--remove" in sys.argv:
        unregister_draft(DRAFT_NAME)
        print(f"Unregistered {DRAFT_NAME}.")
        return

    staged = stage_media(SOURCE_CLIP)
    material = draft.VideoMaterial(staged)
    clip_dur = material.duration

    script = draft.ScriptFile(1080, 1920, 30, True)
    script.add_track(draft.TrackType.video)
    script.add_segment(draft.VideoSegment(material, draft.Timerange(0, clip_dur)))

    bin_entry = media_bin_entry(staged, material.width, material.height, clip_dur)
    draft_info = conform_draft_info(json.loads(script.dumps()), bin_entry["id"])

    tb = TextBuilder()
    all_extras = []

    def add_layer(elements):
        segs = []
        for m, s, e in elements:
            draft_info["materials"]["texts"].append(m)
            all_extras.append(e)
            segs.append(s)
        draft_info["tracks"].append(text_track(segs))

    hook_dur = min(6 * SEC, clip_dur)  # hook holds ~5-10s, then annotations take its spot
    add_layer([tb.make_text(HOOK, PRESETS["hook"], 0, hook_dur,
                            underline_spans=HOOK_UNDERLINE)])
    add_layer([tb.make_text(SUBLINE, PRESETS["subline"], 0, hook_dur)])
    add_layer([tb.make_text(ANNOTATION, PRESETS["annotation"], hook_dur,
                            clip_dur - hook_dur)])

    word_dur = int(0.55 * SEC)
    words = [(w, i * word_dur, word_dur) for i, w in enumerate(CAPTION_WORDS)]
    mats, segs, extras = tb.make_word_captions(words, PRESETS["caption"])
    draft_info["materials"]["texts"].extend(mats)
    all_extras.append(extras)
    draft_info["tracks"].append(text_track(segs))

    for e in all_extras:
        for category, items in e.items():
            draft_info["materials"][category].extend(items)

    meta = build_draft_meta_info(
        draft_name=DRAFT_NAME,
        draft_id=capcut_uuid(),
        bin_entries=[bin_entry],
        duration_us=draft_info["duration"],
        media_size_bytes=os.path.getsize(staged),
    )

    clean_draft_dir(draft_dir)
    os.makedirs(draft_dir)
    atomic_write_json(os.path.join(draft_dir, "draft_info.json"), draft_info)
    atomic_write_json(os.path.join(draft_dir, "draft_meta_info.json"), meta)
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", staged, "-frames:v", "1",
         os.path.join(draft_dir, "draft_cover.jpg")],
        check=True,
    )
    register_draft(build_root_entry(meta))

    n_texts = len(draft_info["materials"]["texts"])
    print(f"Draft written and registered: {draft_dir}")
    print(f"{len(draft_info['tracks'])} tracks, {n_texts} text elements, "
          f"{draft_info['duration'] / SEC:.1f}s")


if __name__ == "__main__":
    main()
