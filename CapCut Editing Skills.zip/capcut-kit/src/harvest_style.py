"""Harvest the STYLE_SETUP draft into reference/ snapshots (setup step).

Rough-cut styles text, sounds, and stickers by cloning real entries from a
draft YOUR CapCut wrote. During setup you build one draft (default name
STYLE_SETUP) and apply each needed font, animation, sound effect, and
sticker once — that pulls each resource into your CapCut's local cache and
records its exact format in the draft file. Then:

  .venv/bin/python src/harvest_style.py STYLE_SETUP

reads that draft and produces:
  reference/fonts.json           full fonts[] dicts by title
  reference/animations.json      one full material_animation per move
  reference/sound_effects.json   audio material + example segment each
  reference/stickers.json        sticker material + example segment each
  reference/text_template.json   one text material+segment used as the
                                 template every text layer is cloned from
  reference/audio/<effect_id>.*  copies of the cached sfx files

Read-only against the CapCut library (safe with CapCut open, but the draft
must be saved). Ends with a checklist of what was found vs. what rough-cut
needs; re-run after adding anything missing. Long-cut does not need this.
"""

import json
import shutil
import sys
from pathlib import Path

from capcut_env import REFERENCE_DIR, ROOT_META
from style_presets_requirements import (
    REQUIRED_ANIMATIONS,
    REQUIRED_FONTS,
    REQUIRED_SFX,
    REQUIRED_STICKERS,
)

REF = Path(REFERENCE_DIR)


def find_draft_info(name: str) -> Path:
    with open(ROOT_META, encoding="utf-8") as f:
        root = json.load(f)
    for entry in root["all_draft_store"]:
        if entry.get("draft_name") == name:
            return Path(entry["draft_fold_path"]) / "draft_info.json"
    names = [e.get("draft_name") for e in root["all_draft_store"]][:15]
    raise SystemExit(
        f'No draft named "{name}" in your CapCut library.\n'
        f"Drafts found: {names}"
    )


def main():
    name = sys.argv[1] if len(sys.argv) > 1 else "STYLE_SETUP"
    d = json.loads(find_draft_info(name).read_text(encoding="utf-8"))
    m = d["materials"]

    REF.mkdir(exist_ok=True)

    texts = {t["id"]: t for t in m.get("texts", [])}
    audios = {a["id"]: a for a in m.get("audios", [])}
    stickers = {s["id"]: s for s in m.get("stickers", [])}
    anims = {a["id"]: a for a in m.get("material_animations", [])}

    # --- fonts: full fonts[] entry per title ---
    fonts = {}
    for t in m.get("texts", []):
        for f in t.get("fonts", []):
            if f.get("title") and f["title"] not in fonts:
                fonts[f["title"]] = f
    (REF / "fonts.json").write_text(json.dumps(fonts, indent=1))

    # --- animations: one full material_animation per distinct move, keyed
    # "<name> (<track kind>)" because text and sticker versions of the same
    # move are different resource ids.
    def seg_index():
        idx = {}
        for tr in d["tracks"]:
            for s in tr.get("segments", []):
                for r in s.get("extra_material_refs", []):
                    if r in anims:
                        idx[r] = (tr["type"], s)
        return idx

    animations = {}
    for aid, (kind, seg) in seg_index().items():
        mat = anims[aid]
        for an in mat.get("animations", []):
            key = f"{an['name']} ({kind})"
            if key not in animations:
                animations[key] = {"carried_by": kind, "material": mat}
    (REF / "animations.json").write_text(json.dumps(animations, indent=1))

    # Resolve a segment's extra_material_refs to {category: material} so
    # builders can clone the full linked set (audio needs speeds, beats,
    # placeholder_infos, sound_channel_mappings, vocal_separations).
    by_id = {}
    for cat, items in m.items():
        if isinstance(items, list):
            for it in items:
                if isinstance(it, dict) and "id" in it:
                    by_id[it["id"]] = (cat, it)

    def extras_of(seg):
        out = {}
        for r in seg.get("extra_material_refs", []):
            if r in by_id and r not in anims:
                cat, mat = by_id[r]
                out[cat] = mat
        return out

    # --- sound effects: unique by effect_id, with one full example segment ---
    sfx = {}
    for tr in d["tracks"]:
        if tr["type"] != "audio":
            continue
        for s in tr.get("segments", []):
            a = audios.get(s["material_id"])
            if not a:
                continue
            eid = a.get("effect_id")
            if eid and eid not in sfx:
                sfx[eid] = {"name": a.get("name"), "material": a,
                            "segment": s, "extras": extras_of(s)}
    (REF / "sound_effects.json").write_text(json.dumps(sfx, indent=1))

    audio_dir = REF / "audio"
    audio_dir.mkdir(exist_ok=True)
    for eid, entry in sfx.items():
        src = Path(entry["material"]["path"])
        if src.exists():
            shutil.copy2(src, audio_dir / f"{eid}{src.suffix}")

    # --- stickers: material + one full example segment ---
    stk = {}
    for tr in d["tracks"]:
        if tr["type"] != "sticker":
            continue
        for s in tr.get("segments", []):
            mat = stickers.get(s["material_id"])
            if mat and mat["sticker_id"] not in stk:
                stk[mat["sticker_id"]] = {"name": mat.get("name"), "material": mat,
                                          "segment": s, "extras": extras_of(s)}
    (REF / "stickers.json").write_text(json.dumps(stk, indent=1))

    # --- text template: any one text box, cloned as the base for every
    # text layer the builders create (they overwrite text/font/size/color/
    # position/timing, so which box doesn't matter).
    template = None
    for tr in d["tracks"]:
        if tr["type"] != "text":
            continue
        for s in tr.get("segments", []):
            t = texts.get(s["material_id"])
            if t:
                template = {"material": t, "segment": s}
                break
        if template:
            break
    if template:
        (REF / "text_template.json").write_text(json.dumps(template, indent=1))

    # --- checklist against what rough-cut needs ---
    print(f'Harvested from draft "{name}":\n')
    ok = True

    def check(label, needed, found):
        nonlocal ok
        for item in needed:
            if any(item.lower() in f.lower() for f in found):
                print(f"  [ok] {label}: {item}")
            else:
                print(f"  [MISSING] {label}: {item}")
                ok = False

    check("font", REQUIRED_FONTS, list(fonts))
    check("animation", REQUIRED_ANIMATIONS, list(animations))
    check("sound", REQUIRED_SFX, [v["name"] or "" for v in sfx.values()])
    check("sticker", REQUIRED_STICKERS, [v["name"] or "" for v in stk.values()])
    if not template:
        print("  [MISSING] a text box (any text box at all)")
        ok = False
    else:
        print("  [ok] text template")

    if ok:
        print("\nEverything rough-cut needs is harvested. Style setup complete.")
    else:
        print(
            "\nSome pieces are missing. Open the draft in CapCut, add each "
            "MISSING item (put it anywhere on the timeline), save, close "
            "CapCut, and re-run this script."
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
