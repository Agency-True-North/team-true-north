"""What the STYLE_SETUP draft must contain for rough-cut to work.

harvest_style.py checks its harvest against these lists (case-insensitive
substring match) and reports anything missing. START-HERE.md walks the
human through applying each one in CapCut.

If you customize the style (different fonts etc.), update these lists AND
the titles/ids in style_presets.py together.
"""

# Font titles as they appear in CapCut's font browser.
REQUIRED_FONTS = ["Larken", "Ugly Dave", "ZY Modern"]

# Text in-animations; harvest keys are "<name> (text)".
REQUIRED_ANIMATIONS = ["Bounce In (text)", "Typing Cursor (text)"]

# Sound effect names (substring is enough — CapCut names can be long).
REQUIRED_SFX = [
    "Keyboard Typing 01",
    "Glitter glitter",
    "Title Swoosh",
    "Mouse click 1",
    "Bell 02",
    "Pop Whoosh",
    "Pop. Sound to open the lid",
]

# Stickers (the white double-underline used under hot-take labels).
REQUIRED_STICKERS = ["Two White Underline"]
