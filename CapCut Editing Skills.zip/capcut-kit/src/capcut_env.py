"""CapCut environment: paths, safety checks, backups, draft registration.

Everything that touches your real CapCut library goes through this module.
Rules (from the build brief, learned the hard way):
  - Never write while CapCut is running.
  - Respect .locked files.
  - Back up root_meta_info.json before every write to it.
  - Media must live inside CapCut's sandbox (ImportMedias) or it won't load.
"""

import json
import os
import shutil
import subprocess
import time
import uuid

HOME = os.path.expanduser("~")
PROJECTS_DIR = os.path.join(
    HOME, "Movies/CapCut/User Data/Projects/com.lveditor.draft"
)
ROOT_META = os.path.join(PROJECTS_DIR, "root_meta_info.json")
IMPORT_MEDIAS = os.path.join(
    HOME,
    "Library/Containers/com.lemon.lvoverseas/Data/Movies/CapCut/User Data/Cache/ImportMedias",
)
TOOL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BACKUPS_DIR = os.path.join(TOOL_DIR, "backups")
REFERENCE_DIR = os.path.join(TOOL_DIR, "reference")


def capcut_uuid() -> str:
    """CapCut-style id: uppercase, dashed."""
    return str(uuid.uuid4()).upper()


def now_us() -> int:
    return int(time.time() * 1_000_000)


def assert_capcut_closed() -> None:
    # pgrep -x can miss CapCut's process; match the full binary path instead.
    result = subprocess.run(
        ["pgrep", "-f", "CapCut.app/Contents/MacOS/CapCut"], capture_output=True
    )
    if result.returncode == 0:
        raise RuntimeError(
            "CapCut is running. Close it before writing any draft files."
        )


def assert_not_locked(draft_dir: str) -> None:
    if not os.path.isdir(draft_dir):
        return
    locked = [f for f in os.listdir(draft_dir) if f.endswith(".locked")]
    if locked:
        raise RuntimeError(f"{draft_dir} has lock files: {locked}. Not touching it.")


def clean_draft_dir(draft_dir: str) -> None:
    """Remove a draft folder entirely before a rebuild.

    Once CapCut opens a draft it writes auxiliary files (attachments,
    timelines, .bak, .locked) tied to that version's ids; regenerating
    draft_info.json around them makes the draft unopenable. Rebuilds must
    start from an empty folder. Only ZZTEST_ drafts may be wiped.
    """
    if not os.path.isdir(draft_dir):
        return
    if not os.path.basename(draft_dir).startswith("ZZTEST_"):
        raise RuntimeError(f"Refusing to wipe non-test draft: {draft_dir}")
    assert_capcut_closed()
    shutil.rmtree(draft_dir)


def backup_root_meta() -> str:
    os.makedirs(BACKUPS_DIR, exist_ok=True)
    stamp = time.strftime("%Y%m%d-%H%M%S")
    dest = os.path.join(BACKUPS_DIR, f"root_meta_info.{stamp}.json")
    shutil.copy2(ROOT_META, dest)
    return dest


def atomic_write_json(path: str, data: dict) -> None:
    tmp = path + ".tmp-capcut-tool"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, separators=(",", ":"))
    os.replace(tmp, path)


def stage_media(src_path: str) -> str:
    """Copy a media file into CapCut's sandbox import cache. Returns staged path."""
    if not os.path.isdir(IMPORT_MEDIAS):
        raise RuntimeError(f"ImportMedias folder not found: {IMPORT_MEDIAS}")
    dest = os.path.join(IMPORT_MEDIAS, os.path.basename(src_path))
    if os.path.exists(dest) and os.path.getsize(dest) == os.path.getsize(src_path):
        return dest
    shutil.copy2(src_path, dest)
    return dest


def register_draft(entry: dict) -> None:
    """Add one draft entry to root_meta_info.json (backed up first, atomic write).

    If an entry with the same draft_name exists, it is replaced so reruns
    don't pile up duplicates.
    """
    assert_capcut_closed()
    backup_root_meta()
    with open(ROOT_META, encoding="utf-8") as f:
        root = json.load(f)
    store = root["all_draft_store"]
    store[:] = [e for e in store if e.get("draft_name") != entry["draft_name"]]
    store.insert(0, entry)
    atomic_write_json(ROOT_META, root)


def unregister_draft(draft_name: str) -> None:
    assert_capcut_closed()
    backup_root_meta()
    with open(ROOT_META, encoding="utf-8") as f:
        root = json.load(f)
    root["all_draft_store"] = [
        e for e in root["all_draft_store"] if e.get("draft_name") != draft_name
    ]
    atomic_write_json(ROOT_META, root)
