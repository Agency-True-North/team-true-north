"""Tightened draft: dead space + pause-adjacent fillers cut, captions retimed.

The video becomes one segment per keep-interval (all from the same staged
source, so every cut is reversible in CapCut by dragging segment edges).
Caption words are mapped through the cuts; words falling inside a cut
(fillers) disappear with their audio.

Usage: .venv/bin/python src/build_tightened.py <video path> [draft name]
"""

import json
import os
import subprocess
import sys

import pyJianYingDraft as draft

from capcut_env import (
    PROJECTS_DIR,
    assert_capcut_closed,
    assert_not_locked,
    atomic_write_json,
    capcut_uuid,
    clean_draft_dir,
    register_draft,
    stage_media,
)
from conform import conform_draft_info
from meta_info import build_draft_meta_info, build_root_entry, media_bin_entry
from style_presets import PRESETS
from text_builder import TextBuilder
from tighten import format_report, plan_cuts
from transcribe import transcribe
from build_captioned import caption_word, MAX_WORD_HOLD_GAP

SEC = 1_000_000


class CutTimeline:
    """Maps source seconds -> output seconds across keep-intervals."""

    def __init__(self, keeps):
        self.keeps = keeps
        self.offsets = []
        t = 0.0
        for s, e in keeps:
            self.offsets.append(t - s)
            t += e - s
        self.duration = t

    def map(self, src: float):
        for (s, e), off in zip(self.keeps, self.offsets):
            if s <= src <= e:
                return src + off
        return None


def retimed_captions(words, timeline):
    out = []
    for i, w in enumerate(words):
        text = caption_word(w["word"])
        start = timeline.map(w["start"])
        if not text or start is None:
            continue
        end_src = min(w["end"] + MAX_WORD_HOLD_GAP,
                      words[i + 1]["start"] if i + 1 < len(words) else w["end"] + MAX_WORD_HOLD_GAP)
        end = timeline.map(end_src) or timeline.map(w["end"]) or (start + 0.2)
        if end > start:
            out.append((text, int(start * SEC), int((end - start) * SEC)))
    return out


def build_tightened_draft(video_path: str, draft_name: str) -> str:
    assert_capcut_closed()
    draft_dir = os.path.join(PROJECTS_DIR, draft_name)
    assert_not_locked(draft_dir)

    transcript = transcribe(video_path)
    staged = stage_media(video_path)
    material = draft.VideoMaterial(staged)
    video_duration_s = material.duration / SEC

    keeps, report = plan_cuts(transcript["words"], video_duration_s)
    timeline = CutTimeline(keeps)
    print(format_report(keeps, report, video_duration_s))

    script = draft.ScriptFile(1080, 1920, 30, True)
    script.add_track(draft.TrackType.video)
    target = 0
    for s, e in keeps:
        dur = int((e - s) * SEC)
        script.add_segment(draft.VideoSegment(
            material,
            draft.Timerange(target, dur),
            source_timerange=draft.Timerange(int(s * SEC), dur),
        ))
        target += dur

    bin_entry = media_bin_entry(
        staged, material.width, material.height, material.duration
    )
    draft_info = conform_draft_info(json.loads(script.dumps()), bin_entry["id"])

    tb = TextBuilder()
    timings = retimed_captions(transcript["words"], timeline)
    mats, segs, extras = tb.make_word_captions(timings, PRESETS["caption"])
    draft_info["materials"]["texts"].extend(mats)
    draft_info["materials"]["material_animations"].extend(
        extras["material_animations"]
    )
    draft_info["tracks"].append({
        "id": capcut_uuid(), "type": "text", "segments": segs,
        "flag": 0, "attribute": 0, "name": "", "is_default_name": True,
    })

    meta = build_draft_meta_info(
        draft_name=draft_name,
        draft_id=capcut_uuid(),
        bin_entries=[bin_entry],
        duration_us=draft_info["duration"],
        media_size_bytes=os.path.getsize(staged),
    )

    clean_draft_dir(draft_dir)
    os.makedirs(draft_dir)
    atomic_write_json(os.path.join(draft_dir, "draft_info.json"), draft_info)
    atomic_write_json(os.path.join(draft_dir, "draft_meta_info.json"), meta)
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", staged, "-frames:v", "1",
         os.path.join(draft_dir, "draft_cover.jpg")],
        check=True,
    )
    register_draft(build_root_entry(meta))
    print(f"Draft written and registered: {draft_dir}")
    print(f"{len(keeps)} video segments, {len(timings)} caption words, "
          f"{timeline.duration:.1f}s output")
    return draft_dir


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    name = sys.argv[2] if len(sys.argv) > 2 else (
        "ZZTEST_" + os.path.splitext(os.path.basename(sys.argv[1]))[0] + "_tight"
    )
    build_tightened_draft(sys.argv[1], name)
