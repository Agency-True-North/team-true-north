"""The full pipeline draft: tightened video + captions + hook + sub-line +
timed annotations + v2 polish (animations, sound effects, hot takes, pop
words). Runs only on APPROVED proposals (a JSON file or dict that the creator has
signed off on) — this module never invents content.

Timing model:
  - Hook: 0 -> HOOK_SECONDS, types itself in (Typing Cursor + typing sfx),
    Title Swoosh as it exits.
  - Yellow sub-line: bounces in when the hook finishes typing (glitter sfx),
    holds until the hook exits.
  - Annotations: at their transcript anchor (mapped through cuts), never
    before the hook exits; each holds until the next one or ANNOTATION_MAX.
    Bounce In + pop on entry; numbered list items ("1. ...") get the mouse
    click instead (her standing rule).
  - Hot takes (approved["hot_takes"], only proposed when instructed): the
    tilted yellow label ("hot take" / "inner thoughts" / "hear me") + white
    double-underline sticker over an annotation-styled line, Pop Whoosh on
    entry, exactly the designed placement.
  - Pop words (approved["pop_words"]): caption words re-styled in ZY Modern.
  - B-roll (approved["broll"], entries with a "path"): muted overlay video
    segments at their transcript anchor, 1-3s, full canvas, staged into the
    sandbox like the main clip. Entries without a path are film-this ideas
    and are never placed.

Usage:
  .venv/bin/python src/build_full.py <video path> <approved.json> [draft name]
"""

import json
import os
import re
import subprocess
import sys

import pyJianYingDraft as draft

from capcut_env import (
    PROJECTS_DIR,
    assert_capcut_closed,
    assert_not_locked,
    atomic_write_json,
    capcut_uuid,
    clean_draft_dir,
    register_draft,
    stage_media,
)
from build_captioned import caption_word
from conform import conform_draft_info
from meta_info import build_draft_meta_info, build_root_entry, media_bin_entry
from overlay_builder import SfxBuilder, StickerBuilder, audio_track, sticker_track
from style_presets import LAYER_ANIMATIONS, PRESETS, SFX
from text_builder import TextBuilder
from tighten import format_report, plan_cuts
from transcribe import transcribe
from build_tightened import CutTimeline, retimed_captions

SEC = 1_000_000
HOOK_SECONDS = 6.0
ANNOTATION_MAX = 10.0
ANNOTATION_MIN = 3.0
# The sub-line enters as the hook's typing sound ends (her choreography).
SUBLINE_DELAY_S = 1.233333
# The swoosh starts a beat before the text actually leaves (hers: 0.2-0.4s).
SWOOSH_LEAD_S = 0.25
UNDERLINE_STICKER_ID = "7459386231852518717"  # Highlight EN - Two White Underline
NUMBERED_ITEM = re.compile(r"^\s*\d")
BROLL_MIN_S, BROLL_MAX_S = 1.0, 3.5


def text_track(segments):
    return {"id": capcut_uuid(), "type": "text", "segments": segments,
            "flag": 0, "attribute": 0, "name": "", "is_default_name": True}


def annotation_windows(items, timeline, out_duration_s):
    """(item, start_s, end_s) per annotation-slot item (annotations and hot
    takes share the top slot) on the output timeline.

    An item appears exactly when its anchor line starts (never before the
    hook exits). If the previous item is still up, the previous one is
    truncated — the anchor moment always wins over hold time."""
    starts = []
    prev = HOOK_SECONDS
    for a in items:
        t = timeline.map(a["time"]) if a.get("time") is not None else None
        start = max(t if t is not None else prev, HOOK_SECONDS)
        start = max(start, prev) if t is None else start
        starts.append((a, start))
        prev = start
    starts.sort(key=lambda x: x[1])

    windows = []
    for i, (item, start) in enumerate(starts):
        end = min(start + ANNOTATION_MAX, out_duration_s)
        if i + 1 < len(starts):
            end = min(end, starts[i + 1][1])  # truncate for the next anchor
        if windows and start < windows[-1][2]:
            w = windows[-1]
            windows[-1] = (w[0], w[1], start)
        if end > start:
            windows.append((item, start, end))
    return windows


def pop_word_indices(pop_words, timings, timeline):
    """Map approved pop words (word + source time) onto caption indices."""
    chosen = set()
    for pw in pop_words or []:
        word = caption_word(pw.get("word", ""))
        t = pw.get("time")
        if not word or t is None:
            continue
        mapped = timeline.map(t)
        if mapped is None:
            continue
        best = None
        for i, (text, start_us, _dur) in enumerate(timings):
            if text != word:
                continue
            dist = abs(start_us / SEC - mapped)
            if best is None or dist < best[0]:
                best = (dist, i)
        if best and best[0] < 1.5:
            chosen.add(best[1])
    return chosen


def broll_windows(broll, timeline):
    """(entry, start_s, duration_s) for placeable b-roll on the output
    timeline: anchored, clamped to 1-3.5s, overlaps truncated (the later
    moment wins), unmappable anchors skipped with a warning."""
    placeable = []
    for b in broll or []:
        if not b.get("path"):
            continue  # film-this idea, nothing to place
        t = timeline.map(b["time"]) if b.get("time") is not None else None
        if t is None:
            print(f"  ! b-roll skipped (anchor not found / inside a cut): "
                  f"{os.path.basename(b['path'])}")
            continue
        secs = max(BROLL_MIN_S, min(float(b.get("seconds") or 2.0), BROLL_MAX_S))
        placeable.append((b, t, min(secs, timeline.duration - t)))
    placeable.sort(key=lambda x: x[1])
    windows = []
    for b, start, dur in placeable:
        if windows and start < windows[-1][1] + windows[-1][2]:
            prev = windows[-1]
            windows[-1] = (prev[0], prev[1], start - prev[1])
        if dur > 0.3:
            windows.append((b, start, dur))
    return [w for w in windows if w[2] > 0.3]


def audio_lanes(segments):
    """Pack audio segments into as few non-overlapping tracks as possible."""
    lanes = []
    for seg in sorted(segments, key=lambda s: s["target_timerange"]["start"]):
        tr = seg["target_timerange"]
        for lane in lanes:
            last = lane[-1]["target_timerange"]
            if tr["start"] >= last["start"] + last["duration"]:
                lane.append(seg)
                break
        else:
            lanes.append([seg])
    return lanes


def build_full_draft(video_path: str, approved: dict, draft_name: str) -> str:
    assert_capcut_closed()
    draft_dir = os.path.join(PROJECTS_DIR, draft_name)
    assert_not_locked(draft_dir)

    transcript = transcribe(video_path)
    staged = stage_media(video_path)
    material = draft.VideoMaterial(staged)
    video_duration_s = material.duration / SEC

    keeps, report = plan_cuts(transcript["words"], video_duration_s)
    timeline = CutTimeline(keeps)
    print(format_report(keeps, report, video_duration_s))

    script = draft.ScriptFile(1080, 1920, 30, True)
    script.add_track(draft.TrackType.video, "main")
    target = 0
    for s, e in keeps:
        dur = int((e - s) * SEC)
        script.add_segment(draft.VideoSegment(
            material, draft.Timerange(target, dur),
            source_timerange=draft.Timerange(int(s * SEC), dur)), "main")
        target += dur

    # B-roll overlays: muted, full canvas, staged like the main clip.
    bin_entries = [media_bin_entry(
        staged, material.width, material.height, material.duration)]
    bin_map = {staged: bin_entries[0]["id"]}
    broll_placed = broll_windows(approved.get("broll"), timeline)
    if broll_placed:
        script.add_track(draft.TrackType.video, "broll", relative_index=1)
        broll_materials = {}
        for b, start, dur_s in broll_placed:
            path = b["path"]
            if path not in broll_materials:
                b_staged = stage_media(path)
                b_mat = draft.VideoMaterial(b_staged)
                broll_materials[path] = b_mat
                bin_entries.append(media_bin_entry(
                    b_staged, b_mat.width, b_mat.height, b_mat.duration))
                bin_map[b_staged] = bin_entries[-1]["id"]
            b_mat = broll_materials[path]
            dur_us = min(int(dur_s * SEC), b_mat.duration)
            script.add_segment(draft.VideoSegment(
                b_mat, draft.Timerange(int(start * SEC), dur_us),
                source_timerange=draft.Timerange(0, dur_us),
                volume=0.0), "broll")

    draft_info = conform_draft_info(json.loads(script.dumps()), bin_map)
    out_duration_us = draft_info["duration"]

    tb = TextBuilder()
    sfx_b = SfxBuilder()
    stk_b = StickerBuilder()
    sfx_elements, sticker_elements = [], []

    def add_sfx(key, start_us):
        start_us = max(0, start_us)
        m, s, extras = sfx_b.make_sfx(key, start_us, max_end_us=out_duration_us)
        if s["target_timerange"]["duration"] > 0:
            sfx_elements.append((m, s, extras))

    def add_track_of(elements):
        segs = []
        for m, s, e in elements:
            draft_info["materials"]["texts"].append(m)
            draft_info["materials"]["material_animations"].extend(
                e["material_animations"])
            segs.append(s)
        if segs:
            draft_info["tracks"].append(text_track(segs))

    # Hook: types itself in, swooshes out.
    hook_dur = int(min(HOOK_SECONDS, timeline.duration) * SEC)
    add_track_of([tb.make_text(approved["hook"], PRESETS["hook"], 0, hook_dur,
                               animation=LAYER_ANIMATIONS["hook"])])
    add_sfx("typing", 0)
    add_sfx("swoosh", hook_dur - int(SWOOSH_LEAD_S * SEC))

    # Sub-line: bounces in with glitter once the hook has typed itself out.
    if approved.get("subline"):
        sub_start = min(int(SUBLINE_DELAY_S * SEC), hook_dur // 2)
        add_track_of([tb.make_text(approved["subline"], PRESETS["subline"],
                                   sub_start, hook_dur - sub_start,
                                   animation=LAYER_ANIMATIONS["subline"])])
        add_sfx("glitter", sub_start)

    # Annotations and hot takes share the top slot.
    items = [dict(a) for a in approved.get("annotations", [])]
    for h in approved.get("hot_takes", []):
        items.append({"text": h["text"], "time": h.get("time"),
                      "label": h.get("label") or "hot take"})
    ann_elements, label_elements = [], []
    for item, start, end in annotation_windows(items, timeline, timeline.duration):
        s_us, d_us = int(start * SEC), int((end - start) * SEC)
        if item.get("label"):
            # Her hot-take pattern: tilted yellow label + double underline +
            # Pop Whoosh; label and line enter plain (no bounce), as she built it.
            label_elements.append(
                tb.make_text(item["label"], PRESETS["hot_take"], s_us, d_us))
            m, s, extras = stk_b.make_sticker(UNDERLINE_STICKER_ID, s_us, d_us)
            sticker_elements.append((m, s, extras))
            ann_elements.append(
                tb.make_text(item["text"], PRESETS["annotation"], s_us, d_us))
            add_sfx("pop_whoosh", s_us)
        else:
            ann_elements.append(
                tb.make_text(item["text"], PRESETS["annotation"], s_us, d_us,
                             animation=LAYER_ANIMATIONS["annotation"]))
            # Entry sound: the approved per-annotation "sfx" (proposed by
            # sonnet from the content, overridable at the gate or via
            # run.py --sfx), defaulting to pop. Numbered list items always
            # click in — her standing rule beats everything.
            sfx_key = item.get("sfx") if item.get("sfx") in SFX else "pop"
            if NUMBERED_ITEM.match(item["text"]):
                sfx_key = "mouse_click"
            add_sfx(sfx_key, s_us)
    add_track_of(ann_elements)
    add_track_of(label_elements)

    # Captions, with approved pop words re-styled in ZY Modern.
    timings = retimed_captions(transcript["words"], timeline)
    pop_idx = pop_word_indices(approved.get("pop_words"), timings, timeline)
    mats, segs, extras = tb.make_word_captions(
        timings, PRESETS["caption"], PRESETS["pop"], pop_idx)
    draft_info["materials"]["texts"].extend(mats)
    draft_info["materials"]["material_animations"].extend(
        extras["material_animations"])
    draft_info["tracks"].append(text_track(segs))

    # Stickers, then sound effects (packed into non-overlapping audio lanes).
    for m, s, extra_mats in sticker_elements:
        draft_info["materials"].setdefault("stickers", []).append(m)
        for cat, ms in extra_mats.items():
            draft_info["materials"].setdefault(cat, []).extend(ms)
    if sticker_elements:
        draft_info["tracks"].append(
            sticker_track([s for _, s, _ in sticker_elements]))

    for m, s, extra_mats in sfx_elements:
        draft_info["materials"].setdefault("audios", []).append(m)
        for cat, ms in extra_mats.items():
            draft_info["materials"].setdefault(cat, []).extend(ms)
    for lane in audio_lanes([s for _, s, _ in sfx_elements]):
        draft_info["tracks"].append(audio_track(lane))

    meta = build_draft_meta_info(
        draft_name=draft_name, draft_id=capcut_uuid(),
        bin_entries=bin_entries, duration_us=draft_info["duration"],
        media_size_bytes=os.path.getsize(staged))

    clean_draft_dir(draft_dir)
    os.makedirs(draft_dir)
    atomic_write_json(os.path.join(draft_dir, "draft_info.json"), draft_info)
    atomic_write_json(os.path.join(draft_dir, "draft_meta_info.json"), meta)
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", staged, "-frames:v",
         "1", os.path.join(draft_dir, "draft_cover.jpg")], check=True)
    register_draft(build_root_entry(meta))

    print(f"Draft written and registered: {draft_dir}")
    print(f"hook + {len(ann_elements)} annotations ({len(label_elements)} "
          f"labeled) + {len(timings)} caption words ({len(pop_idx)} pop) + "
          f"{len(sfx_elements)} sfx + {len(sticker_elements)} stickers + "
          f"{len(broll_placed)} b-roll, {timeline.duration:.1f}s")
    return draft_dir


if __name__ == "__main__":
    if len(sys.argv) < 3:
        sys.exit(__doc__)
    with open(sys.argv[2], encoding="utf-8") as f:
        approved = json.load(f)
    name = sys.argv[3] if len(sys.argv) > 3 else (
        "ZZTEST_" + os.path.splitext(os.path.basename(sys.argv[1]))[0] + "_full")
    build_full_draft(sys.argv[1], approved, name)
