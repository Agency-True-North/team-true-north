"""Snapshot a draft YOUR CapCut created into reference/ (setup step).

The builders never invent CapCut's file format — they copy every format
detail from a reference draft that the real CapCut on THIS machine wrote.
That makes the tool match your CapCut version automatically.

During setup you make a small draft in CapCut (import one video clip, drop
it on the timeline, add one text box, close CapCut). Then:

  .venv/bin/python src/make_reference.py STYLE_SETUP

finds the draft named STYLE_SETUP in your CapCut library and snapshots:
  reference/draft_info.json                the draft's timeline file
  reference/draft_meta_info.json           the draft's identity file
  reference/root_meta_info.reference.json  your library index, for reference

Read-only against the CapCut library — safe to run anytime, but the draft
must have been SAVED (close CapCut, or at least close the project) first.
Re-run it after CapCut updates to refresh the format snapshots (see
CAPCUT-UPDATE-REPAIR.md).
"""

import json
import shutil
import sys
from pathlib import Path

from capcut_env import PROJECTS_DIR, ROOT_META, REFERENCE_DIR


def find_draft(name: str) -> Path:
    with open(ROOT_META, encoding="utf-8") as f:
        root = json.load(f)
    for entry in root["all_draft_store"]:
        if entry.get("draft_name") == name:
            return Path(entry["draft_fold_path"])
    names = [e.get("draft_name") for e in root["all_draft_store"]][:15]
    raise SystemExit(
        f'No draft named "{name}" in your CapCut library.\n'
        f"Drafts found: {names}\n"
        f"Rename your setup project to exactly {name} in CapCut and re-run."
    )


def validate(draft_info: dict, name: str) -> None:
    problems = []
    tracks = draft_info.get("tracks", [])
    video_tracks = [t for t in tracks if t.get("type") == "video" and t.get("segments")]
    if not video_tracks:
        problems.append("no video clip on the timeline")
    if not tracks or tracks[0].get("type") != "video" or not tracks[0].get("segments"):
        problems.append("the FIRST track must be the video track — start the "
                        "draft by dragging the video clip in before anything else")
    if not draft_info.get("materials", {}).get("videos"):
        problems.append("no video material in the draft")
    if problems:
        raise SystemExit(
            f'The draft "{name}" can\'t be used as a reference yet:\n  - '
            + "\n  - ".join(problems)
            + "\nFix it in CapCut (a fresh draft with one video clip dropped in "
              "first is perfect), save, close CapCut, re-run."
        )


def main():
    if len(sys.argv) != 2:
        raise SystemExit("usage: make_reference.py <draft name, e.g. STYLE_SETUP>")
    name = sys.argv[1]
    folder = find_draft(name)
    src_info = folder / "draft_info.json"
    src_meta = folder / "draft_meta_info.json"
    if not src_info.exists():
        raise SystemExit(f"{src_info} not found — open the draft once in CapCut, "
                         "close CapCut, and re-run.")

    draft_info = json.loads(src_info.read_text(encoding="utf-8"))
    validate(draft_info, name)

    ref = Path(REFERENCE_DIR)
    ref.mkdir(exist_ok=True)
    shutil.copy2(src_info, ref / "draft_info.json")
    if src_meta.exists():
        shutil.copy2(src_meta, ref / "draft_meta_info.json")
    shutil.copy2(ROOT_META, ref / "root_meta_info.reference.json")

    version = draft_info.get("version")
    new_version = draft_info.get("new_version")
    print(f"Reference snapshots written to reference/ from draft \"{name}\"")
    print(f"CapCut draft format: version={version} new_version={new_version}")
    print(f"Projects dir: {PROJECTS_DIR}")


if __name__ == "__main__":
    main()
