"""Long-form plain draft: the video with cuts applied, nothing else.

One segment per keep-interval, all referencing the same staged source, so
every cut is reversible in CapCut by dragging a segment edge. No text layers,
no sounds, no b-roll — the creator captions these themselves, YouTube style. The
canvas takes the source video's own dimensions (masterclass videos are 16:9;
everything so far was 1080x1920).

Usage: .venv/bin/python src/build_longform.py <video path> [draft name]
       (direct usage builds with mechanical cuts only; longcut.py is the
        real front door and adds the sonnet mistake/redundancy pass)
"""

import json
import os
import subprocess
import sys

import pyJianYingDraft as draft

from capcut_env import (
    PROJECTS_DIR,
    assert_capcut_closed,
    assert_not_locked,
    atomic_write_json,
    capcut_uuid,
    clean_draft_dir,
    register_draft,
    stage_media,
)
from conform import conform_draft_info
from meta_info import build_draft_meta_info, build_root_entry, media_bin_entry

SEC = 1_000_000


def build_plain_cut_draft(video_path: str, keeps, draft_name: str) -> str:
    """keeps: [(start_s, end_s), ...] in source seconds. Returns draft dir."""
    assert_capcut_closed()
    if not os.path.isfile(video_path):
        raise FileNotFoundError(video_path)
    draft_dir = os.path.join(PROJECTS_DIR, draft_name)
    assert_not_locked(draft_dir)

    staged = stage_media(video_path)
    material = draft.VideoMaterial(staged)
    if material.duration <= 0:
        raise RuntimeError(f"Could not read a duration from {video_path}")

    script = draft.ScriptFile(material.width, material.height, 30, True)
    script.add_track(draft.TrackType.video)
    target = 0
    for s, e in keeps:
        dur = int((e - s) * SEC)
        if dur <= 0:
            continue
        script.add_segment(draft.VideoSegment(
            material,
            draft.Timerange(target, dur),
            source_timerange=draft.Timerange(int(s * SEC), dur),
        ))
        target += dur

    bin_entry = media_bin_entry(
        staged, material.width, material.height, material.duration
    )
    draft_info = conform_draft_info(json.loads(script.dumps()), bin_entry["id"])

    meta = build_draft_meta_info(
        draft_name=draft_name,
        draft_id=capcut_uuid(),
        bin_entries=[bin_entry],
        duration_us=draft_info["duration"],
        media_size_bytes=os.path.getsize(staged),
    )

    clean_draft_dir(draft_dir)
    os.makedirs(draft_dir)
    atomic_write_json(os.path.join(draft_dir, "draft_info.json"), draft_info)
    atomic_write_json(os.path.join(draft_dir, "draft_meta_info.json"), meta)
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", staged, "-frames:v", "1",
         os.path.join(draft_dir, "draft_cover.jpg")],
        check=True,
    )
    register_draft(build_root_entry(meta))

    print(f"Draft written and registered: {draft_dir}")
    print(f"{material.width}x{material.height} canvas, {len(keeps)} segments, "
          f"{target / SEC:.1f}s output")
    return draft_dir


if __name__ == "__main__":
    from tighten import plan_cuts, format_report
    from transcribe import transcribe

    if len(sys.argv) < 2:
        sys.exit(__doc__)
    video = sys.argv[1]
    name = sys.argv[2] if len(sys.argv) > 2 else (
        "ZZTEST_" + os.path.splitext(os.path.basename(video))[0] + "_long"
    )
    t = transcribe(video)
    mat = draft.VideoMaterial(stage_media(video))
    keeps, report = plan_cuts(t["words"], mat.duration / SEC)
    print(format_report(keeps, report, mat.duration / SEC))
    build_plain_cut_draft(video, keeps, name)
