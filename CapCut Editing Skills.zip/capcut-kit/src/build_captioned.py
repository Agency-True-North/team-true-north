"""Phase 3: real video + word-by-word captions from its Deepgram transcript.

Each spoken word becomes one caption element in the locked caption preset
(TK Small Write, white, chest height). Words are lowercased and stripped of
sentence punctuation to match the kit's default caption look; each word holds on screen
until the next word starts (gaps capped, so pauses go quiet).

Usage: .venv/bin/python src/build_captioned.py <video path> [draft name]
"""

import json
import os
import subprocess
import sys

import pyJianYingDraft as draft

from capcut_env import (
    PROJECTS_DIR,
    assert_capcut_closed,
    assert_not_locked,
    atomic_write_json,
    capcut_uuid,
    clean_draft_dir,
    register_draft,
    stage_media,
)
from conform import conform_draft_info
from meta_info import build_draft_meta_info, build_root_entry, media_bin_entry
from style_presets import PRESETS
from text_builder import TextBuilder
from transcribe import transcribe

SEC = 1_000_000
MAX_WORD_HOLD_GAP = 0.5  # seconds a word may linger into a pause


def caption_word(word: str) -> str:
    return word.lower().strip(".,!?;:…")


def word_timings(words, video_duration_us):
    """(text, start_us, duration_us) per word; each holds until the next."""
    out = []
    for i, w in enumerate(words):
        text = caption_word(w["word"])
        if not text:
            continue
        start = int(w["start"] * SEC)
        if i + 1 < len(words):
            hold_end = min(words[i + 1]["start"], w["end"] + MAX_WORD_HOLD_GAP)
        else:
            hold_end = w["end"] + MAX_WORD_HOLD_GAP
        end = min(int(hold_end * SEC), video_duration_us)
        if end > start:
            out.append((text, start, end - start))
    return out


def build_captioned_draft(video_path: str, draft_name: str) -> str:
    assert_capcut_closed()
    draft_dir = os.path.join(PROJECTS_DIR, draft_name)
    assert_not_locked(draft_dir)

    transcript = transcribe(video_path)

    staged = stage_media(video_path)
    material = draft.VideoMaterial(staged)
    script = draft.ScriptFile(1080, 1920, 30, True)
    script.add_track(draft.TrackType.video)
    script.add_segment(
        draft.VideoSegment(material, draft.Timerange(0, material.duration))
    )

    bin_entry = media_bin_entry(
        staged, material.width, material.height, material.duration
    )
    draft_info = conform_draft_info(json.loads(script.dumps()), bin_entry["id"])

    tb = TextBuilder()
    timings = word_timings(transcript["words"], material.duration)
    mats, segs, extras = tb.make_word_captions(timings, PRESETS["caption"])
    draft_info["materials"]["texts"].extend(mats)
    draft_info["materials"]["material_animations"].extend(
        extras["material_animations"]
    )
    draft_info["tracks"].append({
        "id": capcut_uuid(), "type": "text", "segments": segs,
        "flag": 0, "attribute": 0, "name": "", "is_default_name": True,
    })

    meta = build_draft_meta_info(
        draft_name=draft_name,
        draft_id=capcut_uuid(),
        bin_entries=[bin_entry],
        duration_us=draft_info["duration"],
        media_size_bytes=os.path.getsize(staged),
    )

    clean_draft_dir(draft_dir)
    os.makedirs(draft_dir)
    atomic_write_json(os.path.join(draft_dir, "draft_info.json"), draft_info)
    atomic_write_json(os.path.join(draft_dir, "draft_meta_info.json"), meta)
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", staged, "-frames:v", "1",
         os.path.join(draft_dir, "draft_cover.jpg")],
        check=True,
    )
    register_draft(build_root_entry(meta))

    print(f"Draft written and registered: {draft_dir}")
    print(f"{len(timings)} caption words over "
          f"{material.duration / SEC:.1f}s")
    return draft_dir


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    name = sys.argv[2] if len(sys.argv) > 2 else (
        "ZZTEST_" + os.path.splitext(os.path.basename(sys.argv[1]))[0] + "_cap"
    )
    build_captioned_draft(sys.argv[1], name)
