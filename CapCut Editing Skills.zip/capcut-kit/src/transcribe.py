"""Transcribe a video via Deepgram, returning word-level timestamps.

Audio is extracted locally with ffmpeg (mono 16 kHz WAV) so only ~2 MB per
90s goes to Deepgram instead of the full video. Results are cached in
transcripts/<video basename>.json — delete the cache file to force a re-run.

Usage: .venv/bin/python src/transcribe.py <video path>
"""

import json
import os
import subprocess
import sys
import tempfile
import urllib.request

from capcut_env import TOOL_DIR

TRANSCRIPTS_DIR = os.path.join(TOOL_DIR, "transcripts")
DEEPGRAM_URL = (
    "https://api.deepgram.com/v1/listen"
    "?model=nova-3&smart_format=true&punctuate=true&filler_words=true"
)


def _api_key() -> str:
    env_path = os.path.join(TOOL_DIR, ".env")
    with open(env_path, encoding="utf-8") as f:
        for line in f:
            if line.startswith("DEEPGRAM_API_KEY="):
                key = line.split("=", 1)[1].strip().strip('"')
                if key:
                    return key
    raise RuntimeError(f"No DEEPGRAM_API_KEY in {env_path}")


def transcribe(video_path: str) -> dict:
    """Returns {'words': [{'word', 'start', 'end'}...], 'transcript': str}.
    Times are in seconds (floats), straight from Deepgram."""
    os.makedirs(TRANSCRIPTS_DIR, exist_ok=True)
    cache = os.path.join(
        TRANSCRIPTS_DIR,
        os.path.splitext(os.path.basename(video_path))[0] + ".json",
    )
    if os.path.exists(cache):
        with open(cache, encoding="utf-8") as f:
            return json.load(f)

    with tempfile.TemporaryDirectory() as tmp:
        wav = os.path.join(tmp, "audio.wav")
        subprocess.run(
            ["ffmpeg", "-y", "-v", "error", "-i", video_path,
             "-vn", "-ac", "1", "-ar", "16000", "-c:a", "pcm_s16le", wav],
            check=True,
        )
        with open(wav, "rb") as f:
            audio = f.read()

    request = urllib.request.Request(
        DEEPGRAM_URL,
        data=audio,
        headers={
            "Authorization": f"Token {_api_key()}",
            "Content-Type": "audio/wav",
        },
    )
    with urllib.request.urlopen(request, timeout=300) as resp:
        payload = json.load(resp)

    alt = payload["results"]["channels"][0]["alternatives"][0]
    result = {
        "transcript": alt["transcript"],
        "words": [
            {"word": w["word"], "start": w["start"], "end": w["end"]}
            for w in alt["words"]
        ],
    }
    with open(cache, "w", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=1)
    return result


if __name__ == "__main__":
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    r = transcribe(sys.argv[1])
    print(f"{len(r['words'])} words")
    print(r["transcript"][:300])
