"""Phase 2: assemble a real raw video into an editable CapCut draft.

Takes any video file, stages it into CapCut's sandbox, and produces a draft
on the 1080x1920 Reels canvas that opens and plays. Text layers come in
Phases 3-4; this is the media backbone.

Usage:
  .venv/bin/python src/build_video.py <video path> [draft name]
  .venv/bin/python src/build_video.py --remove <draft name>

Draft name defaults to ZZTEST_<video filename>. Only ZZTEST_ names can be
rebuilt in place (the clean-wipe rule); real runs will get their own naming
once the pipeline is end-to-end.
"""

import json
import os
import subprocess
import sys

import pyJianYingDraft as draft

from capcut_env import (
    PROJECTS_DIR,
    assert_capcut_closed,
    assert_not_locked,
    atomic_write_json,
    capcut_uuid,
    clean_draft_dir,
    register_draft,
    stage_media,
    unregister_draft,
)
from conform import conform_draft_info
from meta_info import build_draft_meta_info, build_root_entry, media_bin_entry

CANVAS = (1080, 1920)


def build_video_draft(video_path: str, draft_name: str) -> str:
    """Stage a video and write a registered draft around it. Returns draft dir."""
    assert_capcut_closed()
    if not os.path.isfile(video_path):
        raise FileNotFoundError(video_path)
    draft_dir = os.path.join(PROJECTS_DIR, draft_name)
    assert_not_locked(draft_dir)

    staged = stage_media(video_path)
    material = draft.VideoMaterial(staged)
    if material.duration <= 0:
        raise RuntimeError(f"Could not read a duration from {video_path}")

    script = draft.ScriptFile(*CANVAS, 30, True)
    script.add_track(draft.TrackType.video)
    script.add_segment(
        draft.VideoSegment(material, draft.Timerange(0, material.duration))
    )

    bin_entry = media_bin_entry(
        staged, material.width, material.height, material.duration
    )
    draft_info = conform_draft_info(json.loads(script.dumps()), bin_entry["id"])

    meta = build_draft_meta_info(
        draft_name=draft_name,
        draft_id=capcut_uuid(),
        bin_entries=[bin_entry],
        duration_us=draft_info["duration"],
        media_size_bytes=os.path.getsize(staged),
    )

    clean_draft_dir(draft_dir)
    os.makedirs(draft_dir)
    atomic_write_json(os.path.join(draft_dir, "draft_info.json"), draft_info)
    atomic_write_json(os.path.join(draft_dir, "draft_meta_info.json"), meta)
    subprocess.run(
        ["ffmpeg", "-y", "-v", "error", "-ss", "1", "-i", staged, "-frames:v", "1",
         os.path.join(draft_dir, "draft_cover.jpg")],
        check=True,
    )
    register_draft(build_root_entry(meta))

    print(f"Draft written and registered: {draft_dir}")
    print(f"Source: {material.width}x{material.height}, "
          f"{material.duration / 1_000_000:.1f}s")
    return draft_dir


def main() -> None:
    if "--remove" in sys.argv:
        unregister_draft(sys.argv[sys.argv.index("--remove") + 1])
        print("Unregistered.")
        return
    if len(sys.argv) < 2:
        sys.exit(__doc__)
    video_path = sys.argv[1]
    default_name = "ZZTEST_" + os.path.splitext(os.path.basename(video_path))[0]
    draft_name = sys.argv[2] if len(sys.argv) > 2 else default_name
    build_video_draft(video_path, draft_name)


if __name__ == "__main__":
    main()
