"""Build your-CapCut-format text materials/segments from the harvested template.

The template (reference/text_template.json) is a text box created in YOUR
CapCut (harvested from the STYLE_SETUP draft by src/harvest_style.py), so
every field is exactly what your CapCut version writes. We
deep-copy it and parametrize only text, font, size, color, position, timing,
and optional underline ranges — never hand-assembling the format.
"""

import copy
import json
import os

from capcut_env import REFERENCE_DIR, capcut_uuid

_TEXT_RENDER_INDEX_BASE = 14000


def _load_template():
    with open(os.path.join(REFERENCE_DIR, "text_template.json"), encoding="utf-8") as f:
        return json.load(f)


def _load_animations():
    with open(os.path.join(REFERENCE_DIR, "animations.json"), encoding="utf-8") as f:
        return json.load(f)


class TextBuilder:
    """Produces (material, segment, extra_materials) triples for text layers."""

    def __init__(self):
        self._template = _load_template()
        self._animations = _load_animations()
        self._render_index = _TEXT_RENDER_INDEX_BASE

    def _animation_material(self, anim_spec):
        """A full material_animations entry for a harvested in-animation.

        anim_spec is one of style_presets.ANIM_* ({name, resource_id, duration});
        the full harvested material (reference/animations.json) is deep-copied so
        every field is exactly what your CapCut wrote."""
        for entry in self._animations.values():
            mat = entry["material"]
            anims = mat.get("animations", [])
            if (entry["carried_by"] == "text" and anims
                    and anims[0]["resource_id"] == anim_spec["resource_id"]):
                mat = copy.deepcopy(mat)
                mat["id"] = capcut_uuid()
                return mat
        raise KeyError(f"animation not in reference/animations.json: {anim_spec}")

    def make_text(self, text, preset, start_us, duration_us,
                  underline_spans=None, animation=None):
        """One styled text element.

        underline_spans: list of (start, end) character offsets to underline.
        animation: optional style_presets.ANIM_* spec for the in-animation.
        Returns (material, segment, extra_materials).
        """
        tmpl = self._template
        material = copy.deepcopy(tmpl["material"])
        segment = copy.deepcopy(tmpl["segment"])
        font = preset["font"]

        material["id"] = capcut_uuid()
        material["content"] = json.dumps(
            {"styles": self._styles(text, preset, underline_spans or []),
             "text": text},
            ensure_ascii=False,
        )
        material["font_path"] = font["path"]
        material["font_id"] = font["id"]
        material["font_title"] = font["title"]
        material["font_size"] = preset["size"]
        for entry in material.get("fonts", []):
            entry["id"] = capcut_uuid()
            entry["path"] = font["path"]
            entry["resource_id"] = font["id"]
            entry["title"] = font["title"]

        if animation:
            anim = self._animation_material(animation)
        else:
            anim = {"id": capcut_uuid(), "type": "sticker_animation",
                    "animations": [], "multi_language_current": "none"}

        self._render_index += 1
        segment["id"] = capcut_uuid()
        segment["material_id"] = material["id"]
        segment["extra_material_refs"] = [anim["id"]]
        segment["target_timerange"] = {"start": start_us, "duration": duration_us}
        segment["render_index"] = self._render_index
        segment["clip"]["transform"] = {"x": preset["x"], "y": preset["y"]}
        if "scale" in preset:
            segment["clip"]["scale"] = {"x": preset["scale"], "y": preset["scale"]}
        if "rotation" in preset:
            segment["clip"]["rotation"] = preset["rotation"]

        return material, segment, {"material_animations": [anim]}

    def make_word_captions(self, words_with_timing, preset, pop_preset=None,
                           pop_indices=frozenset()):
        """Word-by-word captions: one text element per (word, start_us, duration_us).
        Words at an index in pop_indices are styled with pop_preset instead
        (ZY Modern "pop words"). Returns (materials, segments, extra_materials)
        for a single text track."""
        materials, segments, extras = [], [], {"material_animations": []}
        for i, (word, start_us, duration_us) in enumerate(words_with_timing):
            p = pop_preset if (pop_preset and i in pop_indices) else preset
            m, s, e = self.make_text(word, p, start_us, duration_us)
            materials.append(m)
            segments.append(s)
            extras["material_animations"].extend(e["material_animations"])
        return materials, segments, extras

    @staticmethod
    def _styles(text, preset, underline_spans):
        """Split [0, len) into ranges so underlined spans get underline: true."""
        def style(rng, underline):
            s = {
                "fill": {"content": {"render_type": "solid",
                                     "solid": {"color": list(preset["color"])}}},
                "font": {"path": preset["font"]["path"], "id": preset["font"]["id"]},
                "range": list(rng),
                "size": preset["size"],
            }
            if underline:
                s["underline"] = True
            return s

        marks = sorted(set([0, len(text)] +
                           [b for span in underline_spans for b in span]))
        spans = list(zip(marks, marks[1:]))
        underlined = lambda a, b: any(u0 <= a and b <= u1 for u0, u1 in underline_spans)
        return [style((a, b), underlined(a, b)) for a, b in spans if a < b]
