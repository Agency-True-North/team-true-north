"""Long-form cut proposals: retakes, false starts, mistakes, redundancies.

Sonnet reads a timestamped transcript and proposes spans to cut, each tagged
"confident" (obvious flub/retake — auto-applied after she sees the list) or
"judgment" (she decides at the gate). Nothing here touches CapCut.

Anchor resolution must survive REPEATED words (a retake says the same words
twice), so every cut carries a "near" time hint and we resolve the anchor
occurrence closest to it. Cuts whose anchors don't resolve are never applied;
they surface at the gate as unresolved so nothing silently disappears.

Usage: .venv/bin/python src/smart_cuts.py <video path>
"""

import json
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

MAX_CONFIDENT_S = 25.0   # a "confident" cut longer than this is demoted
MAX_CUT_S = 150.0        # longer than this = anchor mismatch, mark unresolved
TRIM_PAD = 0.04

# Long transcripts are analyzed in overlapping chunks, in parallel — one
# giant prompt for a 45-minute video is slow and fragile (the 2026-07-16
# community-video run hung for half an hour on a single call). Each call
# gets a hard timeout and retries; a chunk that still fails raises loudly,
# because a silently skipped chunk means uncaught flubs.
CHUNK_S = 480            # ~8 minutes of video per sonnet call
CHUNK_OVERLAP_S = 45     # overlap so a flub spanning a boundary is seen
CALL_TIMEOUT_S = 300     # per sonnet call
CALL_ATTEMPTS = 3        # tries per chunk before failing loudly
PARALLEL_CALLS = 4       # a 45-min class = ~7 chunks -> 2 batches, ~10 min          # air shaved off the neighbors' word boundaries

PROMPT = """You are marking cuts in a raw long-form teaching video (a
masterclass). The speaker records in one take and fixes mistakes by re-saying
lines. Your job: find the spans that should be CUT so the survivor plays
clean. You are not shortening the class — teaching content stays. When in
doubt, it is a judgment call, not a cut.

What to mark, and its confidence:
- "retake" (confident): she flubs or restarts a line, then says it again.
  Cut the weaker take. When both takes work, cut the EARLIER one — she
  re-said it because she wanted it better.
- "false start" (confident): a sentence abandoned mid-way and restarted.
- "mistake" (confident): she calls it out herself ("wait", "let me say that
  again", "scratch that", "no, sorry"). Cut from where the flubbed line
  starts through the call-out itself.
- Watch for NEAR-repeats: a restart that changes one word is a
  self-correction ("because who you ARE in the room or... because who you
  WERE in the room with") — cut the first attempt through any trailing
  "or"/"I mean". The words differ slightly, so read for the redo, not for
  an exact repeat.
- "redundant" (judgment): a passage that repeats a point already made and
  adds nothing new. She decides.
- "tangent" (judgment): a detour that could go. She decides.

NOT a cut, ever: deliberate rhetorical repetition — a phrase repeated for
emphasis, a list riding the same opener ("I don't care if... I don't care
if..."), a callback to an earlier line. That is her speaking style. A retake
is a REDO of a line that went wrong, not a rhythm.

TIMESTAMPED TRANSCRIPT (markers are [m:ss] in video time):
{transcript}
{hints_block}{notes_block}
For each cut give:
- "reason": retake | false start | mistake | redundant | tangent
- "confidence": "confident" or "judgment" per the rules above
- "first_words": the FIRST 4-6 words of the span to cut, copied VERBATIM
  from the transcript (exact words, exact order)
- "last_words": the LAST 4-6 words of the span to cut, VERBATIM
- "near": the [m:ss] marker closest to where the cut STARTS — this is how
  the right occurrence is found when the same words appear twice, so take
  it from the marker immediately before the span
- "why": one short line (for a retake, say which take is kept)

Reply with ONLY this JSON, nothing else:
{{"cuts": [{{"reason": "...", "confidence": "...", "first_words": "...",
 "last_words": "...", "near": "m:ss", "why": "..."}}]}}
An empty list is a fine answer if the recording is clean."""

HINTS_BLOCK = """
REPEATED-PHRASE DETECTOR HITS (mechanical; some are retakes, some are just
her repeating herself naturally — judge each):
{hints}
"""

NOTES_BLOCK = """
HER NOTES FOR THIS VIDEO (follow them; they override the defaults above):
{notes}
"""


def _norm(w: str) -> str:
    return w.lower().strip(".,!?;:…'\"")


def timestamped_transcript(words, marker_every_s: float = 15.0) -> str:
    """Transcript text with [m:ss] markers at speech gaps / every ~15s."""
    lines, current, last_marker = [], [], -1e9
    for i, w in enumerate(words):
        gap = w["start"] - words[i - 1]["end"] if i else 0.0
        if w["start"] - last_marker >= marker_every_s or gap > 1.0:
            if current:
                lines.append(" ".join(current))
            m, s = divmod(int(w["start"]), 60)
            current = [f"[{m}:{s:02d}]"]
            last_marker = w["start"]
        current.append(w["word"])
    if current:
        lines.append(" ".join(current))
    return "\n".join(lines)


def _parse_near(near) -> float:
    try:
        parts = str(near).strip("[] ").split(":")
        return int(parts[0]) * 60 + float(parts[1]) if len(parts) == 2 else float(parts[0])
    except (ValueError, IndexError):
        return 0.0


def _find_all(target_words, stream):
    target = [_norm(w) for w in target_words.split()]
    if not target:
        return [], 0
    hits = [i for i in range(len(stream) - len(target) + 1)
            if stream[i:i + len(target)] == target]
    if not hits and len(target) > 3:  # tolerate one transcription drift word
        head = target[:3]
        hits = [i for i in range(len(stream) - 2) if stream[i:i + 3] == head]
        return hits, 3
    return hits, len(target)


def resolve_cut(cut: dict, words) -> dict:
    """Fill start/end seconds (word boundaries) or mark the cut unresolved."""
    stream = [_norm(w["word"]) for w in words]
    near = _parse_near(cut.get("near", 0))

    starts, _ = _find_all(cut.get("first_words", ""), stream)
    if not starts:
        cut["resolved"] = False
        return cut
    i = min(starts, key=lambda k: abs(words[k]["start"] - near))

    ends, n = _find_all(cut.get("last_words", ""), stream)
    ends = [k for k in ends if k >= i]
    if not ends:
        cut["resolved"] = False
        return cut
    j = ends[0] + n - 1

    start, end = words[i]["start"], words[j]["end"]
    if not 0 < end - start <= MAX_CUT_S:
        cut["resolved"] = False
        return cut

    cut["resolved"] = True
    cut["start"] = round(start - TRIM_PAD, 3)
    cut["end"] = round(end + TRIM_PAD, 3)
    if cut.get("confidence") == "confident" and end - start > MAX_CONFIDENT_S:
        cut["confidence"] = "judgment"
        cut["why"] = (cut.get("why", "") + " (long cut, demoted to ask)").strip()
    cut["cut_text"] = _excerpt(words, i, j)
    return cut


def _excerpt(words, i, j, max_words=25):
    span = [w["word"] for w in words[i:j + 1]]
    if len(span) <= max_words:
        return " ".join(span)
    half = max_words // 2
    return " ".join(span[:half]) + " [...] " + " ".join(span[-half:])


def _hints_text(retake_hints):
    return "\n".join(
        f"  {int(r['earlier_time'] // 60)}:{int(r['earlier_time'] % 60):02d} then "
        f"{int(r['later_time'] // 60)}:{int(r['later_time'] % 60):02d}: \"{r['text']}...\""
        for r in (retake_hints or []))


def _sonnet_cuts(prompt: str, label: str) -> list:
    """One sonnet call with retries. Raises after CALL_ATTEMPTS failures —
    a skipped chunk would mean uncaught flubs, so failure is never silent."""
    last = ""
    for attempt in range(1, CALL_ATTEMPTS + 1):
        try:
            result = subprocess.run(
                ["claude", "-p", "--model", "sonnet"],
                input=prompt, capture_output=True, text=True,
                timeout=CALL_TIMEOUT_S,
            )
            if result.returncode != 0:
                last = f"claude CLI exit {result.returncode}: {result.stderr[:200]}"
            else:
                raw = result.stdout.strip()
                return json.loads(
                    raw[raw.find("{"):raw.rfind("}") + 1]).get("cuts", [])
        except subprocess.TimeoutExpired:
            last = f"timed out after {CALL_TIMEOUT_S}s"
        except (ValueError, json.JSONDecodeError) as e:
            last = f"unparseable reply: {e}"
        print(f"  ! sonnet {label} attempt {attempt}/{CALL_ATTEMPTS} failed "
              f"({last}) — {'retrying' if attempt < CALL_ATTEMPTS else 'giving up'}")
    raise RuntimeError(
        f"The sonnet pass failed for {label} after {CALL_ATTEMPTS} attempts "
        f"({last}). Nothing was skipped silently — fix the claude CLI (try "
        f"`claude -p` by hand) and re-run, or use --no-smart to build with "
        f"mechanical cuts only.")


def _windows(words):
    """Overlapping (t0, t1) chunk windows covering the transcript."""
    end = words[-1]["end"]
    if end <= CHUNK_S * 1.25:
        return [(0.0, end)]
    out, t0, stride = [], 0.0, CHUNK_S - CHUNK_OVERLAP_S
    while t0 < end:
        out.append((t0, min(t0 + CHUNK_S, end)))
        if t0 + CHUNK_S >= end:
            break
        t0 += stride
    return out


def propose_smart_cuts(words, retake_hints=None, notes: str = "") -> list:
    """Run sonnet over the transcript (chunked + parallel for long videos);
    return resolved cut dicts."""
    windows = _windows(words)
    jobs = []
    for t0, t1 in windows:
        w_chunk = [w for w in words if t0 <= w["start"] < t1]
        if not w_chunk:
            continue
        h_chunk = [r for r in (retake_hints or [])
                   if t0 <= r["later_time"] < t1 or t0 <= r["earlier_time"] < t1]
        hints = _hints_text(h_chunk)
        prompt = PROMPT.format(
            transcript=timestamped_transcript(w_chunk),
            hints_block=HINTS_BLOCK.format(hints=hints) if hints else "",
            notes_block=NOTES_BLOCK.format(notes=notes) if notes else "")
        label = (f"chunk {int(t0 // 60)}:{int(t0 % 60):02d}-"
                 f"{int(t1 // 60)}:{int(t1 % 60):02d}")
        jobs.append((prompt, label))

    if len(jobs) > 1:
        print(f"  analyzing in {len(jobs)} chunks, "
              f"{min(PARALLEL_CALLS, len(jobs))} at a time...")
    with ThreadPoolExecutor(max_workers=min(PARALLEL_CALLS, len(jobs))) as ex:
        chunk_cuts = list(ex.map(lambda j: _sonnet_cuts(*j), jobs))

    cuts = [c for chunk in chunk_cuts for c in chunk]
    resolved = [resolve_cut(dict(c), words) for c in cuts]
    # Confident first at equal start so overlap-dedupe keeps the stronger call
    resolved.sort(key=lambda c: (c.get("start", 1e9),
                                 0 if c.get("confidence") == "confident" else 1))

    deduped, seen_unresolved = [], set()
    for c in resolved:
        if not c.get("resolved"):
            key = (c.get("first_words", ""), str(c.get("near", "")))
            if key not in seen_unresolved:
                seen_unresolved.add(key)
                deduped.append(c)
            continue
        dup = False
        for kept in deduped:
            if not kept.get("resolved"):
                continue
            overlap = (min(c["end"], kept["end"]) - max(c["start"], kept["start"]))
            if overlap > 0.5 * min(c["end"] - c["start"],
                                   kept["end"] - kept["start"]):
                dup = True  # same flub seen from two overlapping chunks
                break
        if not dup:
            deduped.append(c)

    for c in deduped:
        # apply=True only for confident, resolved cuts; the gate can flip any.
        c["apply"] = bool(c["resolved"] and c.get("confidence") == "confident")
    return deduped


if __name__ == "__main__":
    from tighten import find_retakes
    from transcribe import transcribe

    if len(sys.argv) < 2:
        sys.exit(__doc__)
    t = transcribe(sys.argv[1])
    out = propose_smart_cuts(t["words"], find_retakes(t["words"]))
    print(json.dumps(out, ensure_ascii=False, indent=1))
