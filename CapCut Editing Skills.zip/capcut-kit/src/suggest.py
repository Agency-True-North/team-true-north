"""Propose hook + sub-line + annotations from a transcript, in the house voice.

Runs a fast model via the `claude` CLI (no API key needed — uses her Claude
Code auth). Output is ALWAYS a proposal: the approval gate lives in the
calling flow, and nothing reaches a draft without her yes.

Annotations are anchored to transcript quotes so they appear on screen while
she's saying the thing they summarize.

Also proposes "pop_words" — caption words that get the ZY Modern punch font —
and, only when asked (hot_takes=N), "hot_takes": moments that get the tilted
yellow "hot take" / "inner thoughts" / "hear me" label treatment.

Given her b-roll library filenames (broll_files), proposes "broll" overlay
moments: matched to a library file when one fits, or file=null with an idea
of what to film when nothing does (shown at the gate, never placed).
Free-text steering for a specific video goes in via notes.

Usage: .venv/bin/python src/suggest.py <video path> ["her stated hook"] [--hot-takes N]
"""

import json
import os
import subprocess
import sys

from transcribe import transcribe

VOICE_RULES = """Voice rules (non-negotiable):
- Short. Declarative. Statements, never questions.
- Her actual voice: warm but not soft, specific, true first polished second.
- No em dashes. No hype words (hustle, girlboss, passive income, leverage,
  grind, crush it, unleash, transformative, embark, secrets).
- No cheese, no cleverness for its own sake. Clear beats clever.
- Lowercase is fine for the handwriting lines.
- Audience: women 30-50 who hold everything together and feel invisible
  inside the life they built. She talks TO one woman, not at a crowd."""

FRAMEWORKS = """Hook craft (Kallaway frameworks — these are the baseline):
- Triple Hook: the hook + sub-line pair must deliver (1) Context: name her
  reality instantly, (2) the Lean: curiosity in a direction, (3) Snapback:
  pull against where she was leaning. The title carries context + lean;
  the sub-line carries the lean's payoff or the snapback tension.
- Curiosity & Contrast: her audience's common belief vs the contrarian
  reality in the video. Make that gap as large as possible.
- Anticipation: the pair should leave a question open that only watching
  answers. Never resolve it in the hook.
- Speed to value: the hook signals value in the first read, no warm-up.

Annotation craft — an annotation is the line a viewer would screenshot:
- Choose the 2-4 moments where a viewer feels NAMED: pain stated plainly,
  an identity truth, the contrarian snapback, the line that stings or lifts.
- The annotation text is that line's sharpest phrasing: verbatim from the
  transcript or tightened, 3-8 words, lowercase.
- Skip setup, transitions, and generic advice. If it could caption anyone's
  video, it is not an annotation.
- Spread them across the video; never two inside the same breath."""

PROMPT = """You write on-screen text layers for a short talking-head Reel.

{voice}

{frameworks}

TRANSCRIPT:
{transcript}
{notes_block}
{hook_instruction}

Also produce:
- "subline": a 4-8 word handwritten sub-line under the hook (lowercase),
  completing the Triple Hook.
- "annotations": 2-4 screenshot-worthy lines as described above. For each,
  include "anchor": the FIRST 4-6 words of the exact sentence it belongs to,
  copied VERBATIM from the transcript — the annotation appears the moment
  she starts saying that sentence, so anchor precision is everything.
  Also include "sfx": the sound the annotation enters with. "mouse_click"
  when the line is informational — a point, a step, a tip, a list item,
  something being taught. "pop" when the line is an emotional beat — pain
  named, identity, the line that stings or lifts. "bell" only for the one
  biggest emphasis moment, if the video has one.
- "pop_words": 4-8 single caption words that deserve extra visual punch (the
  pivot word of a sentence, a swear, a superlative, the word her voice leans
  on). For each: "word": the word exactly as spoken, "anchor": 4-6 verbatim
  transcript words ENDING with that word (that exact occurrence).
{hot_take_instruction}{broll_instruction}
Reply with ONLY this JSON, nothing else:
{{"hook": "...", "subline": "...",
 "annotations": [{{"text": "...", "anchor": "...", "sfx": "pop|mouse_click|bell"}}],
 "pop_words": [{{"word": "...", "anchor": "..."}}]{hot_take_json}{broll_json}}}"""

HOT_TAKE_INSTRUCTION = """- "hot_takes": exactly {n} moment(s) where she says the quiet part out loud —
  the confession, the contrarian line, the thing she half-whispers. For each:
  "label": whichever of "hot take", "inner thoughts", "hear me" fits that
  moment's energy, "text": the line itself (annotation rules apply), and
  "anchor": the FIRST 4-6 words of its sentence, verbatim. Do not reuse a
  moment already used as an annotation."""
HOT_TAKE_JSON = ',\n "hot_takes": [{"label": "...", "text": "...", "anchor": "..."}]'

BROLL_INSTRUCTION = """
- "broll": 0-4 moments where a short cutaway would make the video stronger —
  a scene she describes, a feeling shown better than told. Only where it
  genuinely helps; zero is a fine answer. Her b-roll library (each filename
  describes the footage):
{files}
  For each moment: "file": the EXACT filename from the library that fits,
  or null if nothing in the library does. "idea": 3-8 words describing the
  footage (when file is null this is what she should film or source).
  "anchor": the FIRST 4-6 words of the sentence it covers, verbatim.
  "seconds": 1-3, how long it holds."""
BROLL_JSON = ',\n "broll": [{"file": "filename-or-null", "idea": "...", "anchor": "...", "seconds": 2}]'

NOTES_BLOCK = """
HER NOTES FOR THIS VIDEO (follow them; they override the defaults above):
{notes}
"""


def suggest(video_path: str, stated_hook: str = "", hot_takes: int = 0,
            broll_files=None, notes: str = "") -> dict:
    transcript = transcribe(video_path)
    if stated_hook:
        hook_instruction = (f'Her stated hook is: "{stated_hook}". Use it as '
                            f'"hook" verbatim (title case it if needed).')
    else:
        hook_instruction = ('Produce "hook": a 3-6 word title-case hook for '
                            'the top of the video.')
    file_list = "\n".join(f"    {f}" for f in (broll_files or []))
    prompt = PROMPT.format(
        voice=VOICE_RULES, frameworks=FRAMEWORKS,
        transcript=transcript["transcript"],
        notes_block=NOTES_BLOCK.format(notes=notes) if notes else "",
        hook_instruction=hook_instruction,
        hot_take_instruction=(HOT_TAKE_INSTRUCTION.format(n=hot_takes)
                              if hot_takes else ""),
        hot_take_json=HOT_TAKE_JSON if hot_takes else "",
        broll_instruction=(BROLL_INSTRUCTION.format(files=file_list)
                           if broll_files else ""),
        broll_json=BROLL_JSON if broll_files else "")
    # MAX_THINKING_TOKENS=0: claude CLI >=2.1 adaptive thinking can loop
    # forever on these transcript prompts (2026-08-11); thinking off = ~15s.
    result = subprocess.run(
        ["claude", "-p", "--model", "sonnet", prompt],
        capture_output=True, text=True, timeout=180,
        env={**os.environ, "MAX_THINKING_TOKENS": "0"},
    )
    if result.returncode != 0:
        raise RuntimeError(f"claude CLI failed: {result.stderr[:400]}")
    raw = result.stdout.strip()
    start, end = raw.find("{"), raw.rfind("}")
    proposals = json.loads(raw[start:end + 1])
    if not hot_takes:
        proposals.pop("hot_takes", None)
    if not broll_files:
        proposals.pop("broll", None)
    for a in proposals.get("annotations", []) + proposals.get("hot_takes", []):
        a["time"] = anchor_time(a.get("anchor", ""), transcript["words"])
    for pw in proposals.get("pop_words", []):
        pw["time"] = anchor_last_word_time(pw.get("anchor", ""),
                                           pw.get("word", ""),
                                           transcript["words"])
    for b in proposals.get("broll", []):
        # never trust a hallucinated filename: unknown -> null + keep the idea
        if b.get("file") and b["file"] not in (broll_files or []):
            b["file"] = None
        b["time"] = anchor_time(b.get("anchor", ""), transcript["words"])
    return proposals


def anchor_time(anchor: str, words):
    """Find the transcript time where an anchor quote is spoken."""
    def norm(w):
        return w.lower().strip(".,!?;:…'\"")
    target = [norm(w) for w in anchor.split()]
    if not target:
        return None
    stream = [norm(w["word"]) for w in words]
    for i in range(len(stream) - len(target) + 1):
        if stream[i:i + len(target)] == target:
            return words[i]["start"]
    # fall back to first-two-word match
    for i in range(len(stream) - 1):
        if stream[i:i + 2] == target[:2]:
            return words[i]["start"]
    return None


def anchor_last_word_time(anchor: str, word: str, words):
    """Time of the pop word itself: the anchor's LAST word is the pop word,
    so return the start of the anchor's final word."""
    def norm(w):
        return w.lower().strip(".,!?;:…'\"")
    target = [norm(w) for w in anchor.split()]
    if not target:
        return None
    if norm(word) and target[-1] != norm(word):
        target.append(norm(word))
    stream = [norm(w["word"]) for w in words]
    for i in range(len(stream) - len(target) + 1):
        if stream[i:i + len(target)] == target:
            return words[i + len(target) - 1]["start"]
    # fall back: first occurrence of the word itself
    for i, w in enumerate(stream):
        if w == norm(word):
            return words[i]["start"]
    return None


if __name__ == "__main__":
    argv = sys.argv[1:]
    if not argv:
        sys.exit(__doc__)
    n_hot = int(argv[argv.index("--hot-takes") + 1]) if "--hot-takes" in argv else 0
    positional = [a for a in argv if not a.startswith("--")
                  and (argv.index(a) == 0 or argv[argv.index(a) - 1] != "--hot-takes")]
    p = suggest(positional[0], positional[1] if len(positional) > 1 else "",
                hot_takes=n_hot)
    print(json.dumps(p, indent=1))
