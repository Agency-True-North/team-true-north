"""The text style presets, resolved from the user's own style.

Every text layer, sound, and sticker here is defined by ROLE (hook font,
annotation entry sound, ...). The actual asset behind each role comes from
two places the user controls:

  style_map.json    role -> the NAME of the font / sound / animation /
                    sticker the user picked (any they like — see
                    src/style_roles.py)
  reference/*.json  the harvest of their STYLE_SETUP draft, which carries
                    the exact resource ids, machine-local cache paths, and
                    trims their own CapCut wrote

Names match case-insensitively as substrings, so "keyboard" finds
"Keyboard Typing 01". A role whose item isn't in the harvest resolves to
None and the builders skip it (silent entry / plain entry / no sticker) —
it never blocks a build. Fonts are the one exception: a build needs at
least one harvested font, and an unresolvable font role falls back to the
first harvested font with a printed note.

This module refuses to run (with a clear message) until the harvest has
been done: do the STYLE_SETUP ritual in START-HERE.md, then run
src/harvest_style.py.

transform.y: POSITIVE is higher on screen.

Layout: hook + yellow sub-line hold the top for the first ~5-10s; after the
hook exits, annotations take over that top slot. Captions sit at chest
height throughout.
"""

import json
import os

from style_roles import load_style_map, match_name

_REFERENCE_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "reference"
)

_STYLE = load_style_map()


def _load_reference(name):
    path = os.path.join(_REFERENCE_DIR, name)
    if not os.path.exists(path):
        return None
    with open(path, encoding="utf-8") as f:
        return json.load(f)


def _load_fonts():
    harvested = _load_reference("fonts.json")
    if not harvested:
        raise RuntimeError(
            "reference/fonts.json is missing or empty — the style harvest\n"
            "hasn't run, or STYLE_SETUP has no font applied yet. Apply at\n"
            "least one font (any font you like) to a text box in the\n"
            "STYLE_SETUP draft in CapCut, then run:\n"
            "  .venv/bin/python src/harvest_style.py STYLE_SETUP"
        )

    def font(role):
        wanted = _STYLE["fonts"].get(role)
        title = match_name(wanted, list(harvested))
        if title is None:
            title = next(iter(harvested))
            print(
                f'  ! no harvested font matches "{wanted}" (the "{role}" role) '
                f'— using "{title}". To change it: apply the font you want in '
                f"STYLE_SETUP, re-run src/harvest_style.py, and put its name "
                f"in style_map.json."
            )
        entry = harvested[title]
        return {
            "path": entry["path"],
            "id": entry.get("resource_id") or entry.get("id"),
            "title": title,
        }

    return font("hook"), font("body"), font("pop")


FONT_HOOK, FONT_BODY, FONT_POP = _load_fonts()

CREAM = (0.965, 0.949, 0.933)                              # hook serif
YELLOW = (1.0, 0.8901960849761963, 0.450980395078659)      # #FFE373
WHITE = (1.0, 1.0, 1.0)

PRESETS = {
    "hook":       {"font": FONT_HOOK, "size": 15.0, "color": CREAM,  "x": 0.0, "y": 0.65,  "scale": 0.91},
    "subline":    {"font": FONT_BODY, "size": 12.0, "color": YELLOW, "x": 0.0, "y": 0.51},
    "annotation": {"font": FONT_BODY, "size": 17.0, "color": WHITE,  "x": 0.0, "y": 0.60},
    "caption":    {"font": FONT_BODY, "size": 14.0, "color": WHITE,  "x": 0.0, "y": -0.30},
    # pop word: a caption word that needs to hit harder. Same slot, pop font.
    "pop":        {"font": FONT_POP,  "size": 14.0, "color": WHITE,  "x": 0.0, "y": -0.30},
    # "hot take" / "inner thoughts" / "hear me" label, only when instructed.
    # Tilted, upper-left; pairs with the underline sticker + the pop_whoosh
    # sound (whatever the user mapped to those roles).
    "hot_take":   {"font": FONT_BODY, "size": 15.0, "color": YELLOW,
                   "x": -0.6009174311926606, "y": 0.682170542635659,
                   "scale": 1.1698563675243907, "rotation": -31.941055535219327},
}


def _load_layer_animations():
    """Text in-animation spec ({name, resource_id, duration}) per layer,
    from the user's harvest. None = that layer just appears (no animation).
    All None when the user said no to animations in the style interview."""
    roles = ("hook", "subline", "annotation", "hot_take")
    if not _STYLE.get("use_animations", True):
        return {r: None for r in roles}
    harvested = _load_reference("animations.json") or {}
    by_name = {}
    for entry in harvested.values():
        if entry.get("carried_by") != "text":
            continue
        for an in entry["material"].get("animations", []):
            if an.get("name") and an["name"] not in by_name:
                by_name[an["name"]] = {
                    "name": an["name"],
                    "resource_id": an.get("resource_id") or an.get("id"),
                    "duration": an.get("duration", 500000),
                }

    def anim(role):
        name = match_name(_STYLE["animations"].get(role), list(by_name))
        return by_name.get(name) if name else None

    hook = anim("hook")
    text_in = anim("text_in")
    # A hook with no animation of its own still enters like the other text.
    return {
        "hook": hook or text_in,
        "subline": text_in,
        "annotation": text_in,
        "hot_take": text_in,
    }


# Which animation each layer enters with (captions are always bare).
LAYER_ANIMATIONS = _load_layer_animations()


def _load_sfx():
    """Sound effect per semantic role, resolved from the user's harvest.
    Trim and volume ride along in the harvested segment itself. None = that
    role is silent. All None when the user said no to sound effects in the
    style interview."""
    if not _STYLE.get("use_sfx", True):
        return {role: None for role in _STYLE["sfx"]}
    harvested = _load_reference("sound_effects.json") or {}
    by_name = {}
    for eid, entry in harvested.items():
        n = entry.get("name") or ""
        if n and n not in by_name:
            by_name[n] = eid
    out = {}
    for role, wanted in _STYLE["sfx"].items():
        n = match_name(wanted, list(by_name))
        out[role] = {"effect_id": by_name[n], "name": n} if n else None
    return out


# Semantic mapping (what plays when):
#   typing      -> hook entry
#   glitter     -> sub-line entry
#   swoosh      -> a text layer exiting the screen
#   pop         -> an annotation appearing
#   bell        -> emphasis annotation
#   pop_whoosh  -> hot take label entry
#   mouse_click -> EVERY numbered-list item as it enters (standing rule)
SFX = _load_sfx()


def _load_underline_sticker():
    """sticker_id for the hot-take underline, or None (no sticker placed)."""
    harvested = _load_reference("stickers.json") or {}
    by_name = {}
    for sid, entry in harvested.items():
        n = entry.get("name") or ""
        if n and n not in by_name:
            by_name[n] = sid
    n = match_name(_STYLE["stickers"].get("underline"), list(by_name))
    return by_name[n] if n else None


STICKER_UNDERLINE_ID = _load_underline_sticker()
