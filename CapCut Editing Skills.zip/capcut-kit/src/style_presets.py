"""The text style presets (kit edition).

The look was designed by hand in CapCut and harvested: fonts, animations,
sound effects, and stickers are identified by CapCut's own resource ids,
which are the same on every machine. The FILE PATHS to those resources are
machine-specific — CapCut caches a resource locally the first time it is
applied in the app.

That is why setup includes the STYLE_SETUP draft ritual (see START-HERE.md):
you apply each font/sound/animation/sticker once in your own CapCut, then
src/harvest_style.py reads YOUR cached paths out of that draft and writes
them into reference/. This module loads font paths from
reference/fonts.json — it will refuse to run (with a clear message) until
the harvest has been done.

transform.y: POSITIVE is higher on screen.

Layout: hook + yellow sub-line hold the top for the first ~5-10s; after the
hook exits, annotations take over that top slot. Captions sit at chest
height throughout.

To swap a font later: apply the new font to any text box in the STYLE_SETUP
draft in CapCut, re-run src/harvest_style.py, and change the title names
below.
"""

import json
import os

_REFERENCE_DIR = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "reference"
)

# Font titles as they appear in CapCut's font browser. If you swap a font,
# change the title here AND apply the new font once in STYLE_SETUP.
HOOK_FONT_TITLE = "Larken"
BODY_FONT_TITLE = "Ugly Dave"
POP_FONT_TITLE = "ZY Modern"


def _load_fonts():
    path = os.path.join(_REFERENCE_DIR, "fonts.json")
    if not os.path.exists(path):
        raise RuntimeError(
            "reference/fonts.json is missing — the style harvest hasn't run.\n"
            "Do the STYLE_SETUP draft ritual in START-HERE.md, then run:\n"
            "  .venv/bin/python src/harvest_style.py STYLE_SETUP"
        )
    with open(path, encoding="utf-8") as f:
        harvested = json.load(f)

    def font(title):
        entry = harvested.get(title)
        if not entry:
            raise RuntimeError(
                f'Font "{title}" is not in reference/fonts.json.\n'
                f"Apply it to a text box in the STYLE_SETUP draft in CapCut,\n"
                f"then re-run: .venv/bin/python src/harvest_style.py STYLE_SETUP\n"
                f"(harvested so far: {sorted(harvested)})"
            )
        return {
            "path": entry["path"],
            "id": entry.get("resource_id") or entry.get("id"),
            "title": title,
        }

    return font(HOOK_FONT_TITLE), font(BODY_FONT_TITLE), font(POP_FONT_TITLE)


FONT_HOOK, FONT_BODY, FONT_POP = _load_fonts()

CREAM = (0.965, 0.949, 0.933)                              # hook serif
YELLOW = (1.0, 0.8901960849761963, 0.450980395078659)      # #FFE373
WHITE = (1.0, 1.0, 1.0)

PRESETS = {
    "hook":       {"font": FONT_HOOK, "size": 15.0, "color": CREAM,  "x": 0.0, "y": 0.65,  "scale": 0.91},
    "subline":    {"font": FONT_BODY, "size": 12.0, "color": YELLOW, "x": 0.0, "y": 0.51},
    "annotation": {"font": FONT_BODY, "size": 17.0, "color": WHITE,  "x": 0.0, "y": 0.60},
    "caption":    {"font": FONT_BODY, "size": 14.0, "color": WHITE,  "x": 0.0, "y": -0.30},
    # pop word: a caption word that needs to hit harder. Same slot, pop font.
    "pop":        {"font": FONT_POP,  "size": 14.0, "color": WHITE,  "x": 0.0, "y": -0.30},
    # "hot take" / "inner thoughts" / "hear me" label, only when instructed.
    # Tilted, upper-left; pairs with the white double-underline sticker +
    # Pop Whoosh.
    "hot_take":   {"font": FONT_BODY, "size": 15.0, "color": YELLOW,
                   "x": -0.6009174311926606, "y": 0.682170542635659,
                   "scale": 1.1698563675243907, "rotation": -31.941055535219327},
}

# Text in-animations by CapCut resource id (same on every machine).
# duration is microseconds. start=0, applied as material_animations of type "in".
ANIM_BOUNCE_IN_TEXT = {"name": "Bounce In", "resource_id": "6887766069587481090", "duration": 500000}
ANIM_TYPING_CURSOR = {"name": "Typing Cursor", "resource_id": "7208392434831593985", "duration": 1366666}

# Which animation each layer enters with:
# hook types itself in, sub-line and annotations bounce in, captions are bare.
LAYER_ANIMATIONS = {
    "hook": ANIM_TYPING_CURSOR,
    "subline": ANIM_BOUNCE_IN_TEXT,
    "annotation": ANIM_BOUNCE_IN_TEXT,
    "hot_take": ANIM_BOUNCE_IN_TEXT,
}

# Sound effects by CapCut effect id (same on every machine; the cached audio
# file paths come from YOUR harvest in reference/sound_effects.json).
# Semantic mapping:
#   typing    -> hook entry (with the Typing Cursor animation)
#   glitter   -> sub-line entry
#   swoosh    -> a text layer exiting the screen (quiet)
#   pop       -> an annotation appearing
#   bell      -> emphasis annotation
#   pop_whoosh-> hot take label entry
#   mouse_click -> EVERY numbered-list item as it enters (standing rule)
SFX = {
    "typing":      {"effect_id": "7541601071157020682", "name": "Keyboard Typing 01", "volume": 1.0},
    "glitter":     {"effect_id": "6817556231327057922", "name": "Glitter glitter / Glocken beautiful rising sound", "volume": 0.93},
    "swoosh":      {"effect_id": "7529722916961634358", "name": "Title Swoosh", "volume": 0.2864932119846344},
    "mouse_click": {"effect_id": "7380059209545746473", "name": "Mouse click 1", "volume": 1.0},
    "bell":        {"effect_id": "7529761236524730418", "name": "Bell 02", "volume": 1.0},
    "pop_whoosh":  {"effect_id": "7517109130840426533", "name": "Pop Whoosh", "volume": 1.0},
    "pop":         {"effect_id": "6817210440771176450", "name": "Pop. Sound to open the lid, stopper, cap (high)", "volume": 0.5838122963905334},
}
