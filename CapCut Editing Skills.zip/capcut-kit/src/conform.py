"""Conform pyJianYingDraft output to YOUR CapCut's draft format.

The library targets an old draft format; current CapCut versions write a
newer one. The strategy: keep the library's timeline construction, then
fill every key YOUR reference draft (made by src/make_reference.py) has that the library output lacks,
using the reference's (generic) values as defaults. Media-specific reference
values are never copied — only keys missing from our output are added, and the
library always emits the media-specific ones itself.

Reference draft: made in YOUR CapCut during setup and snapshotted into
reference/ by src/make_reference.py. Re-run that after CapCut updates.
"""

import copy
import json
import os
import re

from capcut_env import REFERENCE_DIR, capcut_uuid

_HEX32 = re.compile(r"^[0-9a-f]{32}$")


def _load_reference():
    with open(os.path.join(REFERENCE_DIR, "draft_info.json"), encoding="utf-8") as f:
        return json.load(f)


def _fill_missing(ours: dict, ref: dict) -> None:
    """Add keys present in ref but absent from ours (deep-copied ref values)."""
    for key, value in ref.items():
        if key not in ours:
            ours[key] = copy.deepcopy(value)


def _uuidify_ids(node, mapping):
    """Rewrite library-style 32-hex ids to CapCut-style uppercase dashed UUIDs,
    consistently across the whole document (references must keep matching)."""
    if isinstance(node, dict):
        return {k: _uuidify_ids(v, mapping) for k, v in node.items()}
    if isinstance(node, list):
        return [_uuidify_ids(v, mapping) for v in node]
    if isinstance(node, str) and _HEX32.match(node):
        if node not in mapping:
            u = node.upper()
            mapping[node] = f"{u[0:8]}-{u[8:12]}-{u[12:16]}-{u[16:20]}-{u[20:32]}"
        return mapping[node]
    return node


def conform_draft_info(draft: dict, media_bin_id) -> dict:
    """Take pyJianYingDraft's dumped dict, return an reference-shaped draft_info.

    media_bin_id: a single id (one video) or a {media path: bin entry id}
    dict when the draft has b-roll overlays too."""
    ref = _load_reference()
    draft = _uuidify_ids(draft, {})

    # Top level: add reference-only keys, stamp identity/version/platform.
    _fill_missing(draft, ref)
    draft["id"] = capcut_uuid()
    draft["new_version"] = ref["new_version"]
    draft["version"] = ref["version"]
    draft["platform"] = copy.deepcopy(ref["platform"])
    draft["last_modified_platform"] = copy.deepcopy(ref["last_modified_platform"])

    # Material categories the reference has that the library doesn't emit.
    for category, value in ref["materials"].items():
        if category not in draft["materials"]:
            draft["materials"][category] = [] if isinstance(value, list) else copy.deepcopy(value)

    # Segments: fill reference-only keys from the reference video segment.
    ref_seg = ref["tracks"][0]["segments"][0]
    ref_track = ref["tracks"][0]
    for track in draft["tracks"]:
        _fill_missing(track, ref_track)
        if track["type"] == "video":
            for seg in track["segments"]:
                _fill_missing(seg, ref_seg)

    # Video materials: fill reference-only keys, link each to its media-bin entry.
    ref_video = ref["materials"]["videos"][0]
    for video in draft["materials"]["videos"]:
        _fill_missing(video, ref_video)
        if isinstance(media_bin_id, dict):
            video["local_material_id"] = media_bin_id.get(video["path"], "")
        else:
            video["local_material_id"] = media_bin_id
        video["material_name"] = os.path.basename(video["path"])

    return draft
