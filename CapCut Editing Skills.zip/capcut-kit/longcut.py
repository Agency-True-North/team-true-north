#!/usr/bin/env python
"""Long-form cleanup cut: raw 16:9 video -> plain CapCut draft, cuts only.

For masterclass-style recordings. Cuts filler words, dead pauses, and
mistakes/retakes/redundancies. NO text layers, sounds, or b-roll — the creator
adds captions herself in CapCut. Every cut is reversible there (segments
reference the full source; drag an edge to bring material back).

Usage:
  .venv/bin/python longcut.py <video path> [--name X] [--notes "..."]
                              [--no-smart] [--yes]
  .venv/bin/python longcut.py <video path> --propose-only
  .venv/bin/python longcut.py <video path> --from-proposal <file>

Filler and pause cuts are mechanical and always applied. The sonnet pass
proposes mistake/retake/redundancy cuts: "confident" ones (obvious flubs)
are pre-approved, "judgment" ones are asked at the gate. --no-smart skips
the sonnet pass entirely. --notes steers sonnet ("the section on pricing
was re-recorded, keep the second version").

For a driver (Claude) running the gate conversationally:
  --propose-only            plan + save + print JSON path, build nothing
  --from-proposal <file>    build using the JSON's "apply" flags as-is
"""

import json
import os
import subprocess
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from build_longform import build_plain_cut_draft
from capcut_env import PROJECTS_DIR
from smart_cuts import propose_smart_cuts
from tighten import _subtract, find_retakes, format_report, plan_cuts
from transcribe import transcribe

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
PROPOSALS_DIR = os.path.join(TOOL_DIR, "proposals")


def video_duration_s(video: str) -> float:
    out = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration",
         "-of", "csv=p=0", video], capture_output=True, text=True, check=True)
    return float(out.stdout.strip())


def unique_draft_name(base: str) -> str:
    name, n = base, 1
    while os.path.exists(os.path.join(PROJECTS_DIR, name)):
        n += 1
        name = f"{base} ({n})"
    return name


def stamp(t) -> str:
    return f"{int(t // 60)}:{int(t % 60):02d}" if t is not None else "??"


def final_keeps(words, duration: float, smart_cuts):
    """Mechanical keeps minus every approved smart cut."""
    keeps, report = plan_cuts(words, duration)
    applied = [(c["start"], c["end"]) for c in smart_cuts
               if c.get("apply") and c.get("resolved")]
    if applied:
        keeps = [(s, e) for s, e in _subtract(keeps, applied) if e - s > 0.2]
    return keeps, report


def show(smart_cuts, keeps, report, duration):
    print(format_report(keeps, report, duration).split("\n")[0])
    auto = [c for c in smart_cuts if c.get("apply")]
    ask = [c for c in smart_cuts if c.get("resolved") and not c.get("apply")]
    lost = [c for c in smart_cuts if not c.get("resolved")]
    if auto:
        print("\nCUTTING (confident — obvious flubs/retakes):")
        for c in auto:
            print(f"  {stamp(c['start'])}-{stamp(c['end'])}  [{c['reason']}]  "
                  f"\"{c.get('cut_text', '')}\"")
            print(f"      {c.get('why', '')}")
    if ask:
        print("\nASK — your call (numbered; not cut unless you say so):")
        for n, c in enumerate(ask, 1):
            print(f"  {n}. {stamp(c['start'])}-{stamp(c['end'])}  [{c['reason']}]  "
                  f"\"{c.get('cut_text', '')}\"")
            print(f"      {c.get('why', '')}")
    if lost:
        print("\nCOULD NOT PIN DOWN (mentioned but not cut — check by hand):")
        for c in lost:
            print(f"  ~{c.get('near', '?')}  [{c.get('reason', '?')}]  {c.get('why', '')}")
    return ask


def main() -> None:
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    video = args[0]
    base = os.path.splitext(os.path.basename(video))[0]
    name = args[args.index("--name") + 1] if "--name" in args else None
    notes = args[args.index("--notes") + 1] if "--notes" in args else ""
    no_smart = "--no-smart" in args
    auto_yes = "--yes" in args
    propose_only = "--propose-only" in args
    from_proposal = (args[args.index("--from-proposal") + 1]
                     if "--from-proposal" in args else None)

    duration = video_duration_s(video)
    transcript = transcribe(video)
    words = transcript["words"]

    if from_proposal:
        with open(from_proposal, encoding="utf-8") as f:
            smart = json.load(f)["cuts"]
    elif no_smart:
        smart = []
    else:
        print("Reading the transcript for retakes and flubs (sonnet)...")
        smart = propose_smart_cuts(words, find_retakes(words), notes)

    keeps, report = final_keeps(words, duration, smart)
    ask = show(smart, keeps, report, duration)

    os.makedirs(PROPOSALS_DIR, exist_ok=True)
    pfile = os.path.join(PROPOSALS_DIR, base + "_longcut.json")
    if not from_proposal:
        with open(pfile, "w", encoding="utf-8") as f:
            json.dump({"video": video, "notes": notes, "cuts": smart},
                      f, ensure_ascii=False, indent=1)

    if propose_only:
        print(f"\nPROPOSAL SAVED: {pfile}")
        return

    if not from_proposal and not auto_yes:
        while True:
            answer = input(
                "\nJudgment cuts to ALSO make (numbers like '1 3', 'all', "
                "'none')  [e] edit JSON  [q] quit: ").strip().lower()
            if answer == "q":
                sys.exit("Stopped. Nothing was written.")
            if answer == "e":
                input("Edit the file, save, then press Enter here...")
                with open(pfile, encoding="utf-8") as f:
                    smart = json.load(f)["cuts"]
                break
            if answer in ("none", ""):
                break
            picked = ask if answer == "all" else [
                ask[int(n) - 1] for n in answer.split() if n.isdigit()
                and 1 <= int(n) <= len(ask)]
            for c in picked:
                c["apply"] = True
            with open(pfile, "w", encoding="utf-8") as f:
                json.dump({"video": video, "notes": notes, "cuts": smart},
                          f, ensure_ascii=False, indent=1)
            break
        keeps, report = final_keeps(words, duration, smart)

    kept = sum(e - s for s, e in keeps)
    print(f"\nFinal: {duration:.1f}s -> {kept:.1f}s "
          f"(cut {duration - kept:.1f}s, {len(keeps)} segments)")
    draft_name = name or unique_draft_name(base)
    build_plain_cut_draft(video, keeps, draft_name)
    print(f"\nDone. Open CapCut and look for: {draft_name}")


if __name__ == "__main__":
    main()
