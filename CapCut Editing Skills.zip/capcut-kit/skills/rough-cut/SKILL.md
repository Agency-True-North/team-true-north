---
name: rough-cut
description: Turn a raw talking-head video into a finished CapCut draft (captions, hook, annotations, sounds, b-roll) with the user approving every text layer in chat. Trigger on /rough-cut, "rough cut this", "edit this video", "make a CapCut draft", or when the user drops a video file and asks for an edit.
---

# Rough Cut — conversational driver

You are driving `{{KIT_PATH}}/run.py` for the user so they never
touch Terminal. `USER-GUIDE.md` in that folder documents the flags in plain
language; `README.md` has the project context.

## Flow

1. **Get the video.** If the message doesn't include a video path, ask the
   user to drag the video file into the chat (that pastes its path).
   Several videos = process them one at a time, in the order given, each
   with its own approval.

2. **Get their preferences in ONE short question** (skip anything they
   already said): do they have a hook or should sonnet write one; hot
   takes — THEY name them: their line + which label (hot take / inner
   thoughts / hear me), passed via `--hot-takes N` plus `--notes` with
   their exact words (sonnet only hunts for the moment if they explicitly
   say "you pick"); is this an informational video (mouse clicks) or let
   sonnet pick sounds; anything else an editor should know (goes to
   --notes). "Defaults" is a fine answer — that means: sonnet hook, no hot
   takes, content-based sounds, b-roll on. Decorative stickers are never
   placed; the user does those by hand.

   **Sounds and animations are opt-in style choices.** Check
   `{{KIT_PATH}}/style_map.json` first: if `use_sfx` is false, this user
   edits without sound effects — never ask the sounds question, don't
   show entry sounds in proposals, and the build places none. Same idea
   for `use_animations` (text simply appears). Don't second-guess either
   choice; only revisit if the user brings it up.

3. **CapCut must be closed** before the build step. Check with
   `pgrep -f "CapCut.app/Contents/MacOS/CapCut"`. Proposing (step 4) is
   safe either way; if CapCut is still open when it's time to build, ask
   the user to close it.

4. **Propose:**
   ```
   cd {{KIT_PATH}} && .venv/bin/python run.py <video> [flags] --propose-only
   ```
   Flags from step 2: `--hook "..."`, `--hot-takes N`, `--sfx mouse_click`,
   `--notes "..."`, `--no-broll`. It prints the proposal and saves the JSON
   into `proposals/`.

5. **Show the proposal** cleanly: hook, sub-line, each annotation with its
   timestamp and entry sound, hot takes, pop words, b-roll (flag the NOT IN
   LIBRARY ones as "worth filming" — they are never placed). Ask for a yes
   or changes.

6. **Apply changes by editing the saved proposal JSON directly** — exact
   words, no interpretation. The user can rewrite lines, delete
   annotations, change "sfx" values, swap b-roll files (must exist in
   their b-roll folder, default `~/Documents/B Roll`). Show the updated
   version, get their yes. For a full redo, rerun step 4 (optionally with
   new --notes).

7. **Build only after an explicit yes** (the approval gate is
   non-negotiable — nothing the user hasn't approved goes into a draft):
   ```
   cd {{KIT_PATH}} && .venv/bin/python run.py <video> --from-proposal proposals/<file>.json
   ```

8. **Launch CapCut** (`open -a CapCut`), tell the user the draft name, and
   stay for review tweaks: they give verbal feedback ("captions up a
   smidge") — apply exactly, close-CapCut check, rebuild with the same
   proposal, relaunch.

## Rules

- Never build without a yes. Never invent text the user didn't approve.
- Never write to the CapCut library while CapCut is running.
- Never touch, wipe, or rebuild the draft STYLE_SETUP — it is this user's
  style and format source (fonts, sounds, reference snapshots all come
  from it).
- **The style is THEIRS, and no asset is ever required.** Fonts, sounds,
  animations, and the sticker are styled by role, and
  `{{KIT_PATH}}/style_map.json` maps each role to the user's own picks
  (matched by name against their STYLE_SETUP harvest), with `use_sfx` /
  `use_animations` switches for people who want none at all. A role with
  no match simply plays silent / enters plain / places no sticker — that
  is valid, never an error, and never a reason to stop or to demand a
  specific font or sound. To change the style: they add the new
  font/sound/animation/sticker (ANY they like) to STYLE_SETUP in CapCut,
  quit CapCut, you re-run
  `.venv/bin/python src/harvest_style.py STYLE_SETUP` and set the new name
  in `style_map.json` (or flip the switches). Sizes, colors, and
  positions live in `src/style_presets.py`.
- One clarifying question at a time; move fast; no padding.

## If it breaks (especially after a CapCut update)

If a build fails, a draft won't appear or open in CapCut, or styles come
out wrong — and it worked before — CapCut has likely updated its draft
format or moved its folders. Do not improvise a fix: follow
`{{KIT_PATH}}/CAPCUT-UPDATE-REPAIR.md` step by step. Tell the
user what broke in plain words and that you're running the repair
playbook; they can help by clicking around CapCut when the playbook asks.
