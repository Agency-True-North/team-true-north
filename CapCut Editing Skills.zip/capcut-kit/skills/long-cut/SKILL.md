---
name: long-cut
description: Clean up a long 16:9 video (masterclass style) into a plain CapCut draft — filler words, pauses, mistakes, and retakes cut; no captions or overlays, the user adds those themselves. Trigger on /long-cut, "long cut this", "clean up this masterclass", "cut the filler out of this video", or when the user drops a long/landscape video and asks for a cleanup edit (not a full rough cut).
---

# Long Cut — conversational driver

You are driving `{{KIT_PATH}}/longcut.py` for the user so they
never touch Terminal. This is the SIMPLE pipeline: cuts only, no text
layers. If they want hooks/captions/annotations, that's /rough-cut.
Plain-language guide: `USER-GUIDE.md` in that folder.

## Flow

1. **Get the video.** If the message doesn't include a video path, ask the
   user to drag it into the chat. Long videos are fine — transcription
   takes a few minutes, warn them once and get on with it.

2. **One optional question** (skip if already answered): anything the
   editor should know? ("the pricing section was re-recorded, keep the
   second version") — goes to `--notes`. "No" or silence = run with
   defaults.
   Pacing: the default is tight (cuts gaps over ~0.45s, calibrated to a
   real hand edit). Don't ask about it. Only add `--pace natural` if
   they want the video's natural rhythm kept ("keep the pauses", a
   meditation, a slow story).

   If the sonnet pass fails after retries, the run STOPS and says so —
   tell the user plainly and offer: retry, or build with `--no-smart`
   (pauses and fillers only) so they're never handed a silently
   half-checked cut.

3. **Propose:**
   ```
   cd {{KIT_PATH}} && .venv/bin/python longcut.py <video> [--notes "..."] --propose-only
   ```
   Fillers and pauses are cut automatically. Sonnet also proposes
   mistake/retake/redundancy cuts, saved to
   `proposals/<name>_longcut.json`: "confident" ones have `"apply": true`
   already; "judgment" ones have `"apply": false` and are the USER's call.

4. **Show the result** in plain language:
   - the totals line (source length -> cut length)
   - the confident cuts as a short list ("cutting these obvious flubs"),
     each with timestamp and what's being cut — no per-item approval
     needed, but the user sees the list and can veto any
   - each JUDGMENT call as a numbered question: timestamp, the words that
     would go, and why — get a yes/no per item (or "cut all" / "none")
   - anything UNRESOLVED as "flagged but couldn't pin down — check around
     [time] in CapCut"

5. **Apply the answers by editing the proposal JSON directly** — flip
   `"apply"` to true/false per their calls. Veto of a confident cut =
   `"apply": false`.

6. **CapCut must be closed to build.** Check
   `pgrep -f "CapCut.app/Contents/MacOS/CapCut"`; if open, ask the user to
   close it. Then:
   ```
   cd {{KIT_PATH}} && .venv/bin/python longcut.py <video> --from-proposal proposals/<file>.json
   ```

7. **Launch CapCut** (`open -a CapCut`), tell the user the draft name, and
   remind them: every cut is reversible — drag a segment edge to bring
   anything back. The cut list above tells them where to look.

## Rules

- Judgment cuts never happen without a yes. Confident cuts always shown
  before building.
- Never write to the CapCut library while CapCut is running.
- Never touch, wipe, or rebuild the draft STYLE_SETUP — it is this user's
  style and format source.
- The draft canvas matches the source video (16:9 stays 16:9).
- One question at a time; move fast; no padding.

## If it breaks (especially after a CapCut update)

If a build fails, a draft won't appear or open in CapCut, or clips show
offline — and it worked before — CapCut has likely updated its draft format
or moved its folders. Do not improvise a fix: follow
`{{KIT_PATH}}/CAPCUT-UPDATE-REPAIR.md` step by step. Tell the
user what broke in plain words; their footage is never at risk (drafts only
reference the source file).
