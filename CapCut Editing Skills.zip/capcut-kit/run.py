#!/usr/bin/env python
"""One command: raw video -> finished CapCut rough cut, approval-gated.

Usage:
  .venv/bin/python run.py <video path> [--hook "Your stated hook"] [--name X]
                          [--hot-takes N] [--sfx pop|mouse_click|bell]
                          [--notes "anything sonnet should know"] [--no-broll]
  .venv/bin/python run.py <video path> --yes        (skip gate; testing only)

--sfx forces every annotation's entry sound (e.g. --sfx mouse_click for an
informational video). Without it, sonnet picks per annotation from the
content: mouse_click for points being taught, pop for emotional beats, bell
for the single biggest emphasis. Numbered list items always mouse click.

--notes is free-text steering for sonnet ("this one's a teaching video",
"suggest b-roll of me at the beach", "no hot takes, keep it gentle").

B-roll: if ~/Documents/B Roll exists (override with the BROLL_DIR env var),
sonnet proposes cutaways matched to those files by name; when nothing in the
library fits it suggests what to film instead (shown at the gate, never
placed). --no-broll skips all of it.

For a driver (Claude) that runs the gate conversationally instead:
  --propose-only            propose + save + print JSON path, build nothing
  --from-proposal <file>    skip proposing, build from an approved JSON

Flow: transcribe (cached) -> tighten plan -> propose hook/subline/annotations
/pop words/b-roll (and hot takes if you asked) -> YOU approve (or edit the
JSON it points you at) -> draft written -> open CapCut. Close CapCut first.
"""

import json
import os
import sys

sys.path.insert(0, os.path.join(os.path.dirname(os.path.abspath(__file__)), "src"))

from capcut_env import PROJECTS_DIR
from suggest import suggest
from build_full import build_full_draft

TOOL_DIR = os.path.dirname(os.path.abspath(__file__))
PROPOSALS_DIR = os.path.join(TOOL_DIR, "proposals")
BROLL_DIR = os.path.expanduser(os.environ.get("BROLL_DIR", "~/Documents/B Roll"))
BROLL_EXTENSIONS = (".mp4", ".mov", ".m4v")


def broll_library():
    if not os.path.isdir(BROLL_DIR):
        return []
    return sorted(f for f in os.listdir(BROLL_DIR)
                  if f.lower().endswith(BROLL_EXTENSIONS))


def resolve_broll_paths(proposals):
    """Turn approved library filenames into absolute paths for the build."""
    for b in proposals.get("broll", []):
        if b.get("file"):
            path = os.path.join(BROLL_DIR, b["file"])
            b["path"] = path if os.path.exists(path) else None
    return proposals


def unique_draft_name(base: str) -> str:
    name, n = base, 1
    while os.path.exists(os.path.join(PROJECTS_DIR, name)):
        n += 1
        name = f"{base} ({n})"
    return name


def main() -> None:
    args = sys.argv[1:]
    if not args:
        sys.exit(__doc__)
    video = args[0]
    hook = args[args.index("--hook") + 1] if "--hook" in args else ""
    auto_yes = "--yes" in args
    base = os.path.splitext(os.path.basename(video))[0]
    name = args[args.index("--name") + 1] if "--name" in args else None
    hot_takes = int(args[args.index("--hot-takes") + 1]) if "--hot-takes" in args else 0
    sfx_override = args[args.index("--sfx") + 1] if "--sfx" in args else None
    notes = args[args.index("--notes") + 1] if "--notes" in args else ""
    broll = [] if "--no-broll" in args else broll_library()
    propose_only = "--propose-only" in args
    from_proposal = (args[args.index("--from-proposal") + 1]
                     if "--from-proposal" in args else None)

    os.makedirs(PROPOSALS_DIR, exist_ok=True)
    pfile = os.path.join(PROPOSALS_DIR, base + ".json")

    if from_proposal:
        with open(from_proposal, encoding="utf-8") as f:
            proposals = json.load(f)
        draft_name = name or unique_draft_name(base)
        build_full_draft(video, resolve_broll_paths(proposals), draft_name)
        print(f"\nDone. Open CapCut and look for: {draft_name}")
        return

    def apply_sfx_override(proposals):
        if sfx_override:
            for a in proposals.get("annotations", []):
                a["sfx"] = sfx_override
        return proposals

    def show(proposals):
        print(f"\nHOOK:     {proposals['hook']}")
        print(f"SUB-LINE: {proposals.get('subline', '')}")
        for a in proposals.get("annotations", []):
            t = a.get("time")
            stamp = f"{int(t // 60)}:{int(t % 60):02d}" if t is not None else "??"
            print(f"  {stamp}  ({a.get('sfx', 'pop')})  {a['text']}")
        for h in proposals.get("hot_takes", []):
            t = h.get("time")
            stamp = f"{int(t // 60)}:{int(t % 60):02d}" if t is not None else "??"
            print(f"  {stamp}  [{h.get('label', 'hot take')}]  {h['text']}")
        pops = [pw["word"] for pw in proposals.get("pop_words", [])
                if pw.get("time") is not None]
        if pops:
            print(f"POP WORDS: {', '.join(pops)}")
        if proposals.get("broll"):
            print("B-ROLL:")
            for b in proposals["broll"]:
                t = b.get("time")
                stamp = f"{int(t // 60)}:{int(t % 60):02d}" if t is not None else "??"
                if b.get("file"):
                    print(f"  {stamp}  {b.get('seconds', 2)}s  {b['file']}")
                else:
                    print(f"  {stamp}  NOT IN LIBRARY — film: {b.get('idea', '?')}")

    print("Proposing text layers (sonnet)...")
    proposals = apply_sfx_override(suggest(video, hook, hot_takes, broll, notes))
    with open(pfile, "w", encoding="utf-8") as f:
        json.dump(proposals, f, ensure_ascii=False, indent=1)
    show(proposals)

    if propose_only:
        print(f"\nPROPOSAL SAVED: {pfile}")
        return

    while not auto_yes:
        answer = input(
            f"\n[y] approve  [e] edit {os.path.relpath(pfile, TOOL_DIR)} then "
            "re-read  [r] regenerate  [q] quit: ").strip().lower()
        if answer == "y":
            break
        if answer == "e":
            input("Edit the file, save, then press Enter here...")
            with open(pfile, encoding="utf-8") as f:
                proposals = json.load(f)
            break
        if answer == "r":
            proposals = apply_sfx_override(suggest(video, hook, hot_takes,
                                                   broll, notes))
            with open(pfile, "w", encoding="utf-8") as f:
                json.dump(proposals, f, ensure_ascii=False, indent=1)
            show(proposals)
            continue
        if answer == "q":
            sys.exit("Stopped. Nothing was written.")

    draft_name = name or unique_draft_name(base)
    build_full_draft(video, resolve_broll_paths(proposals), draft_name)
    print(f"\nDone. Open CapCut and look for: {draft_name}")


if __name__ == "__main__":
    main()
