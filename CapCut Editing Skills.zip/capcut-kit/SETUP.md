# SETUP.md — instructions for Claude

You are setting up the CapCut Cut Kit on this person's Mac. Assume they are
NOT technical: they may never have opened Terminal, and they should never
have to. You run every command; they only click things in CapCut and paste
one key. Talk in plain words, one step and one question at a time, no
jargon. START-HERE.md is the human-facing version of this process — keep
your language consistent with it.

## What you're setting up

Two Claude Code skills that turn raw videos into editable CapCut drafts:

- **/long-cut** — long 16:9 videos: cuts filler words, pauses, flubs, and
  retakes. No text layers.
- **/rough-cut** — short talking-head videos: full treatment (captions,
  hook, annotations, sounds, b-roll), everything approved in chat first.

Long-cut needs steps 1–6. Rough-cut additionally needs the style step (7).
Ask early: "Do you want just the long-video cleanup for now, or also the
short-form rough cut with captions and sounds? The rough cut adds a
10-minute one-time step in CapCut." Set up accordingly; they can add
rough-cut later by doing step 7 anytime.

## Step 1 — Confirm the kit's location

The kit must live directly inside the user's main Claude folder — the same
folder that holds their `ABOUT ME` and `PROJECTS` folders and their
`CLAUDE.md` (from the Claude Setup Guide). It can be on their Desktop or in
Documents; the location varies person to person, so never assume one.

Since you're running inside the folder already (they opened Claude Code
here), get its absolute path:

    pwd

Call this `$KIT_PATH` — you'll bake it into the installed skills in Step 6,
so the commands always point at wherever this person's kit actually lives,
never a guessed path.

Sanity-check the location: look for `ABOUT ME`, `PROJECTS`, or `CLAUDE.md`
as siblings one level up from this folder. If none of those are there, this
folder probably isn't inside their Claude folder yet — pause and tell them
plainly: "Drag this whole capcut-kit folder into your Claude folder, the
one with ABOUT ME and PROJECTS in it, then reopen Claude Code inside it and
paste the setup message again." Don't continue setup from the wrong
location.

## Step 2 — System checks

Verify, fixing what you can yourself:

- macOS (this kit is Mac-only; if not macOS, stop and say so kindly).
- CapCut desktop installed (`/Applications/CapCut.app`). If missing, have
  them install it from capcut.com and open it once (it needs to create its
  folders). The projects folder proves it ran:
  `~/Movies/CapCut/User Data/Projects/com.lveditor.draft/`.
- `python3` available (macOS ships one; Xcode CLT prompt may appear — tell
  them to click Install if a dialog pops up).
- `ffmpeg` and `ffprobe` on PATH. If missing: install via Homebrew
  (`brew install ffmpeg`). If Homebrew itself is missing, explain in one
  sentence that you need to install a free helper tool, that the Mac will
  ask for their computer password, and that the password prompt is normal.
  Then install Homebrew, then ffmpeg.
- The `claude` CLI works (`claude --version`) — the kit calls it for the
  AI editing passes; it uses their existing Claude subscription, no extra
  key.

## Step 3 — Python environment

    cd $KIT_PATH
    python3 -m venv .venv
    .venv/bin/pip install -r requirements.txt

## Step 4 — Deepgram key (transcription)

The kit transcribes videos with Deepgram. They need their own free key.
Walk them through it in plain words:

1. Go to console.deepgram.com and create a free account (Google sign-in is
   fine). New accounts include free credit; a typical video costs about a
   cent to transcribe.
2. In the Deepgram dashboard, find "API Keys", create a key, copy it.
3. Paste the key into the chat.

Then write it to `.env` yourself (copy `.env.example` to `.env` and fill
in `DEEPGRAM_API_KEY=<their key>`). Remind them not to share that key with
anyone.

## Step 5 — The STYLE_SETUP draft (their CapCut, their machine)

The kit copies CapCut's file format from a real draft made by THEIR CapCut,
so it always matches their version. They must make one draft named exactly
`STYLE_SETUP`.

- **Long-cut only:** the draft just needs one video clip dragged onto the
  timeline first, plus one text box (any word). Guide them: new project in
  CapCut → drag any short video in and onto the timeline → add one text
  box → back on the home screen, rename the project to STYLE_SETUP (three
  dots on the project tile → Rename) → quit CapCut completely (Cmd+Q).
- **Rough-cut too:** the same draft also carries the style pieces, and
  THE STYLE IS THEIRS — the kit's default look is a suggestion, never a
  requirement. Run the STYLE INTERVIEW first, then turn their answers
  into a personalized clicking list. One question at a time, in this
  order, plain words:

  1. "What font do you want for your hook — the big opening line at the
     top of the video?" (Default look: Larken. Any font they love is the
     right answer, including one already in their CapCut.)
  2. "What font for your captions and on-screen notes?" (Default: Ugly
     Dave. Same font as the hook is fine.) Emphasized caption words use
     the caption font unless they name a third (default: ZY Modern) —
     only mention this if they seem into fonts; don't add a question.
  3. "Do you use sound effects — little sounds when text pops in or a
     list item lands? Totally fine to say no; plenty of creators edit
     silent." If NO: set `"use_sfx": false` in style_map.json and skip
     every sound step below — never revisit it unless they bring it up.
     If YES: there are up to seven sound moments (hook entering, sub-line
     entering, text leaving, list items clicking in, an emphasis ding,
     the hot-take whoosh, notes popping in — see ROLE_NOTES in
     src/style_roles.py). Offer the defaults as one option, their own
     picks as the other; any subset is fine, skipped moments stay silent.
  4. "Do you want entrance animations on the text — like the hook typing
     itself in — or should text just appear?" If NO:
     `"use_animations": false`, skip animation steps. If YES: one
     animation for text entering (default: Bounce In) and, if they want,
     a different one for the hook (default: Typing Cursor).
  5. If (and only if) hot-take labels came up and they want the
     underline: an underline sticker (default: Two White Underline).
     Otherwise set `"stickers": {"underline": null}`.

  Write their answers to `style_map.json` at the kit root NOW, before any
  harvest (src/style_roles.py documents the format — role names map to
  the NAMES of their picks, matched loosely, so their words are enough).
  Then prompt them to build the sample: give them their own short CapCut
  checklist from those answers — video clip FIRST (so the video track is
  track 1), one text box per chosen font, their animations applied to a
  text box each, each chosen sound added anywhere on the timeline, the
  sticker if any. If something they wanted doesn't exist in their CapCut
  (catalogs differ by region and change over time), a similar one they
  like is always right — update style_map.json to what they actually
  chose, and never treat a substitution or a skipped item as a problem.

When they say done:

    .venv/bin/python src/make_reference.py STYLE_SETUP

If it reports problems, translate them to plain words and guide the fix.

## Step 6 — Install the skills

Copy the two skill folders to their user-level skills directory so they
work in any Claude Code session, then bake in this person's actual
`$KIT_PATH` (from Step 1) so the commands never point at a guessed path:

    mkdir -p ~/.claude/skills
    cp -R skills/rough-cut skills/long-cut ~/.claude/skills/
    sed -i '' "s|{{KIT_PATH}}|$KIT_PATH|g" ~/.claude/skills/rough-cut/SKILL.md
    sed -i '' "s|{{KIT_PATH}}|$KIT_PATH|g" ~/.claude/skills/long-cut/SKILL.md

Confirm the substitution took — grep the installed files for `{{KIT_PATH}}`
and make sure nothing comes back. If something does, fix it by hand before
moving on; a leftover placeholder means every command in that skill will
fail.

(If they only want long-cut for now, still copy both — rough-cut just
won't work until step 7 is done, and its error message says exactly that.)

## Step 7 — Style harvest (rough-cut only)

After the full STYLE_SETUP checklist from START-HERE.md is done and CapCut
is closed:

    .venv/bin/python src/harvest_style.py STYLE_SETUP

It harvests EVERYTHING in the draft (their picks, whatever those are) and
maps it onto the style roles using `style_map.json` — the file you wrote
from the style interview in step 5 (created from the defaults if it
somehow doesn't exist). Roles they turned off (`use_sfx` /
`use_animations` false, or a role set to null) are reported as [off] and
never nagged about. The only hard requirements are one text box and one
font; the script exits nonzero only for those.

Then tie off any loose ends, still interview style:

- The report lists any unfilled roles and any harvested items not mapped
  to a role. If a pick didn't auto-match (normal — CapCut names run
  long), ask in plain words, one question at a time — e.g. "You added a
  sound called Sparkle. Want that as the sound when a note pops in, or
  somewhere else?" — then edit `style_map.json` yourself with their
  answers.
- An unfilled role is a valid choice, not an error: it just means that
  moment plays silent / that text enters plain / no sticker. Offer once,
  don't insist.
- NEVER block setup because some exact font, sound, animation, or sticker
  can't be found in their CapCut. There are no required assets. If they
  want something they couldn't find, help them pick a similar one they
  like, add it to STYLE_SETUP, re-run the harvest, and map it.

Also create their b-roll folder and explain it:

    mkdir -p ~/Documents/B\ Roll

"Drop short clips of yourself in here with descriptive filenames like
'me working at laptop.mp4' — that's how the editor finds matching footage."

## Step 8 — Prove it works

Ask for any short video (they can drag it into the chat). Run the long-cut
pipeline on it end to end (`longcut.py <video> --no-smart` is fine for the
test), confirm CapCut is closed first, build, then `open -a CapCut` and ask
them to check: the draft appears in the list, opens, and plays. If they set
up rough-cut, do one full /rough-cut flow on the same video with their
approval at the gate.

Delete test drafts they don't want (`src/build_video.py --remove <name>`
plus removing the draft folder, CapCut closed) — but NEVER STYLE_SETUP.

## Step 9 — Hand it over

Tell them, in their language:

- Type `/rough-cut` or `/long-cut` in Claude Code and drag a video in.
  That's the whole workflow. USER-GUIDE.md is their reference.
- Close CapCut before builds (Claude always reminds them).
- Never delete the STYLE_SETUP project in CapCut — the kit depends on it.
- If CapCut updates and something breaks, just tell Claude "this worked
  before, CapCut updated" — CAPCUT-UPDATE-REPAIR.md takes it from there.

## Updating an existing install

If this person already has the kit working and was told there's a new
version (they'll say something like "update my CapCut kit"), do NOT rerun
the whole setup. Their `.env` (Deepgram key), `.venv`, `reference/`
snapshots, `style_map.json`, and STYLE_SETUP draft are all still good.

1. Get the new kit. Either they downloaded the new zip already, or you
   download it yourself:

       curl -L -o /tmp/capcut-kit-update.zip "https://agency-true-north.github.io/team-true-north/CapCut%20Editing%20Skills.zip"
       unzip -o -q /tmp/capcut-kit-update.zip -d /tmp/capcut-kit-update

2. Copy the new code and docs OVER their existing kit folder — never
   delete the folder itself, that would take `.env`, `.venv`, and their
   harvested style with it:

       rsync -a --delete /tmp/capcut-kit-update/capcut-kit/src/ "$KIT_PATH/src/"
       rsync -a --delete /tmp/capcut-kit-update/capcut-kit/skills/ "$KIT_PATH/skills/"
       cp /tmp/capcut-kit-update/capcut-kit/*.py \
          /tmp/capcut-kit-update/capcut-kit/*.md \
          /tmp/capcut-kit-update/capcut-kit/requirements.txt \
          "$KIT_PATH/"

   (`--delete` clears out modules removed in the new version; it only
   touches `src/` and `skills/`, never their `.env`, `.venv`,
   `reference/`, or `style_map.json`.)

3. Reinstall the skills (repeat step 6 exactly: copy to
   `~/.claude/skills`, substitute `{{KIT_PATH}}`, verify no placeholder
   remains).

4. If there's no `style_map.json` in their kit yet (true for anyone who
   set up before the style interview existed), run the style interview
   from step 5 now — their STYLE_SETUP draft already exists, so this is
   just the questions (fonts, sound effects yes/no, animations yes/no),
   writing `style_map.json`, and re-running
   `.venv/bin/python src/harvest_style.py STYLE_SETUP` with CapCut
   closed. If they'd been forced into default picks they never wanted,
   this is the moment they get their own: anything they'd rather change,
   change it now.

5. Confirm with one quick `/rough-cut` or `/long-cut` run.

## Rules for you, the setting-up Claude

- Never write to the CapCut library while CapCut is running.
- Never touch any draft that isn't yours; only ever remove drafts you
  created during this setup, with the user's ok.
- One question at a time. Plain words. No jargon they didn't use first.
- Their Deepgram key goes in `.env` and nowhere else. Never echo it back
  into the chat once saved.
