# SETUP.md — instructions for Claude

You are setting up the CapCut Cut Kit on this person's Mac. Assume they are
NOT technical: they may never have opened Terminal, and they should never
have to. You run every command; they only click things in CapCut and paste
one key. Talk in plain words, one step and one question at a time, no
jargon. START-HERE.md is the human-facing version of this process — keep
your language consistent with it.

## What you're setting up

Two Claude Code skills that turn raw videos into editable CapCut drafts:

- **/long-cut** — long 16:9 videos: cuts filler words, pauses, flubs, and
  retakes. No text layers.
- **/rough-cut** — short talking-head videos: full treatment (captions,
  hook, annotations, sounds, b-roll), everything approved in chat first.

Long-cut needs steps 1–6. Rough-cut additionally needs the style step (7).
Ask early: "Do you want just the long-video cleanup for now, or also the
short-form rough cut with captions and sounds? The rough cut adds a
10-minute one-time step in CapCut." Set up accordingly; they can add
rough-cut later by doing step 7 anytime.

## Step 1 — Confirm the kit's location

The kit must live directly inside the user's main Claude folder — the same
folder that holds their `ABOUT ME` and `PROJECTS` folders and their
`CLAUDE.md` (from the Claude Setup Guide). It can be on their Desktop or in
Documents; the location varies person to person, so never assume one.

Since you're running inside the folder already (they opened Claude Code
here), get its absolute path:

    pwd

Call this `$KIT_PATH` — you'll bake it into the installed skills in Step 6,
so the commands always point at wherever this person's kit actually lives,
never a guessed path.

Sanity-check the location: look for `ABOUT ME`, `PROJECTS`, or `CLAUDE.md`
as siblings one level up from this folder. If none of those are there, this
folder probably isn't inside their Claude folder yet — pause and tell them
plainly: "Drag this whole capcut-kit folder into your Claude folder, the
one with ABOUT ME and PROJECTS in it, then reopen Claude Code inside it and
paste the setup message again." Don't continue setup from the wrong
location.

## Step 2 — System checks

Verify, fixing what you can yourself:

- macOS (this kit is Mac-only; if not macOS, stop and say so kindly).
- CapCut desktop installed (`/Applications/CapCut.app`). If missing, have
  them install it from capcut.com and open it once (it needs to create its
  folders). The projects folder proves it ran:
  `~/Movies/CapCut/User Data/Projects/com.lveditor.draft/`.
- `python3` available (macOS ships one; Xcode CLT prompt may appear — tell
  them to click Install if a dialog pops up).
- `ffmpeg` and `ffprobe` on PATH. If missing: install via Homebrew
  (`brew install ffmpeg`). If Homebrew itself is missing, explain in one
  sentence that you need to install a free helper tool, that the Mac will
  ask for their computer password, and that the password prompt is normal.
  Then install Homebrew, then ffmpeg.
- The `claude` CLI works (`claude --version`) — the kit calls it for the
  AI editing passes; it uses their existing Claude subscription, no extra
  key.

## Step 3 — Python environment

    cd $KIT_PATH
    python3 -m venv .venv
    .venv/bin/pip install -r requirements.txt

## Step 4 — Deepgram key (transcription)

The kit transcribes videos with Deepgram. They need their own free key.
Walk them through it in plain words:

1. Go to console.deepgram.com and create a free account (Google sign-in is
   fine). New accounts include free credit; a typical video costs about a
   cent to transcribe.
2. In the Deepgram dashboard, find "API Keys", create a key, copy it.
3. Paste the key into the chat.

Then write it to `.env` yourself (copy `.env.example` to `.env` and fill
in `DEEPGRAM_API_KEY=<their key>`). Remind them not to share that key with
anyone.

## Step 5 — The STYLE_SETUP draft (their CapCut, their machine)

The kit copies CapCut's file format from a real draft made by THEIR CapCut,
so it always matches their version. They must make one draft named exactly
`STYLE_SETUP`.

- **Long-cut only:** the draft just needs one video clip dragged onto the
  timeline first, plus one text box (any word). Guide them: new project in
  CapCut → drag any short video in and onto the timeline → add one text
  box → back on the home screen, rename the project to STYLE_SETUP (three
  dots on the project tile → Rename) → quit CapCut completely (Cmd+Q).
- **Rough-cut too:** the same draft also carries the style pieces — walk
  them through the full checklist in START-HERE.md ("The style setup, step
  by step"). Same start (video clip FIRST, so the video track is track 1),
  then the fonts, animations, sounds, and sticker.

When they say done:

    .venv/bin/python src/make_reference.py STYLE_SETUP

If it reports problems, translate them to plain words and guide the fix.

## Step 6 — Install the skills

Copy the two skill folders to their user-level skills directory so they
work in any Claude Code session, then bake in this person's actual
`$KIT_PATH` (from Step 1) so the commands never point at a guessed path:

    mkdir -p ~/.claude/skills
    cp -R skills/rough-cut skills/long-cut ~/.claude/skills/
    sed -i '' "s|{{KIT_PATH}}|$KIT_PATH|g" ~/.claude/skills/rough-cut/SKILL.md
    sed -i '' "s|{{KIT_PATH}}|$KIT_PATH|g" ~/.claude/skills/long-cut/SKILL.md

Confirm the substitution took — grep the installed files for `{{KIT_PATH}}`
and make sure nothing comes back. If something does, fix it by hand before
moving on; a leftover placeholder means every command in that skill will
fail.

(If they only want long-cut for now, still copy both — rough-cut just
won't work until step 7 is done, and its error message says exactly that.)

## Step 7 — Style harvest (rough-cut only)

After the full STYLE_SETUP checklist from START-HERE.md is done and CapCut
is closed:

    .venv/bin/python src/harvest_style.py STYLE_SETUP

It prints a checklist of found/missing pieces. For anything MISSING, tell
them in plain words what to add in CapCut (the exact search name), have
them save and quit CapCut, and re-run. Repeat until it says style setup is
complete.

Also create their b-roll folder and explain it:

    mkdir -p ~/Documents/B\ Roll

"Drop short clips of yourself in here with descriptive filenames like
'me working at laptop.mp4' — that's how the editor finds matching footage."

## Step 8 — Prove it works

Ask for any short video (they can drag it into the chat). Run the long-cut
pipeline on it end to end (`longcut.py <video> --no-smart` is fine for the
test), confirm CapCut is closed first, build, then `open -a CapCut` and ask
them to check: the draft appears in the list, opens, and plays. If they set
up rough-cut, do one full /rough-cut flow on the same video with their
approval at the gate.

Delete test drafts they don't want (`src/build_video.py --remove <name>`
plus removing the draft folder, CapCut closed) — but NEVER STYLE_SETUP.

## Step 9 — Hand it over

Tell them, in their language:

- Type `/rough-cut` or `/long-cut` in Claude Code and drag a video in.
  That's the whole workflow. USER-GUIDE.md is their reference.
- Close CapCut before builds (Claude always reminds them).
- Never delete the STYLE_SETUP project in CapCut — the kit depends on it.
- If CapCut updates and something breaks, just tell Claude "this worked
  before, CapCut updated" — CAPCUT-UPDATE-REPAIR.md takes it from there.

## Rules for you, the setting-up Claude

- Never write to the CapCut library while CapCut is running.
- Never touch any draft that isn't yours; only ever remove drafts you
  created during this setup, with the user's ok.
- One question at a time. Plain words. No jargon they didn't use first.
- Their Deepgram key goes in `.env` and nowhere else. Never echo it back
  into the chat once saved.
