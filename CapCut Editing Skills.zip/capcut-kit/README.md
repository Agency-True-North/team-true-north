# CapCut Cut Kit

Two Claude Code skills that turn raw video into editable CapCut drafts,
with every creative decision approved by the human in chat:

- **/long-cut** — long 16:9 videos: filler words, dead pauses, flubs, and
  retakes cut. Plain draft, no text layers, every cut reversible.
- **/rough-cut** — short talking-head videos: word captions, typed-in
  hook, timed annotations with entry sounds, optional hot-take labels,
  pop words, and b-roll from the user's own library.

**New here? Read START-HERE.md.** It's the plain-language guide and it
hands setup to Claude (SETUP.md is Claude's script for that). USER-GUIDE.md
is the daily-use manual. CAPCUT-UPDATE-REPAIR.md is the fix-it playbook
for when a CapCut app update changes the draft format.

## Requirements

- macOS with the CapCut desktop app
- Claude Code (paid Claude plan) — the AI passes run through the user's
  own `claude` CLI, no API key needed
- A free Deepgram account (transcription; the user's own key in `.env`)
- ffmpeg (setup installs it)

## How it works

- Transcription: Deepgram, word-level timestamps, cached in `transcripts/`.
- Cut planning: mechanical filler/pause detection plus a Claude pass for
  mistakes/retakes/redundancies. Everything lands in a proposal JSON in
  `proposals/` that the user approves (or edits) before any build.
- Draft building: pyJianYingDraft constructs the timeline; `src/conform.py`
  then fills every format detail from reference snapshots of a draft the
  user's own CapCut wrote (`src/make_reference.py`). Styles (fonts, sounds,
  animations, stickers) are harvested from the user's one-time STYLE_SETUP
  draft (`src/harvest_style.py`), so all cached resource paths are their
  machine's own.
- Safety: no writes while CapCut is running; `root_meta_info.json` backed
  up before every write; atomic writes; only `ZZTEST_`-prefixed drafts can
  ever be wiped; the STYLE_SETUP draft is never touched.

## Layout

    START-HERE.md            plain-language guide for the new user
    SETUP.md                 setup script for Claude to execute
    USER-GUIDE.md            daily-use manual
    CAPCUT-UPDATE-REPAIR.md  repair playbook after CapCut updates
    skills/                  the two SKILL.md files (installed to ~/.claude/skills)
    run.py                   rough-cut pipeline entry
    longcut.py               long-cut pipeline entry
    src/                     pipeline modules
    reference/               the user's harvested format/style snapshots
    proposals/ transcripts/ backups/   working dirs (start empty)
