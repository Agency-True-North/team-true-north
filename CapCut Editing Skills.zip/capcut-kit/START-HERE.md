# Start Here

This kit gives you two editing helpers inside Claude Code:

- **/long-cut** cleans up a long video. It cuts filler words, dead pauses,
  flubs, and retakes. You get a plain CapCut draft ready for captions.
- **/rough-cut** turns a short talking-head video into a finished CapCut
  draft: captions, a hook, on-screen notes, sounds, and b-roll. You
  approve every word in chat before anything is built.

You never touch code. You never open Terminal. Claude does all of that.
Your job is this checklist, and most of it is clicking around CapCut.

## What you need

1. A Mac. This kit is Mac only.
2. The CapCut desktop app, installed from capcut.com. Open it once after
   installing.
3. Claude Code with a paid Claude plan. Get it at claude.com/code and sign
   in. The desktop app is the easiest way to use it.
4. About 30 minutes for setup. You only do this once.

## The one sentence that does the setup

1. Put this whole folder inside your Claude folder — the same folder that
   holds your ABOUT ME and PROJECTS folders. Name it exactly: capcut-kit.
   (No Claude folder yet? Create one anywhere you'll remember, called
   Claude, and put this inside it.)
2. Open Claude Code and open that folder.
3. Copy and paste this message to Claude:

> Read SETUP.md in this folder and set everything up for me. I am not
> technical. Go slow, one step at a time, and tell me exactly what to
> click.

That's it. Claude takes over. Along the way it will ask you to do a few
human things it can't do for you:

- Create a free Deepgram account (that's the transcription service) and
  paste one key into the chat. Claude gives you the exact steps.
- Your Mac may ask for your computer password once while Claude installs a
  free helper tool. That's normal.
- Answer a short style interview (your fonts, whether you want sound
  effects and animations at all, and which ones if so), then build one
  special CapCut project called STYLE_SETUP from your answers. Details
  below; Claude walks you through all of it.

## The style setup: your style, in an interview

This is the one-time step that teaches the kit YOUR look. Nothing about it
is fixed: every font, sound, animation, and sticker in your videos is your
pick, and skipping any of them is a real choice, not a workaround. Claude
interviews you first, then hands you a short personal clicking list for
CapCut built from your answers.

The questions Claude will ask, so you can think ahead:

1. What font do you want for your hook, the big opening line?
2. What font for your captions and on-screen notes?
3. Do you use sound effects, little sounds when text pops in or a list
   item lands? No is a normal answer. Plenty of creators edit silent, and
   if you say no, sounds never come up again.
4. Do you want entrance animations on the text, like the hook typing
   itself in, or should text just appear?

If you say yes to sounds or animations, Claude asks which ones. There's a
default look you can take as-is (the one from the demo videos), you can
name your own picks, or you can describe a vibe and choose together. If
something you want doesn't exist in your CapCut, a similar one you like is
always the right answer. Nothing gets stuck because an exact item wasn't
found.

Then comes the sample project, from your answers. The universal part:

1. Open CapCut and click New project.
2. Drag any short video from your computer into CapCut, then drag it down
   onto the timeline. Do this FIRST, before adding anything else.
3. Click Text, then Add text. A text box appears on the timeline. Type
   anything in it.
4. That's enough for /long-cut. For /rough-cut, Claude's personal
   checklist takes it from here: one text box per font you chose, your
   animations applied, your sounds dropped anywhere on the timeline, your
   sticker if you wanted one. Said no to sounds and animations? Then your
   list is already done at step 3.
5. Back on CapCut's home screen, rename the project to exactly:
   STYLE_SETUP (three dots on the project tile, then Rename).
6. Quit CapCut completely (Cmd+Q, or CapCut menu, then Quit).

Tell Claude "done." Claude reads the project, confirms your picks, and
records them. From then on every video uses YOUR style. Do this exactly
once, and never delete the STYLE_SETUP project afterward.

## Using it every day

Open Claude Code and type `/rough-cut` or `/long-cut`, then drag your
video file into the chat. Claude asks a question or two, shows you what it
wants to do, and builds only after you say yes. Then it opens CapCut for
you with the draft ready.

Two habits:

- Close CapCut before a build. Claude reminds you every time.
- Keep a folder called "B Roll" in Documents with short clips of yourself,
  named by what they show ("me pouring water.mp4"). Rough-cut uses it to
  suggest cutaways.

USER-GUIDE.md in this folder is the full guide, including how to ask for
changes ("rewrite the hook", "captions up a smidge").

## Make the style yours

Your style is never locked in. Change your mind about a font, a sound, a
color, or a position anytime: find style inspo videos, creators whose
captions and text you love (for example: Jessie Jean, etc.), and tell
Claude what you want changed. For a new font, sound, animation, or
sticker, Claude will have you add it to the STYLE_SETUP project once (so
your CapCut downloads it), then it's yours on every video after.

## If something breaks later

CapCut updates itself sometimes, and an update can confuse the kit. If a
video that would have worked last week suddenly fails, just tell Claude:
"this worked before, CapCut updated." There's a repair guide built into
the kit and Claude follows it. Your videos and your old drafts are never
at risk.
