# Start Here

This kit gives you two editing helpers inside Claude Code:

- **/long-cut** cleans up a long video. It cuts filler words, dead pauses,
  flubs, and retakes. You get a plain CapCut draft ready for captions.
- **/rough-cut** turns a short talking-head video into a finished CapCut
  draft: captions, a hook, on-screen notes, sounds, and b-roll. You
  approve every word in chat before anything is built.

You never touch code. You never open Terminal. Claude does all of that.
Your job is this checklist, and most of it is clicking around CapCut.

## What you need

1. A Mac. This kit is Mac only.
2. The CapCut desktop app, installed from capcut.com. Open it once after
   installing.
3. Claude Code with a paid Claude plan. Get it at claude.com/code and sign
   in. The desktop app is the easiest way to use it.
4. About 30 minutes for setup. You only do this once.

## The one sentence that does the setup

1. Put this whole folder inside your Claude folder — the same folder that
   holds your ABOUT ME and PROJECTS folders. Name it exactly: capcut-kit.
   (No Claude folder yet? Create one anywhere you'll remember, called
   Claude, and put this inside it.)
2. Open Claude Code and open that folder.
3. Copy and paste this message to Claude:

> Read SETUP.md in this folder and set everything up for me. I am not
> technical. Go slow, one step at a time, and tell me exactly what to
> click.

That's it. Claude takes over. Along the way it will ask you to do a few
human things it can't do for you:

- Create a free Deepgram account (that's the transcription service) and
  paste one key into the chat. Claude gives you the exact steps.
- Your Mac may ask for your computer password once while Claude installs a
  free helper tool. That's normal.
- Build one special CapCut project called STYLE_SETUP. The full clicking
  list is below. Claude will walk you through it too.

## The style setup, step by step

This is the one-time CapCut project that teaches the kit your CapCut's
format and loads the fonts and sounds it uses. Do it exactly once. Never
delete this project afterward.

If you only want /long-cut for now, you only need steps 1 to 4 and step 12.
For /rough-cut, do all of it.

1. Open CapCut and click New project.
2. Drag any short video from your computer into CapCut, then drag it down
   onto the timeline. Do this FIRST, before adding anything else.
3. Click Text, then Add text. A text box appears on the timeline. Type
   anything in it.
4. That's enough for /long-cut. Doing rough-cut too? Keep going.
5. With that text box selected, find the font list and search: Larken.
   Click it. CapCut downloads it and applies it.
6. Add a second text box the same way. Set its font to: Ugly Dave.
7. Add a third text box. Set its font to: ZY Modern.
8. Animations: click your first text box, open the Animations tab, choose
   In, and click: Bounce In. Then click your second text box and give it
   the animation: Typing Cursor.
9. Sounds: click Audio, then Sound effects. Search for each of these and
   add each one to the timeline (anywhere is fine):
   - Keyboard Typing 01
   - Glitter glitter (the long name mentions Glocken)
   - Title Swoosh
   - Mouse click 1
   - Bell 02
   - Pop Whoosh
   - Pop. Sound to open the lid (search "pop sound to open")
10. Sticker: click Stickers, search: underline. Add the one called Two
    White Underline (white double underline). Drag it onto the timeline.
11. Go back to CapCut's home screen. Find this project, click the three
    dots on it, choose Rename, and name it exactly: STYLE_SETUP
12. Quit CapCut completely (Cmd+Q, or CapCut menu, then Quit).

Then tell Claude "done." Claude checks the project and tells you in plain
words if anything is missing. Add it, quit CapCut, say "done" again.

## Using it every day

Open Claude Code and type `/rough-cut` or `/long-cut`, then drag your
video file into the chat. Claude asks a question or two, shows you what it
wants to do, and builds only after you say yes. Then it opens CapCut for
you with the draft ready.

Two habits:

- Close CapCut before a build. Claude reminds you every time.
- Keep a folder called "B Roll" in Documents with short clips of yourself,
  named by what they show ("me pouring water.mp4"). Rough-cut uses it to
  suggest cutaways.

USER-GUIDE.md in this folder is the full guide, including how to ask for
changes ("rewrite the hook", "captions up a smidge").

## Make the style yours

The kit ships with one proven look. You don't have to keep it. Find your
own style inspo videos, creators whose captions and text you love (for
example: Jessie Jean, etc.), and tell Claude what you want changed: fonts,
colors, text positions, sounds. Claude updates the style for every video
after that.

## If something breaks later

CapCut updates itself sometimes, and an update can confuse the kit. If a
video that would have worked last week suddenly fails, just tell Claude:
"this worked before, CapCut updated." There's a repair guide built into
the kit and Claude follows it. Your videos and your old drafts are never
at risk.
