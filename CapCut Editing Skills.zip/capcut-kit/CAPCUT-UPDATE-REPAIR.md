# CapCut Update Repair Playbook

For the Claude on duty when /rough-cut or /long-cut breaks after a CapCut
update. Follow the steps in order; each one is small. The user is not
technical — they can click around CapCut for you and answer yes/no
questions, nothing more.

## Why updates break this kit (read once)

The kit writes CapCut's own private files, and it copies every format
detail from snapshots in `reference/` that the user's own CapCut wrote:

- `draft_info.json` (the timeline): built by pyJianYingDraft, then
  upgraded by `src/conform.py`, which fills every missing key from
  `reference/draft_info.json`.
- `draft_meta_info.json` + the entry in `root_meta_info.json` (the draft's
  identity): built field-for-field in `src/meta_info.py`.
- Styles: fonts/sounds/animations/stickers cloned from `reference/*.json`,
  harvested from the user's STYLE_SETUP draft.
- macOS paths in `src/capcut_env.py`.

When CapCut updates its format, the fix is almost never rewriting code. It
is: refresh the STYLE_SETUP draft in the NEW CapCut, re-run the two
snapshot scripts, and patch the rare structural change. That is this
playbook.

## Safety rails (non-negotiable)

1. NEVER touch, wipe, or rebuild the STYLE_SETUP draft beyond asking the
   user to open or edit it in CapCut themselves.
2. CapCut must be CLOSED for every write to its library. Check:
   `pgrep -f "CapCut.app/Contents/MacOS/CapCut"`. Reading is safe anytime.
3. Only ever wipe draft folders whose names start with `ZZTEST_`.
   `clean_draft_dir` enforces this — do not work around it.
4. `root_meta_info.json` is backed up to `backups/` before every write.
5. Do all repair test builds into `ZZTEST_repair_<date>` draft names.
6. Never hand-write draft JSON from your own knowledge of "what CapCut
   wants." Every key shape must come from a reference snapshot.

## Step 1 — Confirm it is actually a version break

Not every failure is CapCut's fault. Triage first:

| Symptom | Likely cause | Go to |
|---|---|---|
| `run.py`/`longcut.py` crashes with a Python error | Code/venv/dependency problem, not CapCut | Fix normally |
| Transcription step fails | Deepgram key/network (`.env`) | Fix normally |
| style_presets raises "fonts.json is missing" | Style harvest never ran | SETUP.md step 7 |
| Build succeeds, draft does NOT appear in CapCut's list | meta/root shape changed, or paths moved | Step 2 |
| Draft appears but CapCut crashes or errors opening it | draft_info / draft_meta_info shape changed | Step 2 |
| Draft opens but clips show offline | Sandbox media path moved | Step 5 |
| Draft opens but text/sounds/animations are missing or wrong | Style resources changed | Step 6 |

Record the CapCut version:
`defaults read /Applications/CapCut.app/Contents/Info.plist CFBundleShortVersionString`.
Compare against the format the snapshots were taken from (`version` /
`new_version` keys in `reference/draft_info.json`).

## Step 2 — Refresh the reference snapshots from the NEW CapCut

Archive the old snapshots first (never overwrite history):

    cd <the capcut-kit folder this person's skills point at>
    mkdir -p reference/archive-$(date +%Y%m%d)
    cp reference/*.json reference/archive-$(date +%Y%m%d)/ 2>/dev/null

Ask the user to open the STYLE_SETUP draft in the new CapCut, let it load
fully, make one tiny edit and undo it (this makes CapCut re-save the draft
in the NEW format), then quit CapCut completely. Then:

    .venv/bin/python src/make_reference.py STYLE_SETUP
    .venv/bin/python src/harvest_style.py STYLE_SETUP   # rough-cut installs only

If harvest's role report shows roles that used to be filled now unfilled,
the update may have cleared CapCut's cache — guide the user to re-add
THEIR items (the names in style_map.json, shown in the report) to
STYLE_SETUP, save, quit, re-run.

## Step 3 — Test build

1. Confirm CapCut is closed.
2. Build a short test video into a `ZZTEST_repair_<date>` draft
   (`longcut.py <video> --no-smart` is the fastest end-to-end test).
3. `open -a CapCut` and ask the user: does the test draft appear, open,
   and play? For rough-cut, do a text layer test too and check fonts and
   sounds.
4. All yes → clean up the test draft (`src/build_video.py --remove <name>`
   plus wiping its folder, CapCut closed) and you're done.
5. Any no → the format changed structurally, not just by added keys.
   Continue to step 4.

## Step 4 — Structural changes (the rare, real work)

Diff the OLD vs NEW snapshots' key structure (values will differ; you care
about keys appearing, disappearing, or moving). Write a small script that
loads both JSONs and recursively compares sorted key sets, printing
added/removed key paths. Compare `draft_info.json` and
`draft_meta_info.json` against the archived copies. Classify:

- **Added keys** → conform.py fills draft_info additions automatically.
  For draft_meta_info / the root entry, add the new keys (with the new
  snapshot's generic values) to the dicts in `src/meta_info.py`.
- **Removed keys** → usually harmless to keep emitting; remove only if
  CapCut rejects the draft.
- **Renamed/moved keys or changed nesting** → update `meta_info.py`
  shapes, and check `conform.py`'s touch points: the `version` /
  `new_version` / `platform` stamps, `ref["tracks"][0]["segments"][0]`,
  `ref["materials"]["videos"][0]`, and the `local_material_id` link.
- **`draft_materials` bucket list changed** (draft_meta_info) → update
  `_MATERIAL_BUCKET_TYPES` in `meta_info.py`.

Rules of thumb: copy generic values (flags, empty strings, -1s) verbatim
from the new snapshot; NEVER copy media-specific values (paths, ids,
durations, sizes) — those are computed per build. Then repeat step 3.

## Step 5 — If CapCut's folders moved

All paths live at the top of `src/capcut_env.py`. Find the new homes:

    mdfind -name root_meta_info.json 2>/dev/null | grep -i capcut
    find ~/Library/Containers -maxdepth 6 -name "ImportMedias" -type d 2>/dev/null
    find ~/Movies -maxdepth 4 -iname "*draft*" -type d 2>/dev/null

The container id (`com.lemon.lvoverseas`) and the projects dir
(`com.lveditor.draft`) are the parts most likely to change. Update the
constants; nothing else should need edits.

## Step 6 — If drafts open but the STYLE is broken

Ask the user to open STYLE_SETUP in the new CapCut. If its own text and
sounds look right, re-run `src/harvest_style.py STYLE_SETUP` (read-only)
and rebuild. If STYLE_SETUP itself lost styling, CapCut changed resource
handling: guide the user to re-apply the broken pieces in STYLE_SETUP
(harvest's role report shows what stopped resolving), then harvest and
rebuild.

## Step 7 — Know when to stop

If CapCut still rejects drafts after all of the above, the format may have
changed too deeply for key-filling (e.g. draft files became binary or
encrypted). Do NOT brute-force. Tell the user plainly:

- what works and what doesn't
- that this needs a kit update from whoever they got the kit from
- their fallback: don't update CapCut on this Mac until then. Old CapCut
  versions keep working, and every draft already built keeps working.

## Also true, so you don't rediscover it

- pyJianYingDraft is pinned to an old format ON PURPOSE. Do not upgrade or
  patch the library to chase CapCut versions — conform.py is the adapter
  layer; all version knowledge belongs there and in meta_info.py.
- `pgrep -x CapCut` false-negatives. Always
  `pgrep -f "CapCut.app/Contents/MacOS/CapCut"`.
- Media must be staged inside CapCut's sandbox (`ImportMedias`) or clips
  show offline. If clips are offline after an update, check whether the
  sandbox path moved (step 5) before suspecting the draft JSON.
- text transform.y: POSITIVE = up.
- Drafts only reference the source video file. Worst case a draft won't
  open; the user's footage is untouched.
