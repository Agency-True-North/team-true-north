# How to run your cut kit

Turns raw video into a CapCut draft you finish yourself. You approve
everything before it's built.

Two front doors:

- **/rough-cut** — reels and shorts. The full treatment: captions, hook,
  annotations, sounds, b-roll.
- **/long-cut** — long 16:9 videos (masterclass style). Cuts only: filler
  words, dead pauses, flubs, retakes. No text layers — you add captions
  yourself in CapCut. See "Long videos" below.

## The easy way: /rough-cut

In Claude Code, type:

    /rough-cut

then **drag your video file into the chat** — that's how you point it at a
video. Claude asks one short question (hook? hot takes? anything to tell
the editor?), shows you what it proposes, and you approve or ask for
changes in plain English right there ("cut the second annotation",
"make 0:30 the mouse click instead"). Nothing is built until you say yes,
then Claude opens CapCut with the draft ready.

Several videos: drag them all in and they're done one at a time, each with
its own approval.

You can also skip the slash command and just say what you want with the
file dragged in: "rough cut this, my hook is Dream Smaller, one hot take."

## Before every build

Close CapCut. That's the only rule, and Claude will remind you.

## Telling the editor what you want

Say it when you drag the video in. Mix and match:

- **You already know your hook:** "my hook is You Forgot What You Can Do"
- **It's an informational video** (points, steps, tips): "use mouse
  clicks" — every annotation enters with the mouse click sound. Otherwise
  the editor decides per annotation: mouse click for information, pop for
  emotional beats, bell for the single biggest moment. Numbered list items
  always get the mouse click no matter what.
- **You want a hot take / inner thoughts / hear me moment:** "my hot take
  is the line about quitting quietly, label it inner thoughts." You name
  the line and the label; it gets a tilted yellow label with an underline
  and a pop whoosh. Want the editor to pick the moment instead? Say so.
  Don't ask, and no labels are built.
- **Anything else you'd tell an editor:** just say it. "Teaching video,
  keep it gentle, b-roll of me working with kids around." Notes are free
  text and the editor follows them over its defaults.
- **No b-roll this time:** "no b-roll."

## B-roll

Your library is a folder called `B Roll` inside Documents. Keep filenames
descriptive — that's how the editor matches footage to what you're saying
("woman tired at desk.mp4" gets found when you talk about burnout). Drop
new clips in anytime; every run sees the current folder.

The editor proposes cutaways only where they help. Two kinds show up:

    B-ROLL:
      0:29  2s  women tired at laptop.mp4
      0:50  NOT IN LIBRARY — film: you hyping a friend on the phone

The first is in your library and will be placed (muted, 1-3 seconds) if
you approve. The second is a suggestion for footage you don't have yet —
it's never placed, it's the editor telling you what would be worth
filming.

## The approval gate

After proposing, Claude shows you the whole plan: hook, sub-line, every
annotation with its timestamp and sound, hot takes, pop words, b-roll.
Change anything in plain English ("rewrite the hook", "drop annotation 2",
"swap that b-roll clip"). Only your yes builds the draft.

When it finishes, CapCut opens and the draft is in your list, named after
the video file. Everything is normal CapCut layers — move, retime, or
delete anything by hand.

## Long videos: /long-cut

For masterclass-style recordings — long, 16:9, where all you need is the
mistakes gone. Type:

    /long-cut

then drag the video in. It transcribes (a few minutes on a long video),
cuts filler words and dead pauses automatically, and reads the transcript
for flubs and retakes. Long transcripts are read in chunks, several at a
time, so even a 45-minute class takes minutes, not an hour. You get:

- **Cutting** — the obvious ones (a flubbed line you re-said, a false
  start, a "wait, let me say that again"). Listed with timestamps so you
  can veto any, but you don't approve them one by one.
- **Your call** — judgment cuts (a passage that repeats a point, a
  tangent). Each one shows you the exact words that would go. Yes or no
  per item, right in the chat.

Then it builds a plain draft: just your video with the cuts, same 16:9
canvas, no text layers. You caption it YouTube style in CapCut like
always.

**Every cut is reversible.** The draft references your full original file —
click a clip edge at any cut point and drag to bring the material back.
The cut list tells you where to look.

**Pacing.** Pauses are trimmed tight by default (gaps over about half a
second get cut, with enough air left to breathe). If a video should keep
its natural rhythm, a meditation or a slow story, say "natural pacing."

Know something the editor should? Say it when you drag the video in:
"the pricing section was re-recorded, keep the second version."

## Make the style yours

Every font, sound, animation, and sticker in your videos is your pick.
The kit's default look is only a starting point, and none of it is
required. Find your own style inspo videos, creators whose text and
captions you love (for example: Jessie Jean, etc.), and tell Claude what
to change: "captions in a different font", "yellow feels too warm, try
this hex", "hook lower on screen", "swap the pop sound for something
softer". For a new font or sound, Claude has you add it to your
STYLE_SETUP project once (any one you like), then it's on every video
after. Skipping a sound entirely is fine too, that moment just plays
silent. And if sound effects or animations aren't your style at all, say
"no sound effects" or "no animations" and they're off for every video
until you say otherwise.

## If something looks off

Tell Claude what you see, the way you'd tell an editor: "captions up a
smidge", "the pop is too loud", "wrong b-roll at 0:30". Exact words work
best.

If a build that used to work suddenly fails, CapCut probably updated
itself. Tell Claude: "this worked before, CapCut updated." The repair
guide is built in.

## Cheat sheet

| You want | Say (or type) |
|---|---|
| Edit a reel/short | `/rough-cut` + drag the file in |
| Clean up a long 16:9 video | `/long-cut` + drag the file in |
| Use your own hook | "my hook is ..." |
| A hot take / inner thoughts moment | "my hot take is ..., label it inner thoughts" |
| Informational video | "use mouse clicks" |
| Steer the editor | just say it: "keep it gentle, b-roll of me at the beach" |
| No b-roll this time | "no b-roll" |
| Change a proposal | say the change: "rewrite the hook", "drop annotation 2" |
| Fix the style forever | tell Claude after you see it in CapCut |
| No sound effects, ever | "turn off sound effects" (same for animations) |
