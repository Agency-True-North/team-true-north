# Content Multiplier — Claude Code Skill (v2)

One Claude Code skill that turns a single piece of content into your week:

**`/multiply`** — two ways to use it.

1. **The reel package.** Ask for a reel, or hand it a topic, a teaching point, or a quote you loved. You get the reel script you'll film, a companion carousel or static quote post rendered as finished PNG images in YOUR brand palette, and a comment reply pack written ready to paste.
2. **The classic multiply.** Hand it one finished piece (a reel script, an essay, an email, a caption, or a raw voice memo) and it produces the rest: an email, a long-form essay or newsletter, a rendered carousel, a caption, a story sequence, and podcast episode ideas if you have a podcast.

Every output runs through your content engine's critic before you see it, so it sounds like you AND holds the conversion structure.

New in v2:

- **It learns your posting cadence** (asked once, saved) and closes every run with a posting map: which piece goes out which day.
- **It builds your brand palette with you** (asked once, saved) — or reads the one you already have — and renders carousels and quote posts as finished 1080x1350 PNGs on your own computer. You approve the words in chat, then a mockup page of every slide, then the files land in a folder.

The install guide lives here:
https://agency-true-north.github.io/team-true-north/Content%20Multiplier%20Skill%20Install.html

---

## Requires the Content Engine

This skill runs on top of the Content Engine — it uses your voice spec, your persuasion spec, and your critic. If you haven't installed and set up the engine yet, do that first:
https://agency-true-north.github.io/team-true-north/Content%20Engine%20Guide.html

The skill checks for `engine/voice-spec.md` in your workspace and will stop and point you to the engine guide if it's missing.

For rendering, your computer also needs **Python 3** and **Chrome, Edge, or Brave**. Most machines already have both; Claude will tell you plainly if yours doesn't.

---

## Install

A Claude Code skill is a folder in a `.claude/skills/` directory. This one has three files in it: `SKILL.md` (the instructions), `render-carousel.py` (the image renderer), and `palette-example.json` (a reference file). Two places work:

- **Personal (all your projects):** `~/.claude/skills/`
- **One project (shared with your team via git):** `<project>/.claude/skills/`

### Option A — copy the folder in

Copy the skill folder from this package into whichever `.claude/skills/` you want:

```bash
# personal, available everywhere
mkdir -p ~/.claude/skills
cp -R "multiply" ~/.claude/skills/

# or per-project (commit it so teammates get it too)
mkdir -p /path/to/your-project/.claude/skills
cp -R "multiply" /path/to/your-project/.claude/skills/
```

(The skill folder lives under `.claude/skills/` inside this package.)

### Option B — do it by hand

Create the folder and copy all three files in:

```
.claude/
└── skills/
    └── multiply/
        ├── SKILL.md
        ├── render-carousel.py
        └── palette-example.json
```

Restart Claude Code (or start a new session) so it picks up the new skill.

---

## Use

In Claude Code (in the workspace where your engine lives), type:

```
/multiply
```

For a reel package, just say what you want:

```
/multiply

Make me a reel about [your topic, idea, or the quote you loved].
Offer: [what this content belongs to]
CTA: [where it points — your offer, a freebie, follow, or none]
```

For the classic multiply, paste your piece with a few context lines on top:

```
Multiply this into an email, an essay, a carousel, a caption, and stories.
Offer: [what this content belongs to]
CTA: [where each piece points — your offer, a freebie, follow, or none]

[paste the finished piece or memo]
```

The first time you run it, Claude interviews you about your posting cadence and your brand palette — one question at a time, saved to a `brand/` folder in your workspace, never asked again unless you change them.

---

## What you'll need

- **Claude Code** (CLI, desktop, web, or IDE extension).
- **The Content Engine, installed and set up** — voice spec approved, critic in place. The engine guide covers it.
- **Python 3 and Chrome, Edge, or Brave** for rendering images.
- Run it on **Sonnet-class or better**, same as the rest of the engine.

---

## Notes

- The source is finished work. The multiplier never re-drafts it, and your exact lines outrank anything the model writes.
- No CTA means no pitch. The critic fails any ask you didn't request.
- The anti-clone rule is baked in: every format enters the idea by its own door. No two outputs share an opening line.
- Nothing renders until you've approved the words in chat AND the mockup page.
- Your `brand/palette.json` and `brand/cadence.md` are yours. Skill updates never touch them.
- When the master copy of this skill gets updated, re-install the same way (or use the one-paste update in the install guide) — your local copy doesn't update itself.
