# Content Multiplier — Claude Code Skill

One Claude Code skill that fans a single finished piece of content out into the other formats:

**`/multiply`** — you hand it one finished piece (a reel script, an essay, an email, a caption, or a raw voice memo) and it produces the rest: an email, a long-form essay or newsletter, carousel copy, a caption, a story sequence, and podcast episode ideas if you have a podcast. Every output runs through your content engine's critic before you see it, so it sounds like you AND holds the conversion structure.

The install guide lives here:
https://agency-true-north.github.io/team-true-north/Content%20Multiplier%20Skill%20Install.html

---

## Requires the Content Engine

This skill runs on top of the Content Engine — it uses your voice spec, your persuasion spec, and your critic. If you haven't installed and set up the engine yet, do that first:
https://agency-true-north.github.io/team-true-north/Content%20Engine%20Guide.html

The skill checks for `engine/voice-spec.md` in your workspace and will stop and point you to the engine guide if it's missing.

---

## Install

A Claude Code skill is just a folder named `<skill-name>/` with a `SKILL.md` inside, placed in a `.claude/skills/` directory. Two places work:

- **Personal (all your projects):** `~/.claude/skills/`
- **One project (shared with your team via git):** `<project>/.claude/skills/`

### Option A — copy the folder in

Copy the skill folder from this package into whichever `.claude/skills/` you want:

```bash
# personal, available everywhere
mkdir -p ~/.claude/skills
cp -R "multiply" ~/.claude/skills/

# or per-project (commit it so teammates get it too)
mkdir -p /path/to/your-project/.claude/skills
cp -R "multiply" /path/to/your-project/.claude/skills/
```

(The skill folder lives under `.claude/skills/` inside this package.)

### Option B — do it by hand

Create the folder and paste the `SKILL.md`:

```
.claude/
└── skills/
    └── multiply/
        └── SKILL.md
```

Restart Claude Code (or start a new session) so it picks up the new skill.

---

## Use

In Claude Code (in the workspace where your engine lives), type:

```
/multiply
```

or just say it — "multiply this" / "fan this out" — and paste your piece with a few context lines on top:

```
Multiply this into an email, an essay, a carousel, a caption, and stories.
Offer: [what this content belongs to]
CTA: [where each piece points — your offer, a freebie, follow, or none]

[paste the finished piece or memo]
```

Claude builds a source sheet (your one idea + your best lines kept verbatim), drafts each format, and runs every one through the engine's critic and revise loop. You get each finished piece with its critic verdict.

---

## What you'll need

- **Claude Code** (CLI, desktop, web, or IDE extension).
- **The Content Engine, installed and set up** — voice spec approved, critic in place. The engine guide covers it.
- Run it on **Sonnet-class or better**, same as the rest of the engine.

---

## Notes

- The source is finished work. The multiplier never re-drafts it, and your exact lines outrank anything the model writes.
- No CTA means no pitch. The critic fails any ask you didn't request.
- The anti-clone rule is baked in: every format enters the idea by its own door. No two outputs share an opening line.
- When the master copy of this skill gets updated, re-install the same way — your local copy doesn't update itself.
