# DM Messenger: Claude Code Skill

One Claude Code skill that coaches your inbound DM conversations:

**`/dm-messenger`**: paste a DM thread, a screenshot, or a description of a voice note exchange, and it tells you where she is in the Hell to Heaven arc, hands you the exact next message in your texting voice, says whether to send it as text or a voice note, names the move behind it, and tells you what to send next. The first run is a one-time setup interview that learns your ICP, your ads, your story, your class link, and how you text. It then logs every send and reply and reads the patterns, so you are never deciding off three conversations.

The Hell to Heaven framework this runs on is the sales call script:
https://agency-true-north.github.io/team-true-north/Sales%20Call%20Script.html

---

## Install

A Claude Code skill is a folder named `dm-messenger/` with a `SKILL.md` inside, placed in a `.claude/skills/` directory. Two places work:

- **Personal (all your projects):** `~/.claude/skills/`
- **One project:** `<project>/.claude/skills/`

### Option A: copy the folder in

```bash
mkdir -p ~/.claude/skills
cp -R ".claude/skills/dm-messenger" ~/.claude/skills/
```

### Option B: by hand

```
.claude/
└── skills/
    └── dm-messenger/
        └── SKILL.md
```

Restart Claude Code (or start a new session) so it picks up the new skill.

---

## Use

First time, type `/dm-messenger` and answer the setup questions, one at a time. It saves a profile in the folder you're working in (`dm-messenger/profile.md`).

After that, paste any DM:

```
Help me reply to this DM. Her name is [name].

Me: [what you sent]
Her: [what she said]
Her: [her latest message]
```

You get back: where she is, the message to send, text or voice note and why, the logic, and the next move.

---

## Rules baked in

- She messaged you first. The skill will not write cold openers.
- One question per message. Her words mirrored back before any ask.
- No link before the permission question. No company name before she's watched the class. No prices in DMs.
- A no is a no for that conversation.
- When the master copy of this skill gets updated, re-install the same way. Your local copy doesn't update itself.
